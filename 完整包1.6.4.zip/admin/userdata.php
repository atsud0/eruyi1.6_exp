<?php
/*
* File：管理账号密码数据文件
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

$user = 'admin123';//后台账号

$pass = 'admin456';//后台密码

$cookie = '80a10b066fd7400d99bdbd6444e0e69e';

/* 请手动修改以上账号密码信息 */
?>