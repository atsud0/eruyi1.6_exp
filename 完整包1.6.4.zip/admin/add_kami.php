<?php
/*
* File：生成卡密
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';

$type = isset($_POST['k_type']) ? addslashes($_POST['k_type']) : 'vip';
$k_vip = isset($_POST['k_vip']) ? intval($_POST['k_vip']) : 0;//VIP天数
$k_fen = isset($_POST['k_fen']) ? intval($_POST['k_fen']) : 0;//积分
$num = isset($_POST['num']) ? intval($_POST['num']) : 1;
$out = isset($_POST['out']) ? intval($_POST['out']) : 0;
$k_length = isset($_POST['k_length']) ? intval($_POST['k_length']) : 10;
$add_submit = isset($_POST['add_submit']) ? addslashes($_POST['add_submit']) : '';
$del_submit = isset($_POST['del_submit']) ? addslashes($_POST['del_submit']) : '';

if($add_submit){
	$str = '';
	if($type == 'vip'){
		$k_num = $k_vip;
	}else{
		$k_num = $k_fen;
	}
	for($i=1;$i<=$num;$i++){
		$key=getcode($k_length);
		$sql="INSERT INTO `eruyi_kami`(`kami`, `type`,`num`,`new`) VALUES ('$key','$type','$k_num','y')";
		$query=$db->query($sql);
		$str .= $key . "\r\n";
	}
	if($out == 1){
		header("Content-Type: application/octet-stream");
		header("Content-Disposition: attachment; filename={$type}_kami.txt");
		echo "==============卡密开始================\r\n\r\n";
		echo $str;
		echo "\r\n\r\n==============卡密结束================";
		exit;
	}else{
		include_once 'header.php';
		echo "<script>alert('生成成功');</script>";
	}
}else if($del_submit){
	$sql="DELETE FROM `eruyi_kami` WHERE `new`='n'";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('清理成功');location.href='add_kami.php';</script>";
	}
}else{	
	include_once 'header.php';
}

function getcode($length){ 
	$str = null;  
	$strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";  
	$max = strlen($strPol)-1;  
	for($i=0;$i<$length;$i++){
		$str.=$strPol[rand(0,$max)];
	}  
	return $str; 
}
?>
	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>卡密生成</h3>
				</div>
				<div class="module-body">
					<form action="" method="post" id="addimg" name="addimg" class="form-horizontal row-fluid">
					<div id="post">
						<div class="control-group">
							<label class="control-label" for="type" id="type_label">卡密类型:</label>
							<div class="controls">
								<select name="k_type" id="k_type" onchange="change()">
									<option value="vip">会员卡</option>
									<option value="fen">积分卡</option>
								</select>
							</div>
						</div>
						<div class="control-group">
							<div class="view" name="vip_c" id="vip_c" style="display: block;">
								<label class="control-label" for="vip_label">会员天数:</label>
									<div class="controls">
										<input type="text" name="k_vip" id="k_vip" placeholder="永久卡天数:999999999" value="">
									</div>
							</div>
							<div class="view" name="fen_c" id="fen_c">
								<label class="control-label" for="fen_label">用户积分:</label>
								<div class="controls">
									<div class="input-append">
										<input type="text" name="k_fen" id="k_fen" placeholder="0" value="" class="span8"><span class="add-on">积分</span>
									</div>
								</div>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="basicinput">卡密长度:</label>
							<div class="controls">
								<input type="text" name="k_length" id="k_length" value="10">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="basicinput">生成数量:</label>
							<div class="controls">
								<div class="input-append">
									<input type="text" name="num" id="num" value="1" class="span8"><span class="add-on">张</span>
								</div>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">卡密导出:</label>
							<div class="controls">
								<label class="checkbox inline" for="out" id="out_label">
								<input type="checkbox" name="out" id="out" value="1">生成后立即导出</label>
							</div>
						</div>
						<div class="control-group">
							<div class="controls" id="post_button">
								<input type="submit" name="add_submit" value="确认生成" class="btn btn-success" />
							</div>
						</div>
					</div>				
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div  class="module-head">
					<label class="control-label" for="basicinput" style = "text-align:left;"><h3>卡密清理</h3></label>
					<div class="control-group" style = "text-align:right;">
						<div class="controls" id="post">
							<input type="submit" name="del_submit" value="一键清理已用卡密" class="btn btn-small btn-danger" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('add_kami'); 
div.setAttribute("class", "show"); 

function change() {
	if($('#k_type').val()=='vip'){
		$("#vip_c").css("display", "block");
		$("#fen_c").css("display", "none");
	}else{
		$("#vip_c").css("display", "none");
		$("#fen_c").css("display", "block");
	}
}
</script> 
<?php 
include_once 'footer.php';
?>