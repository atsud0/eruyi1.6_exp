<?php
/*
* File：添加商品
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$fen_name = isset($_POST['fen_name']) ? addslashes($_POST['fen_name']) : '';//积分名称
$fen_money = isset($_POST['fen_money']) ? addslashes($_POST['fen_money']) : '0';//积分金额
$appid = isset($_POST['appid']) ? addslashes($_POST['appid']) : '';//APPID
$fen_state = isset($_POST['fen_state']) ? addslashes($_POST['fen_state']) : 'y';//积分状态
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
$adopt = true;
if($submit){
	if($appid == ''){
		$adopt = false;
		echo "<script>alert('请先创建应用');location.href='add_app.php';</script>";
	}
	if($fen_name == ''){
		echo "<script>alert('请输入积分事件名称');</script>";
		$adopt = false;
	}else if($fen_money <= 0){
		echo "<script>alert('请输入积分事件积分数');</script>";
		$adopt = false;
	}
	if($adopt == true){
		$sql="INSERT INTO `eruyi_fen`(`fen_name`, `fen_money`, `appid`, `fen_state`) VALUES ('$fen_name','$fen_money','$appid','$fen_state')";
		$query=$db->query($sql);
		if($query){
			echo "<script>alert('添加成功');</script>";
		}else{
			echo "<script>alert('添加失败');</script>";
		}
	}
}
?>

	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>添加积分事件</h3>
				</div>
				
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					
					<div class="control-group">
						<label class="control-label" for="g_name_label">事件名称:</label>
						<div class="controls">
							<input type="text" name="fen_name" id="fen_name" placeholder="请填写事件名称.." value="" class="span8">
							<span class="help-inline">*</span>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="money">事件消耗:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="fen_money" id="fen_money" placeholder="0" value="" class="span8"><span class="add-on">积分</span>
								
							</div>
						</div>
					</div>
					
					
					<div class="control-group">
						<label class="control-label">事件状态:</label>
						<div class="controls">
							<label class="radio inline">
							<input type="radio" name="fen_state" id="fen_state" value="y" checked="">正常</label> 
							<label class="radio inline">
							<input type="radio" name="fen_state" id="fen_state" value="n">关闭</label> 
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="type" id="appid_label">应用选择:</label>
						<div class="controls">
							<select name="appid" id="appid" class="span8">
								<?php
									$sql="select * from eruyi_app where 1";
									$query=$db->query($sql);
									while($rows=$db->fetch_array($query)){
								?>
								<option value="<?php echo $rows['id']; ?>"><?php echo $rows['name']; ?></option>
								<?php } ?>
							</select>
						</div>
					</div>
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="确认添加" class="btn btn-success" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('add_fen'); 
div.setAttribute("class", "show"); 
</script>
<?php 
include_once 'footer.php';
?>