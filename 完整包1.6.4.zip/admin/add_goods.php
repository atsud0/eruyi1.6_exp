<?php
/*
* File：添加商品
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$g_name = isset($_POST['g_name']) ? addslashes($_POST['g_name']) : '';//商品名称
$g_vip = isset($_POST['g_vip']) ? intval($_POST['g_vip']) : 0;//VIP天数
$g_money = isset($_POST['g_money']) ? addslashes($_POST['g_money']) : '0';//商品金额
$appid = isset($_POST['appid']) ? addslashes($_POST['appid']) : '';//APPID
$g_type = isset($_POST['g_type']) ? addslashes($_POST['g_type']) : 'vip';//商品类型
$g_fen = isset($_POST['g_fen']) ? intval($_POST['g_fen']) : 0;//积分
$g_state = isset($_POST['g_state']) ? addslashes($_POST['g_state']) : 'y';//商品状态
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
$adopt = true;
if($submit){
	if($appid == ''){
		$adopt = false;
		echo "<script>alert('请先创建应用');location.href='add_app.php';</script>";
	}
	if($g_name == ''){
		echo "<script>alert('请输入商品名称');</script>";
		$adopt = false;
	}else if($g_money <= 0){
		echo "<script>alert('请输入商品金额');</script>";
		$adopt = false;
	}else if($g_type == 'vip'){
		if($g_vip <= 0){
			echo "<script>alert('请输入VIP天数');</script>";
			$adopt = false;
		}
	}else if($g_type == 'fen'){		
		if($g_fen <= 0){
			echo "<script>alert('请输入积分数');</script>";
			$adopt = false;
		}	
	}
	if($adopt == true){
		$sql="INSERT INTO `eruyi_goods`(`g_name`, `g_vip`, `g_fen`, `g_money`, `appid`, `g_type`, `g_state`) VALUES ('$g_name','$g_vip','$g_fen','$g_money','$appid','$g_type','$g_state')";
		$query=$db->query($sql);
		if($query){
			echo "<script>alert('添加成功');</script>";
		}else{
			echo "<script>alert('添加失败');</script>";
		}
	}
	
}
?>

<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>添加商品</h3>
				</div>
				
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					
					<div class="control-group">
						<label class="control-label" for="g_name_label">商品名称:</label>
						<div class="controls">
							<input type="text" name="g_name" id="g_name" placeholder="请填写商品名称.." value="" class="span8">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="type" id="type_label">商品类型:</label>
						<div class="controls">
							<select name="g_type" id="g_type" onchange="change()">
								<option value="vip">用户会员</option>
								<option value="fen">用户积分</option>
							</select>
						</div>
					</div>
					<div class="control-group">
						<div class="view" name="vip_c" id="vip_c" style="display: block;">
							<label class="control-label" for="vip_label">会员天数:</label>
							<div class="controls">
								<div class="input-append">
									<input type="text" name="g_vip" id="g_vip" placeholder="会员天数" value="" class="span8"><span class="add-on">天</span>
								</div>
							</div>
						</div>
						<div class="view" name="fen_c" id="fen_c">
							<label class="control-label" for="fen_label">用户积分:</label>
							<div class="controls">
								<div class="input-append">
									<input type="text" name="g_fen" id="g_fen" placeholder="0" value="" class="span8"><span class="add-on">积分</span>
								</div>
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="money">商品金额:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="g_money" id="g_money" placeholder="0.00" value="" class="span8"><span class="add-on">$</span>
							</div>
						</div>
					</div>
					
					
					<div class="control-group">
						<label class="control-label">商品状态:</label>
						<div class="controls">
							<label class="radio inline">
							<input type="radio" name="g_state" id="g_state" value="y" checked="">正常</label> 
							<label class="radio inline">
							<input type="radio" name="g_state" id="g_state" value="n">停售</label> 
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="type" id="appid_label">应用选择:</label>
						<div class="controls">
							<select name="appid" id="appid" class="span8">
								<?php
									$sql="select * from eruyi_app where 1";
									$query=$db->query($sql);
									while($rows=$db->fetch_array($query)){
								?>
								<option value="<?php echo $rows['id']; ?>"><?php echo $rows['name']; ?></option>
								<?php } ?>
							</select>
						</div>
					</div>
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="确认添加" class="btn btn-success" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('add_goods'); 
div.setAttribute("class", "show"); 

function change() {
	if($('#g_type').val()=='vip'){
		$("#vip_c").css("display", "block");
		$("#fen_c").css("display", "none");
	}else{
		$("#vip_c").css("display", "none");
		$("#fen_c").css("display", "block");
	}
}
</script>
<?php 
include_once 'footer.php';
?>