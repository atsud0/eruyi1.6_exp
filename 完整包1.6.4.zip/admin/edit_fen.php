<?php
/*
* File：编辑应用
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : '';
$sql="select * from eruyi_fen where id=$id";
$query=$db->query($sql);
$row=$db->fetch_array($query);

$fen_name = isset($_POST['fen_name']) ? addslashes($_POST['fen_name']) : '';//积分名称
$fen_money = isset($_POST['fen_money']) ? addslashes($_POST['fen_money']) : '0';//积分金额
$appid = isset($_POST['appid']) ? addslashes($_POST['appid']) : '';//APPID
$fen_state = isset($_POST['fen_state']) ? addslashes($_POST['fen_state']) : 'y';//积分状态
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
$adopt = true;
if($submit){
	if($appid == ''){
		$adopt = false;
		echo "<script>alert('请先创建应用');location.href='add_app.php';</script>";
	}
	if($fen_name == ''){
		echo "<script>alert('请输入积分事件名称');</script>";
		$adopt = false;
	}else if($fen_money <= 0){
		echo "<script>alert('请输入积分事件积分数');</script>";
		$adopt = false;
	}
	if($adopt == true){
		$sql="UPDATE `eruyi_fen` SET `fen_name`='$fen_name', `fen_money`='$fen_money', `appid`='$appid', `fen_state`='$fen_state' WHERE id=$id";
		$query=$db->query($sql);
		if($query){
			echo "<script>alert('编辑成功');location.href='edit_fen.php?id=".$id."';</script>";
		}echo "<script>alert('编辑失败');</script>";

	}
}

?>
	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>积分事件设置</h3>
				</div>
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					<div class="control-group">
						<label class="control-label" for="name_label">事件ID:</label>
						<div class="controls">
							<input type="text" id="fenid" value="<?php echo $id;?>" disabled>
							<span class="help-inline"><a href="javascript:void(0);" onclick="copy_id()">复制</a></span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name_label">事件名称:</label>
						<div class="controls">
							<input type="text" name="fen_name" id="fen_name" value="<?php echo $row['fen_name'];?>" >
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="money">事件消耗:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="fen_money" id="fen_money" placeholder="0" value="<?php echo $row['fen_money'];?>" class="span8"><span class="add-on">积分</span>
								
							</div>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">事件状态:</label>
						<div class="controls">
							<label class="radio inline">
							<input type="radio" name="fen_state" id="fen_state" value="y" <?php if($row['fen_state']=='y'){echo 'checked=""';}?>>正常</label> 
							<label class="radio inline">
							<input type="radio" name="fen_state" id="fen_state" value="n" <?php if($row['fen_state']=='n'){echo 'checked=""';}?>>关闭</label> 
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="type" id="type_label">应用选择:</label>
						<div class="controls">
							<select name="appid" id="appid" class="span8">
								<?php
									$sql="select * from eruyi_app where 1";
									$query=$db->query($sql);
									while($rows=$db->fetch_array($query)){
								?>
								<option value="<?php echo $rows['id']; ?>" <?php if($row['appid'] == $rows['id']) echo 'selected = "selected"'; ?>><?php echo $rows['name']; ?></option>
								<?php } ?>
							</select>
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="修改保存" class="btn btn-success" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('edit_fen'); 
div.setAttribute("class", "show"); 
function inp(data) {
    console.log(data.value)
}
// 复制到剪切板

function copy_id(){
    var Url2="<?php echo $id;?>";
    var oInput = document.createElement('input');
    oInput.value = Url2;
    document.body.appendChild(oInput);
    oInput.select(); // 选择对象
    document.execCommand("Copy"); // 执行浏览器复制命令
    oInput.className = 'oInput';
    oInput.style.display='none';
    alert('复制成功');
}

</script>
<?php 
include_once 'footer.php';
?>