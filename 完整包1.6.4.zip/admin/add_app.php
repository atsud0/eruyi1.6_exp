<?php
/*
* File：添加应用
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$name = isset($_POST['app_name']) ? addslashes($_POST['app_name']) : '';
$ipon = isset($_POST['ipon']) ? intval($_POST['ipon']) : 0;//限制IP注册
$codeon = isset($_POST['codeon']) ? intval($_POST['codeon']) : 0;//限制机器码注册
$check_code = isset($_POST['check_code']) ? addslashes($_POST['check_code']) : 'y';//用户登入校验机器码  y开启 n关闭
$many_code = isset($_POST['many_code']) ? addslashes($_POST['many_code']) : 'n';//多设备登入  y开启 n关闭
$charge = isset($_POST['charge']) ? addslashes($_POST['charge']) : 'y';//收费模式 y收费 y免费

$reg_award = isset($_POST['reg_award']) ? addslashes($_POST['reg_award']) : 'vip';//注册奖励类型
$inv_award = isset($_POST['inv_award']) ? addslashes($_POST['inv_award']) : 'vip';//邀请奖励类型
$diary_award = isset($_POST['diary_award']) ? addslashes($_POST['diary_award']) : 'vip';//签到奖励类型
$reg_value = isset($_POST['reg_value']) ? intval($_POST['reg_value']) : 0;//注册送体验VIP时间（单位：分钟，设0关闭）
$inv_value = isset($_POST['inv_value']) ? intval($_POST['inv_value']) : 0;//邀请成功赠送体验VIP时间（单位：小时，设0关闭）
$diary_value = isset($_POST['diary_value']) ? intval($_POST['diary_value']) : 0;//每天签到成功赠送VIP时间（单位：分钟，设0关闭）

//echo '['.$reg_award.'|'.$reg_value.']'.'['.$inv_award.'|'.$inv_value.']'.'['.$diary_award.'|'.$diary_value.']';

$app_bb = isset($_POST['app_bb']) ? addslashes($_POST['app_bb']) : '1.0.0';//APP版本
$pay_url = isset($_POST['pay_url']) ? addslashes($_POST['pay_url']) : '';//支付请求地址
$pay_appid = isset($_POST['pay_appid']) ? addslashes($_POST['pay_appid']) : '';//支付ID
$pay_appkey = isset($_POST['pay_appkey']) ? addslashes($_POST['pay_appkey']) : '';//支付秘钥
$pay_zfb = isset($_POST['pay_zfb']) ? addslashes($_POST['pay_zfb']) : '';//支付宝支付方式
$pay_wx = isset($_POST['pay_wx']) ? addslashes($_POST['pay_wx']) : '';//微信支付方式
$pay_qq = isset($_POST['pay_qq']) ? addslashes($_POST['pay_qq']) : '';//qq支付方式
$pay_zfb_state = isset($_POST['pay_zfb_state']) ? addslashes($_POST['pay_zfb_state']) : '';//支付宝支付状态
$pay_wx_state = isset($_POST['pay_wx_state']) ? addslashes($_POST['pay_wx_state']) : '';//微信支付状态
$pay_qq_state = isset($_POST['pay_qq_state']) ? addslashes($_POST['pay_qq_state']) : '';//qq支付状态
$pay_state = isset($_POST['pay_state']) ? addslashes($_POST['pay_state']) : '';//支付状态
$pay_notify = isset($_POST['pay_notify']) ? addslashes($_POST['pay_notify']) : '';//异步通知地址
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
//echo $vip;
if($submit){
	if($name == ''){
		echo "<script>alert('失败：请输入应用名');</script>";
	}else{
		if($reg_award == 'vip'){
			$reg_vip = $reg_value;
			$reg_fen = 0;
		}else{
			$reg_fen = $reg_value;
			$reg_vip = 0;
		}
		
		if($inv_award == 'vip'){
			$inv_vip = $inv_value;
			$inv_fen = 0;
		}else{
			$inv_fen = $inv_value;
			$inv_vip = 0;
		}
		
		if($diary_award == 'vip'){
			$diary_vip = $diary_value;
			$diary_fen = 0;
		}else{
			$diary_fen = $diary_value;
			$diary_vip = 0;
		}
		
		$sql="select * from eruyi_app where name='$name'";
		$query=$db->query($sql);
		$have=$db->fetch_array($query);
		if($have){
			echo "<script>alert('失败：应用已存在');</script>";
		}else{
			$key = md5(time());
			$sql="INSERT INTO `eruyi_app`(
			`name`,`key`,`charge`,`ipon`,`codeon`,`check_code`,`many_code`,`reg_award`,`inv_award`,`diary_award`,
			`reg_vip`,`reg_fen`,`inv_vip`,`inv_fen`,`diary_vip`,`diary_fen`,`app_bb`,`pay_url`,`pay_appid`,`pay_appkey`,
			`pay_notify`,`pay_state`,`pay_zfb`,`pay_wx`,`pay_qq`,`pay_zfb_state`,`pay_wx_state`,`pay_qq_state`) VALUES (
			'$name','$key','$charge','$ipon','$codeon','$check_code','$many_code','$reg_award','$inv_award','$diary_award',
			'$reg_vip','$reg_fen','$inv_vip','$inv_fen','$diary_vip','$diary_fen','$app_bb','$pay_url','$pay_appid','$pay_appkey',
			'$pay_notify','$pay_state','$pay_zfb','$pay_wx','$pay_qq','$pay_zfb_state','$pay_wx_state','$pay_qq_state')";
			$query=$db->query($sql);
			if($query){
				echo "<script>alert('应用创建成功');</script>";
			}
		}
	}
}

?>
	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>添加应用</h3>
				</div>
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					<div class="control-group">
						<label class="control-label" for="name_label">应用名称:</label>
						<div class="controls">
							<input type="text" name="app_name" id="app_name" placeholder="应用名称.." value="" class="span8">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="bb_label">应用版本:</label>
						<div class="controls">
							<input type="text" name="app_bb" id="app_bb" placeholder="1.0.0" value="">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">运营模式:</label>
						<div class="controls">
							<label class="radio inline">
							<input type="radio" name="charge" id="charge" value="y" checked="">收费模式</label> 
							<label class="radio inline">
							<input type="radio" name="charge" id="charge" value="n">免费模式</label> 
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">设备校验:</label>
						<div class="controls">
							<label class="radio inline">
							<input onchange="code_change(0)" type="radio" name="check_code" id="check_code" value="y" checked="">开启</label> 
							<label class="radio inline">
							<input onchange="code_change(1)" type="radio" name="check_code" id="check_code" value="n">关闭</label> 
						</div>
					</div>
					<div class="view" name="code_c" id="code_c" >
						<div class="control-group"></div>
						<div class="control-group">
							<label class="control-label">多设备登入:</label>
							<div class="controls">
								<label class="radio inline">
								<input type="radio" name="many_code" id="many_code" value="y">开启</label> 
								<label class="radio inline">
								<input type="radio" name="many_code" id="many_code" value="n" checked="">关闭</label> 
							</div>
						</div>
						
					</div>
					<div class="control-group"></div>
					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<strong>提示：</strong> 开启设备校验之后，用户登入时会校验上次登入的设备是否一致，可防止VIP账号一人多用
					</div>
					<div class="control-group">
						<label class="control-label" for="ipon_label">同一IP注册间隔:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="ipon" id="ipon" placeholder="0" value="" class="span8"><span class="add-on">小时</span>
							</div>
						</div>
					</div>
					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<strong>提示：</strong> 可有效防止同一个IP在设置的时间间隔内无法再进行注册，0为不限制
					</div>
					<div class="control-group">
						<label class="control-label" for="codeon_label">同一机器注册间隔:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="codeon" id="codeon" placeholder="0" value="" class="span8"><span class="add-on">小时</span>
							</div>
						</div>
					</div>
					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<strong>提示：</strong> 可有效防止同一个机器在设置的时间间隔内无法再进行注册，0为不限制
					</div>
					<div class="control-group">
						<label class="control-label" for="type" id="reg_label">注册奖励:</label>
						<div class="controls">
							<select name="reg_award" id="reg_award" onchange="change()">
								<option value="vip">会员</option>
								<option value="fen">积分</option>
								<input style="margin-left: 2px;" type="text" name="reg_value" id="reg_value" placeholder="0" value="">
							</select>
						</div>
					</div>

					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<div class="view" name="reg_vip_c" id="reg_vip_c" style="display: block;">
							<strong>提示：</strong> 新注册的用户获得VIP体验时间。奖励单位：<strong>分钟</strong>，0为不奖励
						</div>	
						<div class="view" name="reg_fen_c" id="reg_fen_c">
							<strong>提示：</strong> 新注册的用户获得积分奖励。0为不奖励
						</div>
					</div>
					
					<div class="control-group">
						<label class="control-label" for="type" id="inv_label">邀请奖励:</label>
						<div class="controls">
							<select name="inv_award" id="inv_award" onchange="change()">
								<option value="vip">会员</option>
								<option value="fen">积分</option>
								<input style="margin-left: 2px;" type="text" name="inv_value" id="inv_value" placeholder="0" value="">
							</select>
						</div>
					</div>
					
					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<div class="view" name="inv_vip_c" id="inv_vip_c" style="display: block;">
							<strong>提示：</strong> 邀请用户注册邀请者获得VIP时间奖励。奖励单位：<strong>小时</strong>，0为不奖励
						</div>	
						<div class="view" name="inv_fen_c" id="inv_fen_c">
							<strong>提示：</strong> 邀请用户注册邀请者获得积分奖励。0为不奖励
						</div>
					</div>	
					
					<div class="control-group">
						<label class="control-label" for="type" id="type_label">签到奖励:</label>
						<div class="controls">
							<select name="diary_award" id="diary_award" onchange="change()">
								<option value="vip">会员</option>
								<option value="fen">积分</option>
								<input style="margin-left: 2px;" type="text" name="diary_value" id="diary_value" placeholder="0" value="">
							</select>
						</div>
					</div>

					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<div class="view" name="diary_vip_c" id="diary_vip_c" style="display: block;">
							<strong>提示：</strong> 用户每天进行签到获得VIP时间奖励。奖励单位：<strong>分钟</strong>，0为关闭签到功能且不奖励
						</div>	
						<div class="view" name="diary_fen_c" id="diary_fen_c">
							<strong>提示：</strong> 用户每天进行签到获得积分奖励。0为关闭签到功能且不奖励
						</div>
					</div>	
					
					<div class="control-group">
						<label class="control-label">支付状态:</label>
						<div class="controls">
							<label class="radio inline">
							<input onchange="pay_change(0)" type="radio" name="pay_state" id="pay_state" value="y" >开启</label> 
							<label class="radio inline">
							<input onchange="pay_change(1)" type="radio" name="pay_state" id="pay_state" value="n" checked="checked" >关闭</label> 
						</div>
					</div>
					<div class="view" name="pay_c" id="pay_c">
						<div class="control-group">
						</div>
						<div class="control-group">
							<label class="control-label" for="pay_appid_label">请求地址:</label>
							<div class="controls">
								<input  type="text" name="pay_url" id="pay_url" placeholder="支持所有易支付平台，支付请求地址" value="" class="span8 tip">
								<a href="http://pay.muitc.com" target="_black"><u>商户申请</u></a>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="pay_appid_label">商户ID:</label>
							<div class="controls">
								<input  type="text" name="pay_appid" id="pay_appid" placeholder="支持所有易支付平台，商户ID" value="" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="pay_appkey_label">商户密钥:</label>
							<div class="controls">
								<input  type="text" name="pay_appkey" id="pay_appkey" placeholder="支持所有易支付平台，商户秘钥/KEY" value="" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="pay_notify_label">充值地址:</label>
							<div class="controls">
								<input  type="text" name="pay_notify" id="pay_notify" placeholder="http://域名/notify.php" value="" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">支付宝支付方式:</label>
							<div class="controls">
								<label class="radio inline">
								<input onchange="zfb_change(0)" type="radio" name="pay_zfb_state" id="pay_zfb_state" value="y" checked="checked" >开启</label> 
								<label class="radio inline">
								<input onchange="zfb_change(1)" type="radio" name="pay_zfb_state" id="pay_zfb_state" value="n" >关闭</label> 
							</div>
						</div>
						<div class="view" name="zfb_c" id="zfb_c" style="display: block;">
							<label class="control-label" for="pay_zfb_label">支付方式变量:</label>
							<div class="controls">
								<input type="text" name="pay_zfb" id="pay_zfb" placeholder="支付宝支付方式变量" value="alipay"  class="span8 tip">
							</div>
						</div>
						<div class="control-group">
						</div>
						<div class="control-group">
							<label class="control-label">微信支付方式:</label>
							<div class="controls">
								<label class="radio inline">
								<input onchange="wx_change(0)" type="radio" name="pay_wx_state" id="pay_wx_state" value="y" checked="checked" >开启</label> 
								<label class="radio inline">
								<input onchange="wx_change(1)" type="radio" name="pay_wx_state" id="pay_wx_state" value="n" >关闭</label> 
							</div>
						</div>
						<div class="view" name="wx_c" id="wx_c" style="display: block;">
							<label class="control-label" for="pay_wx_label">支付方式变量:</label>
							<div class="controls">
								<input type="text" name="pay_wx" id="pay_wx" placeholder="微信支付方式变量" value="wxpay"  class="span8 tip">
							</div>
						</div>
						<div class="control-group">
						</div>
						<div class="control-group">
							<label class="control-label">QQ支付方式:</label>
							<div class="controls">
								<label class="radio inline">
								<input onchange="qq_change(0)" type="radio" name="pay_qq_state" id="pay_qq_state" value="y" checked="checked" >开启</label> 
								<label class="radio inline">
								<input onchange="qq_change(1)" type="radio" name="pay_qq_state" id="pay_qq_state" value="n" >关闭</label> 
							</div>
						</div>
						<div class="view" name="qq_c" id="qq_c" style="display: block;">
							<label class="control-label" for="pay_qq_label">支付方式变量:</label>
							<div class="controls">
								<input type="text" name="pay_qq" id="pay_qq" placeholder="QQ支付方式变量" value="qqpay"  class="span8 tip">
							</div>
						</div>
					</div>
					
					<div class="control-group">
					</div>
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="确认添加" class="btn btn-success" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('add_user'); 
div.setAttribute("class", "show"); 

function change() {
	if($('#diary_award').val()=='vip'){
		$("#diary_vip_c").css("display", "block");
		$("#diary_fen_c").css("display", "none");
	}else{
		$("#diary_vip_c").css("display", "none");
		$("#diary_fen_c").css("display", "block");
	}
	
	if($('#inv_award').val()=='vip'){
		$("#inv_vip_c").css("display", "block");
		$("#inv_fen_c").css("display", "none");
	}else{
		$("#inv_vip_c").css("display", "none");
		$("#inv_fen_c").css("display", "block");
	}
	
	if($('#reg_award').val()=='vip'){
		$("#reg_vip_c").css("display", "block");
		$("#reg_fen_c").css("display", "none");
	}else{
		$("#reg_vip_c").css("display", "none");
		$("#reg_fen_c").css("display", "block");
	}
}

function code_change(i) {
	if(i=='1'){
		$("#code_c").css("display", "block");
	}else{
		$("#code_c").css("display", "none");
	}
}

function pay_change(i) {
	if(i=='0'){
		$("#pay_c").css("display", "block");
	}else{
		$("#pay_c").css("display", "none");
	}
}

function zfb_change(i) {
	if(i=='0'){
		$("#zfb_c").css("display", "block");
	}else{
		$("#zfb_c").css("display", "none");
	}
}

function wx_change(i) {
	if(i=='0'){
		$("#wx_c").css("display", "block");
	}else{
		$("#wx_c").css("display", "none");
	}
}

function qq_change(i) {
	if(i=='0'){
		$("#qq_c").css("display", "block");
	}else{
		$("#qq_c").css("display", "none");
	}
}
</script> 
<?php 
include_once 'footer.php';
?>