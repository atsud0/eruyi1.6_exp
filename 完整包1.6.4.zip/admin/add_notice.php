<?php
/*
* File：发布公告
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';
 $sql="select * from eruyi_notice where 1";
 $queryc=$db->query($sql);
 $nums=$db->num_rows($queryc);
 $enums=5;  //每页显示的条目数 
 $page=isset($_GET['page']) ? intval($_GET['page']) : 1;
 $url="add_notice.php?page=";
 $bnums=($page-1)*$enums;
 $content = isset($_POST['content']) ? addslashes($_POST['content']) : '';
 $appid = isset($_POST['appid']) ? addslashes($_POST['appid']) : '';
 $time = time();

$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
if($submit){
	if($content == ''){
		echo "<script>alert('请填写发布的通知内容');</script>";
	}else if($appid == ''){
		echo "<script>alert('请先创建应用');location.href='add_app.php';</script>";
	}	
	if($content != '' && $appid != ''){
		$sql="INSERT INTO `eruyi_notice`(`adm`, `content`, `appid`, `time`) VALUES ('管理员','$content','$appid','$time')";
		$query=$db->query($sql);
		if($query){
			echo "<script>alert('添加成功');</script>";
		}
	}
}
$del_submit = isset($_POST['del_submit']) ? addslashes($_POST['del_submit']) : '';
$del_id = isset($_POST['del_id']) ? addslashes($_POST['del_id']) : '';
 if($del_submit || $del_id != ''){
	$sql="DELETE FROM `eruyi_notice` WHERE `id`= $del_id";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
 }
?>

<div class="span9">
	<div class="content">
		<div class="module">
			<div class="module-head">
				<h3>公告通知</h3>
			</div>
			<div class="module-body">
				<form action="" method="post" id="addimg" name="addimg">
				<div id="post">
					<div class="stream-composer media">
						<a class="media-avatar medium pull-left">
							<img src="<?php echo $adm_pic; ?>">
						</a>
						<div class="media-body">
							<div class="row-fluid">
								<textarea name="content" id="content" placeholder="在这里填写你要通知的内容.." class="span12" style="height: 70px; resize: none;"></textarea>
							</div>
							<div class="clearfix">
								
								<div class="controls" id="post_button">
									<input type="submit" name="submit" value="确认发布" class="btn btn-success pull-right" />
								</div>
								<div class="controls">
									<label class="pull-left" style="margin:5px;">应用选择：</label>
									<select name="appid" id="appid" >
										<?php
											$sql="select * from eruyi_app where 1";
											$query=$db->query($sql);
											while($rows=$db->fetch_array($query)){
										?>
										<option value="<?php echo $rows['id']; ?>"><?php echo $rows['name']; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div>
					</div>
				</div>
				</form>
				<div class="stream-list">
					<?php
						$sql="select * from eruyi_notice where 1 order by id desc limit $bnums,$enums";
						$query=$db->query($sql);
						while($rows=$db->fetch_array($query)){
					?>
					<div class="media stream">
						<a href="#" class="media-avatar medium pull-left">
							<img src="<?php echo $adm_pic; ?>">
						</a>
						<div class="media-body">
							<div class="stream-headline">
								<h5 class="stream-author">
									<?php echo $rows['adm']; ?>
									<small><?php echo gmdate("Y-m-d H:i:s",$rows['time']+8*3600); ?></small>
								</h5>
								<div class="stream-text">
									<?php echo $rows['content']; ?>
								</div>
							</div><!--/.stream-headline-->
							<div class="stream-options">
								<?php
									$tmp_sql="select * from eruyi_app where `id` = '".$rows['appid']."'";
									$tmp_query=$db->query($tmp_sql);
									$have=$db->fetch_array($tmp_query);
								?>
								<code>
									<i class="icon-briefcase shaded"></i>
									<?php echo $have['name']; ?>
								</code>
								<form action="" method="post" id="addimg" name="addimg">
									<input type="hidden" name="del_id" id="del_id" value="<?php echo $rows['id']; ?>">
									<div align="right" style="margin-top:-25px">
										<div class="controls" id="post_button">
											<input type="submit" name="del_submit" value="删除" class="btn btn-small btn-danger" />
										</div>
									</div>
								</form>
							</div>
						</div>
					</div><!--/.media .stream-->
					<?php } ?>
					<?php if($nums > $enums){ ?>
					<div class="module-foot">
						<div class="pagination pagination-centered"><?php echo pagination($nums,$enums,$page,$url); ?></div>
					</div>	
					<?php }; ?>
					<!--<div class="media stream load-more">
						<a href="add_notice.php">
						
						<i class="icon-refresh shaded"></i>
							刷新...
						</a>
					</div>-->
				</div><!--/.stream-list-->
			</div><!--/.module-body-->
		</div><!--/.module-->
		
	</div><!--/.content-->
</div><!--/.span9-->
<script> 
function delsubmit(){
	var delform = document.getElementById("form_log");
	delform.submit();
}
var div = document.getElementById('add_notice'); 
div.setAttribute("class", "show"); 
</script> 
<?php 
include_once 'footer.php';
?>