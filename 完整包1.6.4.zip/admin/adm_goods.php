<?php
/*
* File：管理商品
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

 $sql="SELECT * FROM `eruyi_goods` where 1";
 $queryc=$db->query($sql);
 $nums=$db->num_rows($queryc);
 $enums=30;  //每页显示的条目数 
 $page=isset($_GET['page']) ? intval($_GET['page']) : 1;
 $av_url = $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"]);
 $url="adm_goods.php?page=";
 $bnums=($page-1)*$enums;
 
 $ids = isset($_POST['ids']) ? $_POST['ids'] : '';
 if($ids){
	$idss = '';
	foreach ($ids as $value) {
		$idss .= $value.",";
	}
	$idss = rtrim($idss, ",");
	$sql="DELETE FROM `eruyi_goods` WHERE `id` in ($idss)";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
 }
?>
<div class="span9">
        <div class="module message">
            <div class="module-head">
                <h3>商品列表</h3>
            </div>
            <div class="module-option clearfix">
                <div class="pull-left">
                    <div class="btn-group">
                        <form class="navbar-search pull-left input-append" action="adm_goods.php" method="post" name="sapp" id="sapp">
						<input type="text" class="span3" name="g_name" placeholder="请输入要搜索的商品名称..">
						<button class="btn" type="submit">
							<i class="icon-search"></i>
						</button>
						</form>
                    </div>
				</div>
            </div>
			<form action="" method="post" name="form_log" id="form_log">
            <div class="module-body table">
                <table class="table table-message">
                <tbody>
                <tr>
				<th><input type="checkbox" onclick="checkAll();" class="ids" id="all"/></th>
				<th><b>名称</b></th>
				<th><b>应用</b></th>
				<th><b>金额</b></th>
				<th><b>订单</b></th>
				<th><b>类型</b></th>
				<th><b>状态</b></th>
				<th><b>设置</b></th>
				</tr>
                </tbody>
				<tbody>
				<?php
					$g_name = isset($_POST['g_name']) ? addslashes(trim($_POST['g_name'])) : '';
					if($g_name != ''){
					$sql="select * from eruyi_goods where g_name='$g_name' order by id desc limit $bnums,$enums";
					}else{
					$sql="select * from eruyi_goods where 1 order by id desc limit $bnums,$enums";
					}
					$query=$db->query($sql);
					while($rows=$db->fetch_array($query)){
				?>
				<tr>
				<td><input type="checkbox" name="ids[]" value="<?php echo $rows['id']; ?>" class="ids" /></td>
				<td><?php echo $rows['g_name']; ?></td>
				<?php
					$tmp_sql="select * from eruyi_app where `id` = '".$rows['appid']."'";
					$tmp_query=$db->query($tmp_sql);
					$have=$db->fetch_array($tmp_query);
				?>
				<td><?php echo $have['name']; ?></td>
				<td><?php echo $rows['g_money']; ?></td>
				<?php 
				$tmp_sql="SELECT count(*) FROM `eruyi_order` where `g_id` = '".$rows['id']. "'";
				$tmp_query = $db->query($tmp_sql);
				$tmp_have = $db->fetch_array($tmp_query);
				$total_s = $tmp_have['count(*)'];//订单数
				?>
				<td><?php echo $total_s; ?></td>
				<td><?php if($rows['g_type']=='vip'):?>会员<?php else: ?>积分<?php endif; ?></td>
				<td><?php if($rows['g_state']=='y'):?><font color=green>正常<?php else: ?><font color=red>停售<?php endif; ?></font></td>
				<td><a href="edit_goods.php?id=<?php echo $rows['id']; ?>" target="_self">设置</a></td>
				</tr>
				<?php } ?>
				</tbody>
                </table>
            </div>
            <div class="module-foot">
				<div class="list_footer">
					选中项：<a href="javascript:void(0);" onclick="delsubmit()" class="care">删除</a>
				</div>
				<?php if($nums > $enums){ ?>
					<div class="pagination pagination-centered"><?php echo pagination($nums,$enums,$page,$url); ?></div>
				<?php }; ?>
            </div>
			</form>
        </div>
    </div>
<script>
function checkAll() {
    var code_Values = document.getElementsByTagName("input");
	var all = document.getElementById("all");
    if (code_Values.length) {
        for (i = 0; i < code_Values.length; i++) {
            if (code_Values[i].type == "checkbox") {
                code_Values[i].checked = all.checked;
            }
        }
    } else {
        if (code_Values.type == "checkbox") {
            code_Values.checked = all.checked;
        }
    }
}
function delsubmit(){
	var delform = document.getElementById("form_log");
	delform.submit();
}
var div = document.getElementById('adm_goods'); 
div.setAttribute("class", "show"); 
</script>
<?php 
include_once 'footer.php';
?>