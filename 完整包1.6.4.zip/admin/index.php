﻿<?php
/*
* File：后台首页
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/
require_once 'globals.php';
include_once 'header.php';
$domain = $_SERVER['SERVER_NAME'];
$serverapp = $_SERVER['SERVER_SOFTWARE'];
$mysql_ver = $db->getMysqlVersion();
$php_ver = PHP_VERSION;
$uploadfile_maxsize = ini_get('upload_max_filesize');
if (function_exists("imagecreate")) {
	if (function_exists('gd_info')) {
		$ver_info = gd_info();
		$gd_ver = $ver_info['GD Version'];
	} else{
		$gd_ver = '支持';
	}
} else{
	$gd_ver = '不支持';
}
$tmp_sql="SELECT count(*) FROM `eruyi_user`";
$tmp_query = $db->query($tmp_sql);
$tmp_have = $db->fetch_array($tmp_query);
$user_s = $tmp_have['count(*)'];//用户数

$tmp_sql="SELECT count(*) FROM `eruyi_app`";
$tmp_query = $db->query($tmp_sql);
$tmp_have = $db->fetch_array($tmp_query);
$app_s = $tmp_have['count(*)'];//用户数

$tmp_sql="select sum(`money`) from `eruyi_order` where `state` != '0' order by `id` desc";
$tmp_query = $db->query($tmp_sql);
$tmp_have = $db->fetch_array($tmp_query);
$pay_s = $tmp_have['sum(`money`)'];//收益
if($pay_s == ''){
	$pay_s=0.00;
}
$d_bb = 1.6;//当前系统版本
?>

    <div class="span9">
        <div class="content">
            <div class="btn-controls">
                <div class="btn-box-row row-fluid">
                    <a href="adm_app.php" class="btn-box big span4"><i class=" icon-briefcase"></i><b><?php echo $app_s; ?></b>
                        <p class="text-muted">应用数</p>
                    </a><a href="adm_user.php" class="btn-box big span4"><i class="icon-user"></i><b><?php echo $user_s; ?></b>
                        <p class="text-muted">用户数</p>
                    </a><a href="goods_order.php" class="btn-box big span4"><i class="icon-money"></i><b><?php echo $pay_s; ?></b>
                        <p class="text-muted">总收益</p>
                    </a>
                </div>
            </div>
            <!--/#btn-controls-->
            <div class="module">
                <div class="module-head">
                    <h3>服务器信息</h3>
                </div>	
                <div class="module-body">
                    <div class="chart inline-legend grid">
						<p>当前版本：<?php echo $d_bb; ?>&nbsp;&nbsp;&nbsp;<a  href="javascript:void(0);" onclick="get_bb(<?php echo $d_bb; ?>)" >检查更新</a></p>
						<p>当前域名：<?php echo $domain; ?></p>
						<p>PHP版本：<?php echo $php_ver; ?></p>
						<p>MySQL版本：<?php echo $mysql_ver; ?></p>
						<p>服务器环境：<?php echo $serverapp; ?>（<a href="http://idc.ray-o.cn" target="_black"><font color="#FF0000">推荐使用：<u>光环云计算</u></font></a>）</p>
						<p>GD图形处理库：<?php echo $gd_ver; ?></p>
						<p>服务器空间允许上传最大文件：<?php echo $uploadfile_maxsize; ?></p>
						<div id="placeholder2" class="graph" style="height: 55px">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/.content-->
    </div>
    <!--/.span9-->
	
	
<script>
	function get_bb(bb){
    var httpRequest = new XMLHttpRequest();//第一步：建立所需的对象
	httpRequest.open('GET', './bb_check.php?bb='+bb, true);//第二步：打开连接  将请求参数写在url中  ps:"./Ptest.php?name=test&nameone=testone"
	httpRequest.send();//第三步：发送请求  将请求参数写在URL中
	/**
	 * 获取数据后的处理程序
	 */
	httpRequest.onreadystatechange = function () {
		if (httpRequest.readyState == 4 && httpRequest.status == 200) {
			var json = httpRequest.responseText;//获取到json字符串，还需解析
			var obj = JSON.parse(json);
			if(obj.code == 400){
				alert('检测失败');
			}else if(obj.code != 200){
				alert('发现新版本');open(obj.url);
			}else{
				alert('最新版本');
			}
		}
	};
}
</script>
<?php 
include_once 'footer.php';
?>