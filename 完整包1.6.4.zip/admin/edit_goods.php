<?php
/*
* File：编辑商品
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : '';

$sql="select * from eruyi_goods where id=$id";
$query=$db->query($sql);
$row=$db->fetch_array($query);

$g_name = isset($_POST['g_name']) ? addslashes($_POST['g_name']) : '';//商品名称
$g_vip = isset($_POST['g_vip']) ? addslashes($_POST['g_vip']) : '0';//VIP天数
$g_money = isset($_POST['g_money']) ? addslashes($_POST['g_money']) : '0';//商品金额
$appid = isset($_POST['appid']) ? addslashes($_POST['appid']) : '';//APPid
$g_type = isset($_POST['g_type']) ? addslashes($_POST['g_type']) : 'vip';//商品类型
$g_fen = isset($_POST['g_fen']) ? addslashes($_POST['g_fen']) : '0';//积分
$g_state = isset($_POST['g_state']) ? addslashes($_POST['g_state']) : 'y';//商品状态
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
$adopt = true;
if($submit){
	if($g_name == ''){
		echo "<script>alert('请输入商品名称');</script>";
		$adopt = false;
	}else if($g_money <= 0){
		echo "<script>alert('请输入商品金额');</script>";
		$adopt = false;
	}else if($g_type == 'vip'){
		if($g_vip <= 0){
			echo "<script>alert('请输入VIP天数');</script>";
			$adopt = false;
		}
	}else if($g_type == 'fen'){		
		if($g_fen <= 0){
			echo "<script>alert('请输入积分数');</script>";
			$adopt = false;
		}
	}
	if($adopt == true){
		$sql="UPDATE `eruyi_goods` SET `g_name`='$g_name',`g_vip`='$g_vip',`g_fen`='$g_fen',`g_money` = '$g_money',`appid`='$appid',`g_type`='$g_type',`g_state`='$g_state' WHERE id=$id";
		$query=$db->query($sql);
		if($query){
			echo "<script>alert('编辑成功');location.href='edit_goods.php?id=".$id."';</script>";
		}else{
			echo "<script>alert('编辑失败');</script>";
		}
	}
}
?>
<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>商品详情</h3>
				</div>
				
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					<div class="control-group">
						<label class="control-label" for="name_label">商品ID:</label>
						<div class="controls">
							<input type="text" id="fenid" value="<?php echo $id;?>" disabled>
							<span class="help-inline"><a href="javascript:void(0);" onclick="copy_id()">复制</a></span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="g_name_label">商品名称:</label>
						<div class="controls">
							<input type="text" name="g_name" id="g_name" placeholder="请填写商品名称.." value="<?php echo $row['g_name']; ?>" class="span8">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="type" id="type_label">商品类型:</label>
						<div class="controls">
							<select name="g_type" id="g_type" onchange="change()">
								<option value="vip" <?php if($row['g_type']=='vip') echo 'selected = "selected"'; ?>>用户会员</option>
								<option value="fen" <?php if($row['g_type']=='fen') echo 'selected = "selected"'; ?>>用户积分</option>
							</select>
						</div>
					</div>
					<div class="control-group">
						<div class="view" name="vip_c" id="vip_c" <?php if($row['g_type']=='vip') echo 'style="display: block;"'; ?>>
							<label class="control-label" for="vip_label">会员天数:</label>
							<div class="controls">
								<div class="input-append">
									<input type="text" name="g_vip" id="g_vip" placeholder="会员天数" value="<?php echo $row['g_vip']; ?>" class="span8"><span class="add-on">天</span>
								</div>
							</div>
						</div>
						<div class="view" name="fen_c" id="fen_c" <?php if($row['g_type']=='fen') echo 'style="display: block;"'; ?>>
							<label class="control-label" for="fen_label">用户积分:</label>
							<div class="controls">
								<div class="input-append">
									<input type="text" name="g_fen" id="g_fen" placeholder="0" value="<?php echo $row['g_fen']; ?>" class="span8"><span class="add-on">积分</span>
								</div>
							</div>
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="money">商品金额:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="g_money" id="g_money" placeholder="0.00" value="<?php echo $row['g_money']; ?>" class="span8"><span class="add-on">$</span>
							</div>
						</div>
					</div>
					
					
					<div class="control-group">
						<label class="control-label">商品状态:</label>
						<div class="controls">
							<label class="radio inline">
							<input type="radio" name="g_state" id="g_state" value="y" <?php if($row['g_state']=='y') echo 'checked=""'; ?>>正常</label> 
							<label class="radio inline">
							<input type="radio" name="g_state" id="g_state" value="n" <?php if($row['g_state']=='n') echo 'checked=""'; ?>>停售</label> 
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="type" id="type_label">应用选择:</label>
						<div class="controls">
							<select name="appid" id="appid" class="span8">
								<?php
									$sql="select * from eruyi_app where 1";
									$query=$db->query($sql);
									while($rows=$db->fetch_array($query)){
								?>
								<option value="<?php echo $rows['id']; ?>" <?php if($row['appid'] == $rows['id']) echo 'selected = "selected"'; ?>><?php echo $rows['name']; ?></option>
								<?php } ?>
							</select>
						</div>
					</div>
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="确认修改" class="btn btn-success" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('edit_goods'); 
div.setAttribute("class", "show"); 
function inp(data) {
    console.log(data.value)
}
// 复制到剪切板
function copy_id(){
    var Url2="<?php echo $id;?>";
    var oInput = document.createElement('input');
    oInput.value = Url2;
    document.body.appendChild(oInput);
    oInput.select(); // 选择对象
    document.execCommand("Copy"); // 执行浏览器复制命令
    oInput.className = 'oInput';
    oInput.style.display='none';
    alert('复制成功');
}

function change() {
	if($('#g_type').val()=='vip'){
		$("#vip_c").css("display", "block");
		$("#fen_c").css("display", "none");
	}else{
		$("#vip_c").css("display", "none");
		$("#fen_c").css("display", "block");
	}
}
</script>
<?php 
include_once 'footer.php';
?>