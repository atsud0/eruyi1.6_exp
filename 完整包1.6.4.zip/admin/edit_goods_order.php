<?php
/*
* File：编辑商品
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : '';

$sql="select * from eruyi_order where id=$id";
$query=$db->query($sql);
$row=$db->fetch_array($query);

?>
	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>商品订单详情 ID:<?php echo $id;?></h3>
				</div>
				
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					<div class="control-group">
						<label class="control-label" for="g_name_label">积分事件名称:</label>
						<div class="controls">
							<?php
								$tmp_sql="select * from eruyi_fen where `id` = '".$row['fen_id']."'";
								$tmp_query=$db->query($tmp_sql);
								$have=$db->fetch_array($tmp_query);
							?>
							<input type="text" value="<?php echo $have['fen_name']; ?>" class="span8" disabled>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="g_name_label">事件用户:</label>
						<div class="controls">
							<input type="text" value="<?php echo $row['user']; ?>" class="span8" disabled>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="fen_label">事件积分:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" placeholder="0.00" value="<?php echo $row['fen_money'];?>" class="span8" disabled><span class="add-on">分</span>
							</div>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="g_name_label">事件应用:</label>
						<div class="controls">
							<?php
								$sql="select * from eruyi_app where id = '".$row['appid']."'";
								$query=$db->query($sql);
								$rows=$db->fetch_array($query)
							?>
							<input type="text" value="<?php echo $rows['name']; ?>" class="span8" disabled>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="g_name_label">事件时间:</label>
						<div class="controls">
							<input type="text" value="<?php echo gmdate("Y-m-d H:i:s",$row['fen_time']+8*3600); ?>" class="span8" disabled>
						</div>
					</div>
					
					<div class="control-group">
						<label class="control-label" for="basicinput">事件标记:</label>
						<div class="controls">
							<textarea class="span8" rows="5" disabled><?php echo $row['mark']; ?></textarea>
						</div>
					</div>
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="返回" class="btn btn-success" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('edit_goods'); 
div.setAttribute("class", "show"); 
function inp(data) {
    console.log(data.value)
}
</script>
<?php 
include_once 'footer.php';
?>