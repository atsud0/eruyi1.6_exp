<?php
/*
* File：管理订单
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

 $sql="SELECT * FROM `eruyi_order` where 1";
 $queryc=$db->query($sql);
 $nums=$db->num_rows($queryc);
 $enums=30;  //每页显示的条目数 
 $page=isset($_GET['page']) ? intval($_GET['page']) : 1;
 $av_url = $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"]);
 $url="goods_order.php?page=";
 $bnums=($page-1)*$enums;
 
 $ids = isset($_POST['ids']) ? $_POST['ids'] : '';
 if($ids){
	$idss = '';
	foreach ($ids as $value) {
		$idss .= $value.",";
	}
	$idss = rtrim($idss, ",");
	$sql="DELETE FROM `eruyi_order` WHERE `id` in ($idss)";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
 }
?>
<div class="span9">
        <div class="module message">
            <div class="module-head">
                <h3>订单列表</h3>
            </div>
            <div class="module-option clearfix">
                <div class="pull-left">
                    <div class="btn-group">
                        <form class="navbar-search pull-left input-append" action="goods_order.php" method="post" name="sapp" id="sapp">
						<input type="text" class="span3" name="order" placeholder="请输入要搜索的订单号..">
						<button class="btn" type="submit">
							<i class="icon-search"></i>
						</button>
						</form>
                    </div>
				</div>
            </div>
			<form action="" method="post" name="form_log" id="form_log">
            <div class="module-body table">
                <table class="table table-message">
                <tbody>
                <tr>
				<th><input type="checkbox" onclick="checkAll();" class="ids" id="all"/></th>
				<th><b>订单号</b></th>
				<th><b>名称</b></th>
				<th><b>用户</b></th>
				<th><b>金额</b></th>
				<th><b>时间</b></th>
				<th><b>支付方式</b></th>
				<th><b>状态</b></th>
				<!--<th><b>详情</b></th>-->
				</tr>
                </tbody>
				<tbody>
				<?php
					$order = isset($_POST['order']) ? addslashes(trim($_POST['order'])) : '';
					if($order != ''){
						$sql="select * from eruyi_order where `order`='$order' order by id desc";
					}else{
						$sql="select * from eruyi_order where 1 order by id desc limit $bnums,$enums";
					}
					$query=$db->query($sql);
					while($rows=$db->fetch_array($query)){
				?>
				<tr>
				<td><input type="checkbox" name="ids[]" value="<?php echo $rows['id']; ?>" class="ids" /></td>
				<td><?php echo $rows['order']; ?></td>
				<td><?php echo $rows['g_name']; ?></td>
				<td><?php echo $rows['user']; ?></td>
				<td><?php echo $rows['money']; ?></td>
				<td><?php echo gmdate("Y-m-d H:i:s",$rows['o_time']+8*3600); ?></td>
				<td><?php if($rows['pay_type']=='zfb'){
								echo '支付宝'; 
							}else if ($rows['pay_type']=='wx'){
								echo '微信'; 
							}else{
							echo 'QQ钱包'; 
							}
					?>
				</td>
				<td><?php if($rows['state']=='0'){
								echo '<font color=#FFD700>等待支付</font>'; 
							}else if ($rows['state']=='2'){
								echo '<font color=#00CD00>已支付</font>'; 
							}else if ($rows['state']=='1'){
								echo '<font color=red>充值失败</font>'; 
							}else if ($rows['state']=='3'){
								echo '<font color=red>未知用户</font>'; 
							}else if ($rows['state']=='4'){
								echo '<font color=red>已是永久会员</font>'; 
							}else{
								echo '<font color=red>未知错误</font>'; 
							}
					?>
				</td>
				<!--<td><a href="#" target="_self">查看</a></td>-->
				</tr>
				<?php } ?>
				</tbody>
                </table>
            </div>
            <div class="module-foot">
				<div class="list_footer">
					选中项：<a href="javascript:void(0);" onclick="delsubmit()" class="care">删除</a>
				</div>
				<?php if($nums > $enums){ ?>
					<div class="pagination pagination-centered"><?php echo pagination($nums,$enums,$page,$url); ?></div>
				<?php }; ?>
            </div>
			</form>
        </div>
    </div>
<script>
function checkAll() {
    var code_Values = document.getElementsByTagName("input");
	var all = document.getElementById("all");
    if (code_Values.length) {
        for (i = 0; i < code_Values.length; i++) {
            if (code_Values[i].type == "checkbox") {
                code_Values[i].checked = all.checked;
            }
        }
    } else {
        if (code_Values.type == "checkbox") {
            code_Values.checked = all.checked;
        }
    }
}
function delsubmit(){
	var delform = document.getElementById("form_log");
	delform.submit();
}
var div = document.getElementById('goods_order'); 
div.setAttribute("class", "show"); 
</script>
<?php 
include_once 'footer.php';
?>