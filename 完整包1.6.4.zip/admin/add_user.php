<?php
/*
* File：添加用户
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$user = isset($_POST['user']) ? addslashes($_POST['user']) : '';
$password = isset($_POST['password']) ? addslashes($_POST['password']) : '';
$superpass = isset($_POST['superpass']) ? addslashes($_POST['superpass']) : '';
$fen = isset($_POST['fen']) ? intval($_POST['fen']) : 0;
$lock = isset($_POST['lock']) ? intval($_POST['lock']) : 0;
$regdate = time();
$regip = isset($_POST['regip']) ? addslashes($_POST['regip']) : '127.0.0.1';
$markcode = isset($_POST['markcode']) ? addslashes($_POST['markcode']) : '';
$vip = isset($_POST['vip']) ? addslashes($_POST['vip']) : '0';
$appid = isset($_POST['appid']) ? addslashes($_POST['appid']) : '';
$lock_t = isset($_POST['lock_t']) ? addslashes($_POST['lock_t']) : '';
$lock_show = isset($_POST['lock_show']) ? addslashes($_POST['lock_show']) : '';
//echo strtotime(str_replace("T"," ",$vip));
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
if($submit){
	if($user == ''){
		echo "<script>alert('请填写账号');</script>";
	}else if($password == ''){
		echo "<script>alert('请填写密码');</script>";
	}else if($superpass == ''){
		echo "<script>alert('请填写超级密码');</script>";
	}else if($appid == ''){
		echo "<script>alert('请先创建应用');location.href='add_app.php';</script>";
	}	
	if($user != '' && $password != '' && $superpass != '' && $appid != ''){
		$sql="select * from eruyi_user where user='$user'";
		$query=$db->query($sql);
		$have=$db->fetch_array($query);
		if($have){
			echo "<script>alert('失败：用户名已存在');</script>";
		}else{
			if($lock != 0 and $lock_t != ''){
				$lock = strtotime(str_replace("T"," ",$lock_t));
			}else{
				$lock = 0;
			}
			if($vip != ''){
				$vip = strtotime(str_replace("T"," ",$vip));
			}else{
				$vip = 0;
			}
			$pass = md5($password);
			$sql="INSERT INTO `eruyi_user`(`user`, `password`, `superpass`, `fen`, `regdate`, `regip`, `markcode`,`lock`,`lock_show`,`vip`,`appid`) VALUES ('$user','$pass','$superpass','$fen','$regdate','$regip','$markcode','$lock','$lock_show','$vip','$appid')";
			$query=$db->query($sql);
			if($query){
				echo "<script>alert('添加成功');</script>";
			}
		}
	}
}
?>
	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>添加用户</h3>
				</div>
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					<div class="control-group">
						<label class="control-label" for="user_label">账号:</label>
						<div class="controls">
							<input type="text" name="user" id="user" placeholder="请填写用户账号.." value="" class="span8">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="password_label">密码:</label>
						<div class="controls">
							<input type="text" name="password" id="password" placeholder="请填写用户密码.." value=""  class="span8 tip">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="superpass_label">超级密码:</label>
						<div class="controls">
							<input  type="text" name="superpass" id="superpass" placeholder="请填写用户超级密码.." value=""  class="span8 tip">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="vip_label">会员到期:</label>
						<div class="controls">
							<input type="datetime-local" style="width:248px" name="vip" id="vip" value="">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="fen">账户积分:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="fen" id="fen" placeholder="0" value="" class="span8"><span class="add-on">分</span>
							</div>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">用户状态:</label>
						<div class="controls">
							<label class="radio inline">
							<input onchange="lock_change(0)" type="radio" name="lock" id="lock" value="0" checked="">正常</label> 
							<label class="radio inline">
							<input onchange="lock_change(1)" type="radio" name="lock" id="lock" value="1">禁用</label> 
						</div>
					</div>
					
					<div class="view" name="lock_c" id="lock_c" >
						<div class="control-group">
						</div>
						<div class="control-group">
						</div>
						<label class="control-label" for="lock_label">禁用到期时间:</label>
						<div class="controls">
							<input type="datetime-local" style="width:248px" name="lock_t" id="lock_t" value="<?php echo date("Y-m-d\\TH:m",time()); ?>">
						</div>
						<div class="control-group">
						</div>
						<div class="control-group">
						</div>
						<label class="control-label" for="lock_label">禁用说明:</label>
						<div class="controls">
							<input type="text" name="lock_show" id="lock_show" value="" placeholder="请填写禁用说明" class="span8 tip">
						</div>
					</div>
					<div class="control-group">
					</div>
					<div class="control-group">
						<label class="control-label" for="regip_label">注册IP:</label>
						<div class="controls">
							<input  type="text" name="regip" id="regip" placeholder="请填写注册IP.." value="" class="span8 tip">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="markcode_label">机器码:</label>
						<div class="controls">
							<input  type="text" name="markcode" id="markcode" placeholder="请填写用户机器码.." value="" class="span8 tip">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="type" id="type_label">应用选择:</label>
						<div class="controls">
							<select name="appid" id="appid" class="span8">
								<?php
									$sql="select * from eruyi_app where 1";
									$query=$db->query($sql);
									while($rows=$db->fetch_array($query)){
								?>
								<option value="<?php echo $rows['id']; ?>"><?php echo $rows['name']; ?></option>
								<?php } ?>
							</select>
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="确认添加" class="btn btn-success" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('add_user'); 
div.setAttribute("class", "show"); 

function lock_change(i) {
	if(i=='1'){
		$("#lock_c").css("display", "block");
	}else{
		$("#lock_c").css("display", "none");
	}
}

</script> 
<?php 
include_once 'footer.php';
?>