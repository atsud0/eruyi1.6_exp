<?php
/*
* File：后台登陆
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/
$err = isset($_GET['err']) ? intval($_GET['err']) : 0;
$errmsg = array(null,'账号密码不能为空','账号密码有误','您还没有登陆，请先登录！');
$error_msg = $errmsg[$err];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>后台管理 - 易如意网络验证系统</title>
	<link type="text/css" href="style/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="style/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="style/css/theme.css" rel="stylesheet">
	<link type="text/css" href="style/images/icons/css/font-awesome.css" rel="stylesheet">
	<link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
</head>
<body>

	<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
					<i class="icon-reorder shaded"></i>
				</a>
			  	<a class="brand" href="index.html">
			  		后台管理登入
			  	</a>
				<div class="nav-collapse collapse navbar-inverse-collapse">
					<ul class="nav pull-right">
						<li><a href="../">网站首页</a></li>
					</ul>
				</div><!-- /.nav-collapse -->
			</div>
		</div><!-- /navbar-inner -->
	</div><!-- /navbar -->

	<div class="wrapper">
		<div class="container">
			<div class="row">
				<div class="module module-login span4 offset4">
					<form class="form-vertical" name="f" method="post" action="./index.php?action=login">
						<div class="module-head">
							<h3>登入</h3>
						</div>
						<div class="module-body">
							<div class="control-group">
								<div class="controls row-fluid">
									<input class="span12" type="text" id="inputEmail" placeholder="账号" name="user" value="">
								</div>
							</div>
							<div class="control-group">
								<div class="controls row-fluid">
									<input class="span12" type="password" id="inputPassword" placeholder="密码" name="pw" value="">
								</div>
							</div>
						</div>
						<div class="module-foot">
							<div class="control-group">
								<div class="controls clearfix">
									<button type="submit" class="btn btn-primary pull-right">登入</button>
									<label class="checkbox">
										<input type="checkbox"> 记住我
									</label>
								</div>
								<?php if ($error_msg): ?>
								<div class="login-alert login-alert-error">
									<button type="button" class="close" data-dismiss="login-alert">×</button>
									<strong>提示：</strong> <?php echo $error_msg; ?>
								</div>
								<?php endif;?>
							</div>
						</div>
						
					</form>
				</div>
			</div>
		</div>
	</div><!--/.wrapper-->

	<div class="footer">
		<div class="container">
			<b class="copyright">&copy; 2019 易如意 - eruyi.cn </b> All rights reserved.
		</div>
	</div>
	<script src="style/scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="style/scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="style/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</body>

