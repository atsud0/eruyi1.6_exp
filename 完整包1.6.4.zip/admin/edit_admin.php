<?php
/*
* File：添加应用
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$username = isset($_POST['username']) ? addslashes($_POST['username']) : '';
$password = isset($_POST['password']) ? addslashes($_POST['password']) : '';//限制IP注册
$okpassword = isset($_POST['okpassword']) ? addslashes($_POST['okpassword']) : '';//限制机器码注册

$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
//echo $vip;
if($submit){
	
	if($username == ''){
		echo "<script>alert('失败：请输入账号');</script>";
	}else if($password == ''){
		echo "<script>alert('失败：请输入密码');</script>";
	}else if($okpassword == ''){
		echo "<script>alert('失败：请确认密码');</script>";
	}else if($okpassword != $password){
		echo "<script>alert('失败：密码和确认密码不一致');</script>";
	}else{
		$userdata = file_get_contents('../admin/userdata.php');
        $userdata = preg_replace('/\$user = \'.*?\'/', '$user = \'' . $username . '\'', $userdata);
        $userdata = preg_replace('/\$pass = \'.*?\'/', '$pass = \'' . $password . '\'', $userdata);
		$userdata = preg_replace('/\$cookie = \'.*?\'/', '$cookie = \'' . md5($username.$password.time()) . '\'', $userdata);
        file_put_contents('userdata.php', $userdata);
		echo "<script>alert('修改成功，请重新登入');location.href='./?action=logout';</script>";
	}
	
	
}

?>
	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>修改管理员账号密码:</h3>
				</div>
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					<div class="control-group">
						<label class="control-label" for="name_label">账号:</label>
						<div class="controls">
							<input type="text" name="username" id="username" placeholder="" value="<?php echo $user; ?>">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="bb_label">密码:</label>
						<div class="controls">
							<input type="password" name="password" id="password" placeholder="" value="">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="bb_label">确认密码:</label>
						<div class="controls">
							<input type="password" name="okpassword" id="okpassword" placeholder="" value="">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="确认修改" class="btn btn-success" />
						</div>
					</div>
					<div id="placeholder2" class="graph" style="height: 255px"></div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('edit_admin'); 
div.setAttribute("class", "show"); 
</script> 
<?php 
include_once 'footer.php';
?>