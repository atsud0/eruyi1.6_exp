<?php
/*
* File：管理应用
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

 $sql="select * from eruyi_app where 1";
 $queryc=$db->query($sql);
 $nums=$db->num_rows($queryc);
 $enums=10;  //每页显示的条目数 
 $page=isset($_GET['page']) ? intval($_GET['page']) : 1;
 $url="adm_app.php?page=";
 $bnums=($page-1)*$enums;
 $ids = isset($_POST['ids']) ? $_POST['ids'] : '';
 if($ids){
	$idss = '';
	foreach ($ids as $value) {
		$idss .= $value.",";
	}
	$idss = rtrim($idss, ",");
	$sql="DELETE FROM `eruyi_app` WHERE `id` in ($idss)";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
 }
 

?>

    <div class="span9">
        <div class="module message">
            <div class="module-head">
                <h3>应用列表</h3>
            </div>
            <div class="module-option clearfix">
                <div class="pull-left">
                    <div class="btn-group">
                        <form class="navbar-search pull-left input-append" action="adm_app.php" method="post" name="sapp" id="sapp">
						<input type="text" class="span3" name="name" placeholder="请输入要搜索的应用名称..">
						<button class="btn" type="submit">
							<i class="icon-search"></i>
						</button>
						</form>
                    </div>
				</div>
            </div>
			<form action="" method="post" name="form_log" id="form_log">
            <div class="module-body table">
                <table class="table table-message">
                <tbody>
                <tr>
				<th><input type="checkbox" onclick="checkAll();" class="ids" id="all"/></th>
				<th><b>应用</b></th>
				<th><b>用户量</b></th>
				<th><b>签到数</b></th>
				<th><b>在线</b></th>
				<th><b>开关</b></th>
				<th><b>管理</b></th>
				</tr>
                </tbody>
				<tbody>
				<?php
					$name = isset($_POST['name']) ? addslashes(trim($_POST['name'])) : '';
					if($name != ''){
						$sql="select * from eruyi_app where name='$name' order by id desc limit $bnums,$enums";
					}else{
						$sql="select * from eruyi_app where 1 order by id desc limit $bnums,$enums";
					}
					$query=$db->query($sql);
					while($rows=$db->fetch_array($query)){
				?>
				<tr>
				<td><input type="checkbox" name="ids[]" value="<?php echo $rows['id']; ?>" class="ids" /></td>
				<td><?php if($rows['charge']=='y'):?><font color=red><?php echo $rows['name']; ?></font><?php else: ?><?php echo $rows['name']; ?><?php endif; ?></td>
				<?php 
				$tmp_sql="SELECT count(*) FROM `eruyi_user` where `appid` = '".$rows['id']. "'";
				$tmp_query = $db->query($tmp_sql);
				$tmp_have = $db->fetch_array($tmp_query);
				$total_s = $tmp_have['count(*)'];//用户数
				?>
				<td><?php echo $total_s; ?></td>
				<?php 
				$tmp_sql="SELECT count(*) FROM `eruyi_user` where `appid` = '".$rows['id']. "' and diary between $d_time and $t_day";
				$tmp_query = $db->query($tmp_sql);
				$tmp_have = $db->fetch_array($tmp_query);
				$total_s = $tmp_have['count(*)'];//签到数
				?>
				<td><?php echo $total_s; ?></td>
				<?php 
				$last_time = time();
				$tmp_sql="SELECT count(*) FROM `eruyi_user` where `appid` = '".$rows['id']. "' and last_t > $last_time";
				$tmp_query = $db->query($tmp_sql);
				$tmp_have = $db->fetch_array($tmp_query);
				$total_s = $tmp_have['count(*)'];//在线数
				?>
				<td><?php echo $total_s; ?></td>
				<td><?php if($rows['state']=='y'):?><font color=green>开<?php else: ?><font color=red>关<?php endif; ?></font></td>
				<td><a href="edit_app.php?id=<?php echo $rows['id']; ?>" target="_self">设置</a></td>
				</tr>
				<?php } ?>
				</tbody>
                </table>
            </div>
            <div class="module-foot">
				<div class="list_footer">
					选中项：<a href="javascript:void(0);" onclick="delsubmit()" class="care">删除</a>
				</div>
				<?php if($nums > $enums){ ?>
					<div class="module-foot">
						<div class="pagination pagination-centered"><?php echo pagination($nums,$enums,$page,$url); ?></div>
					</div>	
				<?php }; ?>
            </div>
			</form>
        </div>
    </div>
<script>
function checkAll() {
    var code_Values = document.getElementsByTagName("input");
	var all = document.getElementById("all");
    if (code_Values.length) {
        for (i = 0; i < code_Values.length; i++) {
            if (code_Values[i].type == "checkbox") {
                code_Values[i].checked = all.checked;
            }
        }
    } else {
        if (code_Values.type == "checkbox") {
            code_Values.checked = all.checked;
        }
    }
}
function delsubmit(){
	var delform = document.getElementById("form_log");
	delform.submit();
}
var div = document.getElementById('adm_app'); 
div.setAttribute("class", "show"); 
</script>
<?php 
include_once 'footer.php';
?>