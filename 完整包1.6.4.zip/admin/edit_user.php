<?php
/*
* File：编辑用户
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$uid = isset($_GET['uid']) ? intval($_GET['uid']) : '';
$sql="select * from eruyi_user where uid=$uid";
$query=$db->query($sql);
$row=$db->fetch_array($query);
$name = isset($_POST['name']) ? addslashes($_POST['name']) : '这个人很懒，没有名字';//名称
$fen = isset($_POST['fen']) ? intval($_POST['fen']) : 0;//账号余额
$regip = isset($_POST['regip']) ? addslashes($_POST['regip']) : '';//注册IP
$markcode = isset($_POST['markcode']) ? addslashes($_POST['markcode']) : '';//机器码
$superpass = isset($_POST['superpass']) ? addslashes($_POST['superpass']) : '';//超级密码
$vip = isset($_POST['vip']) ? addslashes($_POST['vip']) : '';//VIP到期时间
$i_inv = isset($_POST['i_inv']) ? addslashes($_POST['i_inv']) : '0';//邀请的人数
$lock = isset($_POST['lock']) ? intval($_POST['lock']) : 0;
$lock_t = isset($_POST['lock_t']) ? addslashes($_POST['lock_t']) : '';
$lock_show = isset($_POST['lock_show']) ? addslashes($_POST['lock_show']) : '';
$appid = isset($_POST['appid']) ? addslashes($_POST['appid']) : '';
$av_url = $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"]);
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';

if($submit){
	if($vip == '永久会员'){
		$vip = '999999999';
	}else if($vip != ''){
		$vip = strtotime(str_replace("T"," ",$vip));
	}
	if($lock != 0 and $lock_t != ''){
		$lock = strtotime(str_replace("T"," ",$lock_t));
	}else{
		$lock = 0;
	}
	$sql="UPDATE `eruyi_user` SET `name`='$name',`fen`='$fen',`regip`='$regip',`superpass`='$superpass',`markcode`='$markcode',`lock`='$lock',`lock_show` = '$lock_show',`vip`= '$vip',`i_inv`= '$i_inv',`appid`= '$appid' WHERE uid=$uid";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('编辑成功');location.href='edit_user.php?uid=".$uid."';</script>";
	}
}
?>
	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>用户信息 ID:<?php echo $uid;?></h3>
				</div>
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					<?php if(strpos($row['pic'],"http")!==false): ?><img src="<?php echo $row['pic']?>" class="avatar"/><?php elseif($row['pic']==''): ?><img src="<?php echo 'http://'.dirname($av_url).'/img/pic/0.png'?>" class="avatar"/><?php else: ?><img src="<?php echo 'http://'.dirname($av_url).$row['pic']?>"  width="60px" height="60px" hspace="40%" vspace="20" /><?php endif; ?>
					<div class="control-group">
						<label class="control-label" for="user_label">账号:</label>
						<div class="controls">
							<input type="text" name="user" id="user" value="<?php echo $row['user'];?>" class="span8" disabled>
							<span class="help-inline"><?php if($row['vip']>time() || $row['vip']=='999999999'): ?> <font color=red>VIP</font><?php endif; ?></span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="name_label">名称:</label>
						<div class="controls">
							<input  type="text" name="name" id="name" value="<?php echo $row['name'];?>"  class="span8 tip">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="superpass_label">超级密码:</label>
						<div class="controls">
							<input  type="text" name="superpass" id="superpass" value="<?php echo $row['superpass'];?>"  class="span8 tip">
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="inv_label">推荐人ID:</label>
						<div class="controls">
							<input type="text" name="inv" id="inv" value="<?php if($row['inv'] == null or $row['inv'] == 0){echo '无';}else{echo $row['inv'];}  ;?>" class="span8" disabled>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="i_inv_label">已邀请人数:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="i_inv" id="i_inv" value="<?php if($row['i_inv'] == null or $row['i_inv'] == 0){echo '0';}else{echo $row['i_inv'];}  ;?>" placeholder="0" class="span8"><span class="add-on">人</span>
							</div>
						</div>
					</div>
					
					<div class="control-group">
						<label class="control-label" for="fen_label">账户积分:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="fen" id="fen" placeholder="0.00" value="<?php echo $row['fen'];?>" class="span8"><span class="add-on">分</span>
							</div>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="vip_label">会员到期:</label>
						<div class="controls">
							<input <?php if($row['vip']=='999999999'){echo 'type="text" value="永久会员" readonly';}else{echo 'type="datetime-local"';}?> style="width:248px" name="vip" id="vip" value="<?php if($row['vip'] > time()){echo date("Y-m-d\\TH:i",$row['vip']);}?>">
							<!--<label class="checkbox inline" style="margin-left:10px;">
							<input type="checkbox" onclick="vip_yj();" name="YJK" id="YJK" value="1" <?php if($row['vip']=='999999999'){echo 'checked="checked"';}?>><div style="margin-left:-5px;">设为永久会员</div></label>-->
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">用户状态:</label>
						<div class="controls">
							<label class="radio inline">
							<input onchange="lock_change(0)" type="radio" name="lock" id="lock" value="0" <?php if($row['lock']<time()){echo 'checked=""';}?>>正常</label> 
							<label class="radio inline">
							<input onchange="lock_change(1)" type="radio" name="lock" id="lock" value="1"<?php if($row['lock']>time()){echo 'checked=""';}?>>禁用</label> 
						</div>
					</div>
					
					<div class="view" name="lock_c" id="lock_c" <?php if($row['lock']>time()):?> style="display: block;"<?php endif; ?>>
						<div class="control-group">
						</div>
						<div class="control-group">
						</div>
						<label class="control-label" for="lock_label">禁用到期时间:</label>
						<div class="controls">
							<input type="datetime-local" style="width:248px" name="lock_t" id="lock_t" value="<?php if($row['lock'] > time()){echo date("Y-m-d\\TH:i",$row['lock']);}?>">
						</div>
						<div class="control-group">
						</div>
						<div class="control-group">
						</div>
						<label class="control-label" for="lock_show_label">禁用说明:</label>
						<div class="controls">
							<input type="text" name="lock_show" id="lock_show" value="<?php echo $row['lock_show'];?>" placeholder="请填写禁用说明" class="span8 tip">
						</div>
					</div>
					<div class="control-group">
					</div>
					<div class="control-group">
						<label class="control-label" for="diary_label">最后签到时间:</label>
						<div class="controls">
							<input  type="text" name="diary" id="diary" placeholder="暂无签到" value="<?php if($row['diary'] > 0){echo gmdate("Y-m-d H:i:s",$row['diary']+8*3600);}else{echo '从未签到';} ?>" class="span8 tip" disabled>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="regdate_label">注册时间:</label>
						<div class="controls">
							<input  type="text" name="regdate" id="regdate" placeholder="没有注册时间.." value="<?php echo gmdate("Y-m-d H:i:s",$row['regdate']+8*3600);?>" class="span8 tip" disabled>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="regip_label">注册IP:</label>
						<div class="controls">
							<input  type="text" name="regip" id="regip" placeholder="没有注册IP" value="<?php echo $row['regip'];?>" class="span8 tip">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="markcode_label">机器码:</label>
						<div class="controls">
							<input  type="text" name="markcode" id="markcode" placeholder="没有机器码" value="<?php echo $row['markcode'];?>" class="span8 tip">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="type" id="type_label">应用选择:</label>
						<div class="controls">
							<select name="appid" id="appid" class="span8">
								<?php
									$sql="select * from eruyi_app where 1";
									$query=$db->query($sql);
									while($rows=$db->fetch_array($query)){
								?>
								<option value="<?php echo $rows['id']; ?>" <?php if($row['appid'] == $rows['id']) echo 'selected = "selected"'; ?>><?php echo $rows['name']; ?></option>
								<?php } ?>
							</select>
							<span class="help-inline">*</span>
						</div>
					</div>
					
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="修改保存" class="btn btn-success" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('edit_user'); 
div.setAttribute("class", "show"); 
function inp(data) {
    console.log(data.value)
}

function lock_change(i) {
	if(i=='1'){
		$("#lock_c").css("display", "block");
	}else{
		$("#lock_c").css("display", "none");
	}
}

</script>
<?php 
include_once 'footer.php';
?>