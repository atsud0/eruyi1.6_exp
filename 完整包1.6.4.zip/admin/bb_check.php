<?php
/*
* File：版本检测
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/
$bb = isset($_GET['bb']) ? addslashes($_GET['bb']) : '0';
if($bb != '' and $bb > 1.0){
	$url = 'https://www.eruyi.cn/eruyi_api.php?act=user&bb='.$bb;
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL,$url);
	curl_setopt($curl, CURLOPT_HEADER,0);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);//禁止调用时就输出获取到的数据
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,false);
	$data = curl_exec($curl);
	curl_close($curl);
	echo $data;
	/*$res = json_decode($data, true);
	$x_code = $res['code'];
	
	if($x_code != 200){
		$x_url = $res['url'];
		echo "<script>alert('发现新版本');location.href='".$x_url."';</script>";
	}else{
		echo "<script>alert('最新版本');</script>";
	}*/
}else{
	$arr = array('code' => 400);
	echo json_encode($arr);
}
exit();

?>