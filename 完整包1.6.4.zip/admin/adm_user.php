<?php
/*
* File：管理用户
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';
 $app_id = isset($_GET['app']) ? addslashes($_GET['app']) : 'all';
 if($app_id != 'all'){
	$sql="select * from eruyi_user where `appid` = '" . $app_id . "'";
 }else{
	$sql="select * from eruyi_user where 1";
 }
 
 $queryc=$db->query($sql);
 $nums=$db->num_rows($queryc);
 $enums=10;  //每页显示的条目数 
 $page=isset($_GET['page']) ? intval($_GET['page']) : 1;
 $url="adm_user.php?page=";
 $bnums=($page-1)*$enums;
 
 $ids = isset($_POST['ids']) ? $_POST['ids'] : '';
 if($ids){
	$idss = '';
	foreach ($ids as $value) {
		$idss .= $value.",";
	}
	$idss = rtrim($idss, ",");
	$sql="DELETE FROM `eruyi_user` WHERE `uid` in ($idss)";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
 }
?>
    <div class="span9">
		<div class="content">
			<div class="module message">
				<div class="module-head">
					<h3>会员列表</h3>
				</div>
				<div class="module-option clearfix">
					<div class="pull-left">
						<label class="pull-left" style="margin:5px;">应用：</label>
						<select onchange="gradeChange(this.value)" name="app" id="app" >
							<option value="all">全部</option>
							<?php
							$sql="select * from eruyi_app where 1";
							$query=$db->query($sql);
							while($rows=$db->fetch_array($query)){
							?>
							<option value="<?php echo $rows['id']; ?>" <?php if($app_id == $rows['id']) echo 'selected = "selected"'; ?>><?php echo $rows['name']; ?></option>
							<?php } ?>
						</select>
					</div>
					<div class="pull-right">
						<form class="navbar-search pull-left input-append" action="adm_user.php" method="post" name="suer" id="suer" >
							<input type="text" name="user" class="span3" placeholder="请输入要搜索的账号..">
							<button class="btn" type="submit">
								<i class="icon-search"></i>
							</button>
						</form>
					</div>
				</div>	
				<form action="" method="post" name="form_log" id="form_log">
				<div class="module-body table">
					<table class="table table-message">
					<tbody>
					<tr>
					<th><input type="checkbox" onclick="checkAll();" class="ids" id="all"/></th>
					<th><b>账号</b></th>
					<th><b>应用</b></th>
					<th><b>状态</b></th>
					<th><b>管理</b></th>
					</tr>
					</tbody>
					<tbody>
					<?php
						$user = isset($_POST['user']) ? addslashes(trim($_POST['user'])) : '';
						if($user != ''){
							$sql="select * from eruyi_user where user='$user' order by uid desc limit $bnums,$enums";
						}else{
							if($app_id == 'all'){
								$sql="select * from eruyi_user where 1 order by uid desc limit $bnums,$enums";
							}else{
								$sql="select * from eruyi_user where `appid` = '" . $app_id . "' order by uid desc limit $bnums,$enums";
							}
						}
						$query=$db->query($sql);
						while($rows=$db->fetch_array($query)){
					?>
					<tr>
					<td><input type="checkbox" name="ids[]" value="<?php echo $rows['uid']; ?>" class="ids" /></td>
					<td><?php if($rows['vip']>time() || $rows['vip']=='999999999'): ?><font color=red><?php echo $rows['user']; ?></font><?php else: ?><?php echo $rows['user']; ?><?php endif; ?></td>
					<?php
						$tmp_sql="select * from eruyi_app where `id` = '".$rows['appid']."'";
						$tmp_query=$db->query($tmp_sql);
						$have=$db->fetch_array($tmp_query);
					?>
					<td><?php echo $have['name']; ?></td>
					<td><?php if($rows['lock']>time()):?><font color=red>禁用<?php else: ?><font color=green>正常<?php endif; ?></font></td>
					<td><a href="edit_user.php?uid=<?php echo $rows['uid']; ?>" target="_self">详情</a></td>
					</tr>
					<?php } ?>
					</tbody>
					</table>
				</div>
				<div class="module-foot">
					<div class="list_footer">
						选中项：<a href="javascript:void(0);" onclick="delsubmit()" class="care">删除</a>
					</div>
					<div align="right" style="margin-top:-20px">用户统计：<?php echo $nums; ?> 人</div>
					<?php if($nums > $enums){ ?>
					<div class="pagination pagination-centered"><?php echo pagination($nums,$enums,$page,$url); ?></div>
					<?php }; ?>
				</div>
				</form>
			</div>
		</div>
    </div>
<script>
function gradeChange(grade){
	location.href='adm_user.php?app=' + grade;
}

function checkAll() {
    var code_Values = document.getElementsByTagName("input");
	var all = document.getElementById("all");
    if (code_Values.length) {
        for (i = 0; i < code_Values.length; i++) {
            if (code_Values[i].type == "checkbox") {
                code_Values[i].checked = all.checked;
            }
        }
    } else {
        if (code_Values.type == "checkbox") {
            code_Values.checked = all.checked;
        }
    }
}
function delsubmit(){
	var delform = document.getElementById("form_log");
	delform.submit();
}
var div = document.getElementById('adm_user'); 
div.setAttribute("class", "show"); 
</script>
<?php 
include_once 'footer.php';
?>