<?php
/*
* File：管理卡密
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';
 $see = isset($_GET['see']) ? addslashes($_GET['see']) : 'all';

if($see == 'nuse'){//未使用
	$sql="select * from eruyi_kami where `new`='y'";
}else if($see == 'used'){//已使用
	$sql="select * from eruyi_kami where `new`='n'";
}else{
	$sql="select * from eruyi_kami where 1";
}

 $queryc=$db->query($sql);
 $nums=$db->num_rows($queryc);
 $enums=10;  //每页显示的条目数 
 $page=isset($_GET['page']) ? intval($_GET['page']) : 1;
 $url="adm_kami.php?page=";
 $bnums=($page-1)*$enums;
 
 $id = isset($_POST['id']) ? $_POST['id'] : '';
 if($id){
	$ids = '';
	foreach ($id as $value) {
		$ids .= $value.",";
	}
	$ids = rtrim($ids, ",");
	$sql="DELETE FROM `eruyi_kami` WHERE `id` in ($ids)";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('删除成功');</script>";
	}
 }
 
 $KMtype = array(
	'fen'=>"积分卡",
	'vip'=>"会员卡",
 );
?>
	<div class="span9">
		<div class="module message">
			<div class="module-head">
				<h3>卡密管理</h3>
			</div>
			<div class="module-option clearfix">
				<div class="pull-left">
					<label class="pull-left" style="margin:5px;">使用状态 : </label>
					<select onchange="gradeChange(this.value)" name="see" id="see" >
						<option value="all" <?php if($see == "all") echo 'selected = "selected"'; ?>>全部</option>
						<option value="nuse" <?php if($see == "nuse") echo 'selected = "selected"'; ?>>未使用</option>
						<option value="used" <?php if($see == "used") echo 'selected = "selected"'; ?>>已使用</option>
					</select>
				</div>
				<div class="pull-right">
					<form class="navbar-search pull-left input-append" action="adm_kami.php" method="post" name="skami" id="skami">
						<input type="text" name="kami" class="span3" placeholder="请输入要搜索的卡密..">
						<button class="btn" type="submit">
							<i class="icon-search"></i>
						</button>
					</form>
				</div>
			</div>
			<form action="" method="post" name="form_log" id="form_log">
			
			<div class="module-body table">								
				<table class="table table-message">
				<tbody>
					<tr>
						<th><input type="checkbox" onclick="checkAll();" class="ids" id="all"/></th>
						<th><b>ID</b></th>
						<th><b>卡密</b></th>
						<th><b>类型</b></th>
						<th><b>状态</b></th>
						<th><b>时间</b></th>
					</tr>
				</tbody>
				<tbody>
					<?php
						$kami = isset($_POST['kami']) ? addslashes(trim($_POST['kami'])) : '';
						if($kami != ''){
							$sql="select * from eruyi_kami where kami='$kami' order by id desc limit $bnums,$enums";
						}else{
							if($see == 'nuse'){//未使用
								$sql="select * from eruyi_kami where `new`='y' order by id desc limit $bnums,$enums";
							}else if($see == 'used'){//已使用
								$sql="select * from eruyi_kami where `new`='n' order by id desc limit $bnums,$enums";
							}else{
								$sql="select * from eruyi_kami where 1 order by id desc limit $bnums,$enums";
							}
						}
						$query=$db->query($sql);
						while($rows=$db->fetch_array($query)){
					?>
					<tr>
						<td><input type="checkbox" name="id[]" value="<?php echo $rows['id']; ?>" class="ids" /></td>
						<td><?php echo $rows['id']; ?></td>
						<td><?php echo $rows['kami']; ?></td>
						<?php if($rows['num'] == 999999999 and $rows['type'] == 'vip'){$k_num = '永久卡';}else{$k_num = $rows['num'];}; ?>
						<td><?php echo $KMtype[$rows['type']].'(<font color=#4876FF>'.$k_num.'</font>)'; ?></td>
						<td><?php if($rows['new']=='n'):?><font color=red><?php echo $rows['user']; ?><?php else: ?><font color=green>可用<?php endif; ?></font></td>
						<td><?php if($rows['new']=='n'): echo gmdate("Y-m-d H:i:s",$rows['date']+8*3600); endif; ?></td>
					</tr>
					<?php
						}
					?>
				</tbody>
				</table>
			</div>
			<div class="module-foot">
				选中项：<a href="javascript:void(0);" onclick="delsubmit()" class="care">删除</a><!-- &nbsp; <a href="javascript:void(0);" onclick="outsubmit()" class="care">导出</a>-->
				<?php if($nums > $enums){ ?>
					<div class="pagination pagination-centered"><?php echo pagination($nums,$enums,$page,$url); ?></div>
				<?php }; ?>
			</div>
			</form>
		</div>	
	</div><!--/.span9-->

<script>
function checkAll() {
    var code_Values = document.getElementsByTagName("input");
	var all = document.getElementById("all");
    if (code_Values.length) {
        for (i = 0; i < code_Values.length; i++) {
            if (code_Values[i].type == "checkbox") {
                code_Values[i].checked = all.checked;
            }
        }
    } else {
        if (code_Values.type == "checkbox") {
            code_Values.checked = all.checked;
        }
    }
}

function gradeChange(grade){
	location.href='adm_kami.php?see=' + grade;
}

function delsubmit(){
	var delform = document.getElementById("form_log");
	delform.submit();
}
var div = document.getElementById('adm_kami'); 
div.setAttribute("class", "show"); 
</script>
<?php 
include_once 'footer.php';
?>