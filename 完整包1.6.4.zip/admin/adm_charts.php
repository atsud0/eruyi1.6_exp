﻿<?php
/*
* File：统计
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$sql="select * from eruyi_user where 1";
$queryc=$db->query($sql);
$user_n=$db->num_rows($queryc);//用户总数

$tmp_sql="SELECT count(*) FROM `eruyi_user` where diary between $d_time and $t_day";
$tmp_query = $db->query($tmp_sql);
$tmp_have = $db->fetch_array($tmp_query);
$u_qds = $tmp_have['count(*)'];//今日签到数

$tmp_sql="SELECT count(*) FROM `eruyi_user` where regdate between $d_time and $t_day";
$tmp_query = $db->query($tmp_sql);
$tmp_have = $db->fetch_array($tmp_query);
$u_zcs = $tmp_have['count(*)'];//今日注册数

if($user_n > 0){
	$user_qd = ceil($u_qds / $user_n * 100);//活跃比例
	$user_zc = ceil($u_zcs / $user_n * 100);//注册比例
}else{
	$user_qd = 0;
	$user_zc = 0;
}


$sql="SELECT * FROM `eruyi_order` where 1";
$queryc=$db->query($sql);
$order_n=$db->num_rows($queryc);//订单总数

$tmp_sql="SELECT count(*) FROM `eruyi_order` where o_time between $d_time and $t_day";
$tmp_query = $db->query($tmp_sql);
$tmp_have = $db->fetch_array($tmp_query);
$o_n = $tmp_have['count(*)'];//今日订单

$sql="SELECT count(*) FROM `eruyi_order` where state !='0'";
$queryc=$db->query($sql);
$tmp_have = $db->fetch_array($queryc);
$o_zt=$tmp_have['count(*)'];//订单状态

if($order_n > 0){
	$order_dd = ceil($o_n / $order_n * 100);//今日订单比例
	$order_zt = ceil($o_zt / $order_n * 100);//支付成功比例
}else{
	$order_dd = 0;
	$order_zt = 0;
}

$sql="select * from eruyi_kami where 1";
$queryc=$db->query($sql);
$kami_s=$db->num_rows($queryc);//卡密总数

$sql="select * from eruyi_kami where `new`='n'";
$queryc=$db->query($sql);
$k_n=$db->num_rows($queryc);//已使用

$sql="select * from eruyi_kami where `new`='y'";
$queryc=$db->query($sql);
$k_y=$db->num_rows($queryc);//未使用

if($kami_s > 0){
	$kami_n = ceil($k_n / $kami_s * 100);//今日订单比例
	$kami_y = ceil($k_y / $kami_s * 100);//支付成功比例
}else{
	$kami_n = 0;
	$kami_y = 0;
}

?>
	<div class="span9">
		<div class="content">
		<div class="module message">
			<div class="module-head">
					<h3>会员统计<span class="pull-right small muted"><?php echo $user_n; ?>人</span></h3>
				</div>
				<ul class="widget widget-usage unstyled ">
					<li>
						<p>
							<strong>今日注册</strong> <span class="pull-right small muted"><?php echo $user_zc; ?>%</span>
						</p>
						<div class="progress tight">
							<div class="bar" style="width: <?php echo $user_zc; ?>%;">
							</div>
						</div>
					</li>
					<li>
						
						<p>
							<strong>今日活跃</strong> <span class="pull-right small muted"><?php echo $user_qd; ?>%</span>
						</p>
						<div class="progress tight">
							<div class="bar bar-success" style="width: <?php echo $user_qd; ?>%;">
							</div>
						</div>
					</li>
				</ul>
			</div>
			<div class="module-head">
					<h3>卡密统计<span class="pull-right small muted"><?php echo $kami_s; ?>条</span></h3>
				</div>
				<ul class="widget widget-usage unstyled ">
					<li>
						<p>
							<strong>已使用</strong> <span class="pull-right small muted"><?php echo $k_n; ?>条</span>
						</p>
						<div class="progress tight">
							<div class="bar bar-danger" style="width: <?php echo $kami_n; ?>%;">
							</div>
						</div>
					</li>
					<li>
						<p>
							<strong>未使用</strong> <span class="pull-right small muted"><?php echo $k_y; ?>条</span>
						</p>
						<div class="progress tight">
							<div class="bar" style="width: <?php echo $kami_y; ?>%;">
							</div>
						</div>
					</li>
				</ul>
			</div>
			<div class="module-head">
					<h3>订单统计<span class="pull-right small muted"><?php echo $order_n; ?>条</span></h3>
				</div>
				<ul class="widget widget-usage unstyled ">
					<li>
						<p>
							<strong>今日订单</strong> <span class="pull-right small muted"><?php echo $o_n; ?>条</span>
						</p>
						<div class="progress tight">
							<div class="bar bar-danger" style="width: <?php echo $order_dd; ?>%;">
							</div>
						</div>
					</li>
					<li>
						<p>
							<strong>支付成功</strong> <span class="pull-right small muted"><?php echo $o_zt; ?>条</span>
						</p>
						<div class="progress tight">
							<div class="bar" style="width: <?php echo $order_zt; ?>%;">
							</div>
						</div>
					</li>
					
				</ul>
			</div>
		</div>
		<!--/.content-->
	</div>
	<!--/.span9-->
<script>
	
</script>			
<?php 
include_once 'footer.php';
?>
