<?php
/*
* File：编辑应用
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/

require_once 'globals.php';
include_once 'header.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : '';
$sql="select * from eruyi_app where id=$id";
$query=$db->query($sql);
$row=$db->fetch_array($query);
$app_key = $row['key'];
$name = isset($_POST['name']) ? addslashes($_POST['name']) : '';
$sign_t = isset($_POST['sign_t']) ? intval($_POST['sign_t']) : 0;//Sign有效时间
$ipon = isset($_POST['ipon']) ? intval($_POST['ipon']) : 0;//限制IP注册
$codeon = isset($_POST['codeon']) ? intval($_POST['codeon']) : 0;//限制机器码注册
$check_code = isset($_POST['check_code']) ? addslashes($_POST['check_code']) : 'y';//用户登入校验机器码  y开启 n关闭
$many_code = isset($_POST['many_code']) ? addslashes($_POST['many_code']) : 'y';//多设备登入  y开启 n关闭

$charge = isset($_POST['charge']) ? addslashes($_POST['charge']) : 'y';//收费模式 y收费 n=免费
$state = isset($_POST['state']) ? addslashes($_POST['state']) : 'y';//应用开关 y开启 n关闭
$notice = isset($_POST['notice']) ? addslashes($_POST['notice']) : '';//关闭通知

$reg_award = isset($_POST['reg_award']) ? addslashes($_POST['reg_award']) : 'vip';//注册奖励类型
$inv_award = isset($_POST['inv_award']) ? addslashes($_POST['inv_award']) : 'vip';//邀请奖励类型
$diary_award = isset($_POST['diary_award']) ? addslashes($_POST['diary_award']) : 'vip';//签到奖励类型
$reg_value = isset($_POST['reg_value']) ? intval($_POST['reg_value']) : 0;//注册送体验VIP时间（单位：分钟，设0关闭）
$inv_value = isset($_POST['inv_value']) ? intval($_POST['inv_value']) : 0;//邀请成功赠送体验VIP时间（单位：小时，设0关闭）
$diary_value = isset($_POST['diary_value']) ? intval($_POST['diary_value']) : 0;//每天签到成功赠送VIP时间（单位：分钟，设0关闭）

$app_bb = isset($_POST['app_bb']) ? addslashes($_POST['app_bb']) : '1.0.0';//APP版本
$app_nshow = isset($_POST['app_nshow']) ? addslashes($_POST['app_nshow']) : '';//APP更新说明
$app_nurl = isset($_POST['app_nurl']) ? addslashes($_POST['app_nurl']) : '';//APP更新地址
$app_extend_ini = isset($_POST['app_extend_ini']) ? addslashes($_POST['app_extend_ini']) : 'n';//应用开关 y显示 n关闭
$app_extend_1 = isset($_POST['app_extend_1']) ? addslashes($_POST['app_extend_1']) : '';//应用扩展配置
$app_extend_2 = isset($_POST['app_extend_2']) ? addslashes($_POST['app_extend_2']) : '';//应用扩展配置
$app_extend_3 = isset($_POST['app_extend_3']) ? addslashes($_POST['app_extend_3']) : '';//应用扩展配置
$app_extend_4 = isset($_POST['app_extend_4']) ? addslashes($_POST['app_extend_4']) : '';//应用扩展配置
$app_extend_5 = isset($_POST['app_extend_5']) ? addslashes($_POST['app_extend_5']) : '';//应用扩展配置

$pay_url = isset($_POST['pay_url']) ? addslashes($_POST['pay_url']) : '';//支付请求地址
$pay_appid = isset($_POST['pay_appid']) ? addslashes($_POST['pay_appid']) : '';//支付ID
$pay_appkey = isset($_POST['pay_appkey']) ? addslashes($_POST['pay_appkey']) : '';//支付秘钥
$pay_zfb = isset($_POST['pay_zfb']) ? addslashes($_POST['pay_zfb']) : '';//支付宝支付方式
$pay_wx = isset($_POST['pay_wx']) ? addslashes($_POST['pay_wx']) : '';//微信支付方式
$pay_qq = isset($_POST['pay_qq']) ? addslashes($_POST['pay_qq']) : '';//qq支付方式
$pay_zfb_state = isset($_POST['pay_zfb_state']) ? addslashes($_POST['pay_zfb_state']) : '';//支付宝支付状态
$pay_wx_state = isset($_POST['pay_wx_state']) ? addslashes($_POST['pay_wx_state']) : '';//微信支付状态
$pay_qq_state = isset($_POST['pay_qq_state']) ? addslashes($_POST['pay_qq_state']) : '';//qq支付状态
$pay_state = isset($_POST['pay_state']) ? addslashes($_POST['pay_state']) : '';//支付状态
$pay_notify = isset($_POST['pay_notify']) ? addslashes($_POST['pay_notify']) : '';//异步通知地址
$submit = isset($_POST['submit']) ? addslashes($_POST['submit']) : '';
if($submit){
	if($reg_award == 'vip'){
		$reg_vip = $reg_value;
		$reg_fen = $row['reg_fen'];
	}else{
		$reg_fen = $reg_value;
		$reg_vip = $row['reg_vip'];
	}
	
	if($inv_award == 'vip'){
		$inv_vip = $inv_value;
		$inv_fen = $row['inv_fen'];
	}else{
		$inv_fen = $inv_value;
		$inv_vip = $row['inv_vip'];
	}
	
	if($diary_award == 'vip'){
		$diary_vip = $diary_value;
		$diary_fen = $row['diary_fen'];
	}else{
		$diary_fen = $diary_value;
		$diary_vip = $row['diary_vip'];
	}
	
	$sql="UPDATE `eruyi_app` SET `name`='$name',
	`sign_t`='$sign_t',
	`charge`= '$charge',
	`state`= '$state',
	`ipon`='$ipon',
	`codeon`='$codeon',
	`check_code`='$check_code',
	`many_code`='$many_code',
	`diary_award`= '$diary_award',
	`reg_award`='$reg_award',
	`inv_award`='$inv_award',
	`diary_fen`= '$diary_fen',
	`reg_fen`='$reg_fen',
	`inv_fen`='$inv_fen',
	`diary_vip`= '$diary_vip',
	`reg_vip`='$reg_vip',
	`inv_vip`='$inv_vip',
	`notice`= '$notice',
	`app_bb`= '$app_bb',
	`app_nshow`= '$app_nshow',
	`app_nurl`= '$app_nurl',
	`app_extend_ini` = '$app_extend_ini',
	`app_extend_1`= '$app_extend_1',
	`app_extend_2`= '$app_extend_2',
	`app_extend_3`= '$app_extend_3',
	`app_extend_4`= '$app_extend_4',
	`app_extend_5`= '$app_extend_5',
	`pay_state`= '$pay_state',
	`pay_url`= '$pay_url',
	`pay_appid`= '$pay_appid',
	`pay_appkey`= '$pay_appkey',
	`pay_zfb`= '$pay_zfb',
	`pay_wx`= '$pay_wx',
	`pay_qq`= '$pay_qq',
	`pay_zfb_state`= '$pay_zfb_state',
	`pay_wx_state`= '$pay_wx_state',
	`pay_qq_state`= '$pay_qq_state',
	`pay_notify`= '$pay_notify' WHERE id=$id";
	$query=$db->query($sql);
	if($query){
		echo "<script>alert('编辑成功');location.href='edit_app.php?id=".$id."';</script>";
	}
}
?>
	<div class="span9">
		<div class="content">
			<div class="module">
				<div class="module-head">
					<h3>应用设置</h3>
				</div>
				<div class="module-body">
					<form class="form-horizontal row-fluid" action="" method="post" id="addimg" name="addimg">
					<div id="post">
					<div class="control-group">
						<label class="control-label" for="name_label">名称:</label>
						<div class="controls">
							<input type="text" name="name" id="name" value="<?php echo $row['name'];?>" >
							<span class="help-inline">*</span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="user_label">APPID:</label>
						<div class="controls">
							<input type="text" id="appid" value="<?php echo $id;?>" disabled>
							<span class="help-inline"><a href="javascript:void(0);" onclick="copy_id()">复制</a></span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="user_label">APPKEY:</label>
						<div class="controls">
							<input type="text" id="key" value="<?php echo $app_key;?>" class="span8" disabled>
							<span class="help-inline"><a href="javascript:void(0);" onclick="copy_key()">复制</a></span>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="sign_t">Sign有效期:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="sign_t" id="sign_t" placeholder="10" value="<?php echo $row['sign_t'];?>" class="span8"><span class="add-on">秒</span>
							</div>
						</div>
					</div>
					
					<div class="control-group">
						<label class="control-label">运营模式:</label>
						<div class="controls">
							<label class="radio inline">
							<input type="radio" name="charge" id="charge" value="y" <?php if($row['charge']=='y'):?> checked="checked"<?php endif; ?> >收费模式</label> 
							<label class="radio inline">
							<input type="radio" name="charge" id="charge" value="n" <?php if($row['charge']=='n'):?> checked="checked"<?php endif; ?> >免费模式</label> 
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">设备校验:</label>
						<div class="controls">
							<label class="radio inline">
							<input onchange="code_change(0)" type="radio" name="check_code" id="check_code" value="y" <?php if($row['check_code']=='y'):?> checked="checked"<?php endif; ?>>开启</label> 
							<label class="radio inline">
							<input onchange="code_change(1)" type="radio" name="check_code" id="check_code" value="n" <?php if($row['check_code']=='n'):?> checked="checked"<?php endif; ?>>关闭</label> 
						</div>
					</div>
					<div class="view" name="code_c" id="code_c" <?php if($row['check_code']=='n'):?> style="display: block;"<?php endif; ?>>
						<div class="control-group">
						</div>
						<div class="control-group">
							<label class="control-label">多设备登入:</label>
							<div class="controls">
								<label class="radio inline">
								<input type="radio" name="many_code" id="many_code" value="y" <?php if($row['many_code']=='y'):?> checked="checked"<?php endif; ?>>开启</label> 
								<label class="radio inline">
								<input type="radio" name="many_code" id="many_code" value="n" <?php if($row['many_code']=='n'):?> checked="checked"<?php endif; ?>>关闭</label> 
							</div>
						</div>
					</div>
					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<strong>提示：</strong> 开启设备校验之后，用户登入时会校验上次登入的设备是否一致，可防止VIP账号一人多用
					</div>
					<div class="control-group">
						<label class="control-label">应用状态:</label>
						<div class="controls">
							<label class="radio inline">
							<input onchange="change(0)" type="radio" name="state" id="state" value="y" <?php if($row['state']=='y'):?> checked="checked"<?php endif; ?> >开启</label> 
							<label class="radio inline">
							<input onchange="change(1)" type="radio" name="state" id="state" value="n" <?php if($row['state']=='n'):?> checked="checked"<?php endif; ?> >关闭</label> 
						</div>
					</div>
					<div class="view" name="notice_c" id="notice_c" <?php if($row['state']=='n'):?> style="display: block;"<?php endif; ?>>
						<label class="control-label" for="notice_label">关闭提示:</label>
						<div class="controls">
							<input type="text" name="notice" id="notice" placeholder="可以在这里填写关闭提示.." value="<?php echo $row['notice'];?>"  class="span8 tip">
						</div>
					</div>
					<div class="alert alert-error">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<strong>提示：</strong> 关闭应用后，改应用的用户无法进行任何操作！
					</div>
					<div class="control-group">
						<label class="control-label" for="ipon_label">同一IP注册间隔:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="ipon" id="ipon" placeholder="0" value="<?php echo $row['ipon'];?>" class="span8"><span class="add-on">小时</span>
							</div>
						</div>
					</div>
					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<strong>提示：</strong> 可有效防止同一个IP在设置的时间间隔内无法再进行注册，0为不限制
					</div>
					<div class="control-group">
						<label class="control-label" for="codeon_label">同一机器注册间隔:</label>
						<div class="controls">
							<div class="input-append">
								<input type="text" name="codeon" id="codeon" placeholder="0" value="<?php echo $row['codeon'];?>" class="span8"><span class="add-on">小时</span>
							</div>
						</div>
					</div>
					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<strong>提示：</strong> 可有效防止同一个机器在设置的时间间隔内无法再进行注册，0为不限制
					</div>
					<div class="control-group">
						<label class="control-label" for="type" id="reg_label">注册奖励:</label>
						<div class="controls">
							<select name="reg_award" id="reg_award" onchange="award_change()">
								<option value="vip" <?php if($row['reg_award']=='vip') echo 'selected = "selected"'; ?>>会员</option>
								<option value="fen" <?php if($row['reg_award']=='fen') echo 'selected = "selected"'; ?>>积分</option>
								<input style="margin-left: 2px;" type="text" name="reg_value" id="reg_value" placeholder="0" value="<?php if($row['reg_award']=='vip'){echo $row['reg_vip'];}else{echo $row['reg_fen'];} ?>">
							</select>
						</div>
					</div>

					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<div class="view" name="reg_vip_c" id="reg_vip_c" <?php if($row['reg_award']=='vip') echo 'style="display: block;"'; ?>>
							<strong>提示：</strong> 新注册的用户获得VIP体验时间。奖励单位：<strong>分钟</strong>，0为不奖励
						</div>	
						<div class="view" name="reg_fen_c" id="reg_fen_c" <?php if($row['reg_award']=='fen') echo 'style="display: block;"'; ?>>
							<strong>提示：</strong> 新注册的用户获得积分奖励。0为不奖励
						</div>
					</div>
					
					<div class="control-group">
						<label class="control-label" for="type" id="inv_label">邀请奖励:</label>
						<div class="controls">
							<select name="inv_award" id="inv_award" onchange="award_change()">
								<option value="vip" <?php if($row['inv_award']=='vip') echo 'selected = "selected"'; ?>>会员</option>
								<option value="fen" <?php if($row['inv_award']=='fen') echo 'selected = "selected"'; ?>>积分</option>
								<input style="margin-left: 2px;" type="text" name="inv_value" id="inv_value" placeholder="0" value="<?php if($row['inv_award']=='vip'){echo $row['inv_vip'];}else{echo $row['inv_fen'];} ?>">
							</select>
						</div>
					</div>
					
					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<div class="view" name="inv_vip_c" id="inv_vip_c" <?php if($row['inv_award']=='vip') echo 'style="display: block;"'; ?>>
							<strong>提示：</strong> 邀请用户注册邀请者获得VIP时间奖励。奖励单位：<strong>小时</strong>，0为不奖励
						</div>	
						<div class="view" name="inv_fen_c" id="inv_fen_c" <?php if($row['inv_award']=='fen') echo 'style="display: block;"'; ?>>
							<strong>提示：</strong> 邀请用户注册邀请者获得积分奖励。0为不奖励
						</div>
					</div>	
					
					<div class="control-group">
						<label class="control-label" for="type" id="type_label">签到奖励:</label>
						<div class="controls">
							<select name="diary_award" id="diary_award" onchange="award_change()">
								<option value="vip" <?php if($row['diary_award']=='vip') echo 'selected = "selected"'; ?>>会员</option>
								<option value="fen" <?php if($row['diary_award']=='fen') echo 'selected = "selected"'; ?>>积分</option>
								<input style="margin-left: 2px;" type="text" name="diary_value" id="diary_value" placeholder="0" value="<?php if($row['diary_award']=='vip'){echo $row['diary_vip'];}else{echo $row['diary_fen'];} ?>">
							</select>
						</div>
					</div>

					<div class="alert">
						<button type="button" class="close" data-dismiss="alert">×</button>
						<div class="view" name="diary_vip_c" id="diary_vip_c" <?php if($row['diary_award']=='vip') echo 'style="display: block;"'; ?>>
							<strong>提示：</strong> 用户每天进行签到获得VIP时间奖励。奖励单位：<strong>分钟</strong>，0为关闭签到功能且不奖励
						</div>	
						<div class="view" name="diary_fen_c" id="diary_fen_c" <?php if($row['diary_award']=='fen') echo 'style="display: block;"'; ?>>
							<strong>提示：</strong> 用户每天进行签到获得积分奖励。0为关闭签到功能且不奖励
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="bb_label">应用版本:</label>
						<div class="controls">
							<input type="text" name="app_bb" id="app_bb" placeholder="1.0.0" value="<?php echo $row['app_bb'];?>">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="app_nshow_label">应用更新内容:</label>
						<div class="controls">
							<input  type="text" name="app_nshow" id="app_nshow" placeholder="更新内容，换行符\n" value="<?php echo $row['app_nshow'];?>" class="span8 tip">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="app_nurl_label">更新地址:</label>
						<div class="controls">
							<input  type="text" name="app_nurl" id="app_nurl" placeholder="更新地址" value="<?php echo $row['app_nurl'];?>" class="span8 tip">
						</div>
					</div>
					<div class="control-group">
						<label class="control-label">扩展配置:</label>
						<div class="controls">
							<label class="radio inline">
							<input onchange="ini_change(0)" type="radio" name="app_extend_ini" id="app_extend_ini" value="y" <?php if($row['app_extend_ini']=='y'):?> checked="checked"<?php endif; ?> >显示</label> 
							<label class="radio inline">
							<input onchange="ini_change(1)" type="radio" name="app_extend_ini" id="app_extend_ini" value="n" <?php if($row['app_extend_ini']=='n'):?> checked="checked"<?php endif; ?> >关闭</label> 
						</div>
					</div>
					<div class="view" name="ini_c" id="ini_c" <?php if($row['app_extend_ini']=='y'):?> style="display: block;"<?php endif; ?>>
						<div class="control-group"></div>
						<div class="control-group">
							<label class="control-label" for="app_extend_label">扩展配置1:</label>
							<div class="controls">
								<input  type="text" name="app_extend_1" id="app_extend_1" placeholder="可自行配置任何数据，将在获取app配置接口中展示" value="<?php echo $row['app_extend_1'];?>" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="app_extend_label">扩展配置2:</label>
							<div class="controls">
								<input  type="text" name="app_extend_2" id="app_extend_2" placeholder="可自行配置任何数据，将在获取app配置接口中展示" value="<?php echo $row['app_extend_2'];?>" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="app_extend_label">扩展配置3:</label>
							<div class="controls">
								<input  type="text" name="app_extend_3" id="app_extend_3" placeholder="可自行配置任何数据，将在获取app配置接口中展示" value="<?php echo $row['app_extend_3'];?>" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="app_extend_label">扩展配置4:</label>
							<div class="controls">
								<input  type="text" name="app_extend_4" id="app_extend_4" placeholder="可自行配置任何数据，将在获取app配置接口中展示" value="<?php echo $row['app_extend_4'];?>" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="app_extend_label">扩展配置5:</label>
							<div class="controls">
								<input  type="text" name="app_extend_5" id="app_extend_5" placeholder="可自行配置任何数据，将在获取app配置接口中展示" value="<?php echo $row['app_extend_5'];?>" class="span8 tip">
							</div>
						</div>
					</div>	
					<div class="control-group"></div>
					<div class="control-group">
						<label class="control-label">支付状态:</label>
						<div class="controls">
							<label class="radio inline">
							<input onchange="pay_change(0)" type="radio" name="pay_state" id="pay_state" value="y" <?php if($row['pay_state']=='y'):?> checked="checked"<?php endif; ?> >开启</label> 
							<label class="radio inline">
							<input onchange="pay_change(1)" type="radio" name="pay_state" id="pay_state" value="n" <?php if($row['pay_state']=='n'):?> checked="checked"<?php endif; ?> >关闭</label> 
						</div>
					</div>
					<div class="view" name="pay_c" id="pay_c" <?php if($row['pay_state']=='y'):?> style="display: block;"<?php endif; ?>>
						<div class="control-group">
						</div>
						<div class="control-group">
							<label class="control-label" for="pay_url_label">请求地址:</label>
							<div class="controls">
								<input  type="text" name="pay_url" id="pay_url" placeholder="支持所有易支付平台，支付请求地址" value="<?php echo $row['pay_url'];?>" class="span8 tip">
								<a href="http://pay.muitc.com" target="_black"><u>商户申请</u></a>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="pay_appid_label">商户ID:</label>
							<div class="controls">
								<input  type="text" name="pay_appid" id="pay_appid" placeholder="支持所有易支付平台，商户ID" value="<?php echo $row['pay_appid'];?>" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="pay_appkey_label">商户密钥:</label>
							<div class="controls">
								<input  type="text" name="pay_appkey" id="pay_appkey" placeholder="支持所有易支付平台，商户秘钥/KEY" value="<?php echo $row['pay_appkey'];?>" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label" for="pay_notify_label">充值地址:</label>
							<div class="controls">
								<input  type="text" name="pay_notify" id="pay_notify" placeholder="http://域名/notify.php" value="<?php echo $row['pay_notify'];?>" class="span8 tip">
							</div>
						</div>
						<div class="control-group">
							<label class="control-label">支付宝支付方式:</label>
							<div class="controls">
								<label class="radio inline">
								<input onchange="zfb_change(0)" type="radio" name="pay_zfb_state" id="pay_zfb_state" value="y" <?php if($row['pay_zfb_state']=='y'):?> checked="checked"<?php endif; ?> >开启</label> 
								<label class="radio inline">
								<input onchange="zfb_change(1)" type="radio" name="pay_zfb_state" id="pay_zfb_state" value="n" <?php if($row['pay_zfb_state']=='n'):?> checked="checked"<?php endif; ?> >关闭</label> 
							</div>
						</div>
						<div class="view" name="zfb_c" id="zfb_c" <?php if($row['pay_zfb_state']=='y'):?> style="display: block;"<?php endif; ?>>
							<label class="control-label" for="pay_zfb_label">支付方式变量:</label>
							<div class="controls">
								<input type="text" name="pay_zfb" id="pay_zfb" placeholder="支付宝支付方式变量" value="<?php echo $row['pay_zfb'];?>"  class="span8 tip">
							</div>
						</div>
						<div class="control-group">
						</div>
						<div class="control-group">
							<label class="control-label">微信支付方式:</label>
							<div class="controls">
								<label class="radio inline">
								<input onchange="wx_change(0)" type="radio" name="pay_wx_state" id="pay_wx_state" value="y" <?php if($row['pay_wx_state']=='y'):?> checked="checked"<?php endif; ?> >开启</label> 
								<label class="radio inline">
								<input onchange="wx_change(1)" type="radio" name="pay_wx_state" id="pay_wx_state" value="n" <?php if($row['pay_wx_state']=='n'):?> checked="checked"<?php endif; ?> >关闭</label> 
							</div>
						</div>
						<div class="view" name="wx_c" id="wx_c" <?php if($row['pay_wx_state']=='y'):?> style="display: block;"<?php endif; ?>>
							<label class="control-label" for="pay_wx_label">支付方式变量:</label>
							<div class="controls">
								<input type="text" name="pay_wx" id="pay_wx" placeholder="微信支付方式变量" value="<?php echo $row['pay_wx'];?>"  class="span8 tip">
							</div>
						</div>
						<div class="control-group">
						</div>
						<div class="control-group">
							<label class="control-label">QQ支付方式:</label>
							<div class="controls">
								<label class="radio inline">
								<input onchange="qq_change(0)" type="radio" name="pay_qq_state" id="pay_qq_state" value="y" <?php if($row['pay_qq_state']=='y'):?> checked="checked"<?php endif; ?> >开启</label> 
								<label class="radio inline">
								<input onchange="qq_change(1)" type="radio" name="pay_qq_state" id="pay_qq_state" value="n" <?php if($row['pay_qq_state']=='n'):?> checked="checked"<?php endif; ?> >关闭</label> 
							</div>
						</div>
						<div class="view" name="qq_c" id="qq_c" <?php if($row['pay_qq_state']=='y'):?> style="display: block;"<?php endif; ?>>
							<label class="control-label" for="pay_qq_label">支付方式变量:</label>
							<div class="controls">
								<input type="text" name="pay_qq" id="pay_qq" placeholder="QQ支付方式变量" value="<?php echo $row['pay_qq'];?>"  class="span8 tip">
							</div>
						</div>
					</div>
					
					<div class="control-group">
					</div>
					<div class="control-group">
						<div class="controls" id="post_button">
							<input type="submit" name="submit" value="修改保存" class="btn btn-success" />
						</div>
					</div>
					</div>
					</form>
				</div>
			</div>
		</div><!--/.content-->
	</div><!--/.span9-->
<script> 
var div = document.getElementById('adm_user'); 
div.setAttribute("class", "show"); 
function inp(data) {
    console.log(data.value)
}
// 复制到剪切板
function copy_key(){
    var Url2="<?php echo $app_key;?>";
    var oInput = document.createElement('input');
    oInput.value = Url2;
    document.body.appendChild(oInput);
    oInput.select(); // 选择对象
    document.execCommand("Copy"); // 执行浏览器复制命令
    oInput.className = 'oInput';
    oInput.style.display='none';
    alert('复制成功');
}

function code_change(i) {
	if(i=='1'){
		$("#code_c").css("display", "block");
	}else{
		$("#code_c").css("display", "none");
	}
}

function copy_id(){
    var Url2="<?php echo $id;?>";
    var oInput = document.createElement('input');
    oInput.value = Url2;
    document.body.appendChild(oInput);
    oInput.select(); // 选择对象
    document.execCommand("Copy"); // 执行浏览器复制命令
    oInput.className = 'oInput';
    oInput.style.display='none';
    alert('复制成功');
}

function award_change() {
	if($('#diary_award').val()=='vip'){
		$("#diary_vip_c").css("display", "block");
		$("#diary_fen_c").css("display", "none");
	}else{
		$("#diary_vip_c").css("display", "none");
		$("#diary_fen_c").css("display", "block");
	}
	
	if($('#inv_award').val()=='vip'){
		$("#inv_vip_c").css("display", "block");
		$("#inv_fen_c").css("display", "none");
	}else{
		$("#inv_vip_c").css("display", "none");
		$("#inv_fen_c").css("display", "block");
	}
	
	if($('#reg_award').val()=='vip'){
		$("#reg_vip_c").css("display", "block");
		$("#reg_fen_c").css("display", "none");
	}else{
		$("#reg_vip_c").css("display", "none");
		$("#reg_fen_c").css("display", "block");
	}
}

function change(i) {
	if(i=='1'){
		$("#notice_c").css("display", "block");
	}else{
		$("#notice_c").css("display", "none");
	}
}
function ini_change(i) {
	if(i=='0'){
		$("#ini_c").css("display", "block");
	}else{
		$("#ini_c").css("display", "none");
	}
}

function pay_change(i) {
	if(i=='0'){
		$("#pay_c").css("display", "block");
	}else{
		$("#pay_c").css("display", "none");
	}
}

function zfb_change(i) {
	if(i=='0'){
		$("#zfb_c").css("display", "block");
	}else{
		$("#zfb_c").css("display", "none");
	}
}

function wx_change(i) {
	if(i=='0'){
		$("#wx_c").css("display", "block");
	}else{
		$("#wx_c").css("display", "none");
	}
}

function qq_change(i) {
	if(i=='0'){
		$("#qq_c").css("display", "block");
	}else{
		$("#qq_c").css("display", "none");
	}
}
</script>
<?php 
include_once 'footer.php';
?>