
<!DOCTYPE html>
<html lang="zh">
    <head>
        
        
     
    </head>

    <body style="overflow-x:hidden;">
		<link href="style/time/css/bootstrap-datetimepicker.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" media="screen" href="style/time/css/bootstrap.min.css" />
        <!--时间css end-->
     	<script type="text/javascript" src="style/time/js/jquery-2.1.1.min.js"></script>
        <script type="text/javascript" src="style/time/js/bootstrap.min.js"></script>
         <!--时间js start-->
		<script src="style/time/js/moment-with-locales.js"></script>
		<script src="style/time/js/bootstrap-datetimepicker.js"></script>
        <!--时间js end-->

		<div class="container">
			<div class="row">
				<div class='col-sm-6'>
					<input type='text' class="form-control" id='datetimepicker4'/>
				 </div>
				<script type="text/javascript">
					$(function () {
						$('#datetimepicker4').datetimepicker({locale: 'zh-cn'});
					});
				</script>
			</div>
		</div>

    </body>
</html>