
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN" lang="zh-CN">
	<head>
		<title>开发文档 - 易如意网络验证系统</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="keywords" content="开发文档,易如意网络验证系统" />
		<meta name="description" content="易如意网络验证系统是一款采用PHP+Mysql构架的用户管理系统" />
		<link rel="icon" href="/favicon.ico" type="image/x-icon">
		<style>
			h4 span{font-size:0.9em;margin-left:5px;color:#999;font-weight:400;}.site-footer-credits
			a{color:#819198;}div{margin-bottom:30px;}.highlighter-rouge{margin-bottom:20px;}
			html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{margin:0}article,aside,details,figcaption,figure,footer,header,hgroup,main,menu,nav,section,summary{display:block}audio,canvas,progress,video{display:inline-block;vertical-align:baseline}audio:not([controls]){display:none;height:0}[hidden],template{display:none}a{background-color:transparent}a:active,a:hover{outline:0}abbr[title]{border-bottom:1px dotted}b,strong{font-weight:bold}dfn{font-style:italic}h1{font-size:2em;margin:0.67em 0}mark{background:#ff0;color:#000}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sup{top:-0.5em}sub{bottom:-0.25em}img{border:0}svg:not(:root){overflow:hidden}figure{margin:1em 40px}hr{box-sizing:content-box;height:0}pre{overflow:auto}code,kbd,pre,samp{font-family:monospace, monospace;font-size:1em}button,input,optgroup,select,textarea{color:inherit;font:inherit;margin:0}button{overflow:visible}button,select{text-transform:none}button,html input[type="button"],input[type="reset"],input[type="submit"]{-webkit-appearance:button;cursor:pointer}button[disabled],html input[disabled]{cursor:default}button::-moz-focus-inner,input::-moz-focus-inner{border:0;padding:0}input{line-height:normal}input[type="checkbox"],input[type="radio"]{box-sizing:border-box;padding:0}input[type="number"]::-webkit-inner-spin-button,input[type="number"]::-webkit-outer-spin-button{height:auto}input[type="search"]{-webkit-appearance:textfield;box-sizing:content-box}input[type="search"]::-webkit-search-cancel-button,input[type="search"]::-webkit-search-decoration{-webkit-appearance:none}fieldset{border:1px solid #c0c0c0;margin:0 2px;padding:0.35em 0.625em 0.75em}legend{border:0;padding:0}textarea{overflow:auto}optgroup{font-weight:bold}table{border-collapse:collapse;border-spacing:0}td,th{padding:0}.highlight table td{padding:5px}.highlight table pre{margin:0}.highlight .cm{color:#999988;font-style:italic}.highlight .cp{color:#999999;font-weight:bold}.highlight .c1{color:#999988;font-style:italic}.highlight .cs{color:#999999;font-weight:bold;font-style:italic}.highlight .c,.highlight .cd{color:#999988;font-style:italic}.highlight .err{color:#a61717;background-color:#e3d2d2}.highlight .gd{color:#000000;background-color:#ffdddd}.highlight .ge{color:#000000;font-style:italic}.highlight .gr{color:#aa0000}.highlight .gh{color:#999999}.highlight .gi{color:#000000;background-color:#ddffdd}.highlight .go{color:#888888}.highlight .gp{color:#555555}.highlight .gs{font-weight:bold}.highlight .gu{color:#aaaaaa}.highlight .gt{color:#aa0000}.highlight .kc{color:#000000;font-weight:bold}.highlight .kd{color:#000000;font-weight:bold}.highlight .kn{color:#000000;font-weight:bold}.highlight .kp{color:#000000;font-weight:bold}.highlight .kr{color:#000000;font-weight:bold}.highlight .kt{color:#445588;font-weight:bold}.highlight .k,.highlight .kv{color:#000000;font-weight:bold}.highlight .mf{color:#009999}.highlight .mh{color:#009999}.highlight .il{color:#009999}.highlight .mi{color:#009999}.highlight .mo{color:#009999}.highlight .m,.highlight .mb,.highlight .mx{color:#009999}.highlight .sb{color:#d14}.highlight .sc{color:#d14}.highlight .sd{color:#d14}.highlight .s2{color:#d14}.highlight .se{color:#d14}.highlight .sh{color:#d14}.highlight .si{color:#d14}.highlight .sx{color:#d14}.highlight .sr{color:#009926}.highlight .s1{color:#d14}.highlight .ss{color:#990073}.highlight .s{color:#d14}.highlight .na{color:#008080}.highlight .bp{color:#999999}.highlight .nb{color:#0086B3}.highlight .nc{color:#445588;font-weight:bold}.highlight .no{color:#008080}.highlight .nd{color:#3c5d5d;font-weight:bold}.highlight .ni{color:#800080}.highlight .ne{color:#990000;font-weight:bold}.highlight .nf{color:#990000;font-weight:bold}.highlight .nl{color:#990000;font-weight:bold}.highlight .nn{color:#555555}.highlight .nt{color:#000080}.highlight .vc{color:#008080}.highlight .vg{color:#008080}.highlight .vi{color:#008080}.highlight .nv{color:#008080}.highlight .ow{color:#000000;font-weight:bold}.highlight .o{color:#000000;font-weight:bold}.highlight .w{color:#bbbbbb}.highlight{background-color:#f8f8f8}*{box-sizing:border-box}body{padding:0;margin:0;font-family:"Open Sans", "Helvetica Neue", Helvetica, Arial, sans-serif;font-size:16px;line-height:1.5;color:#606c71}a{color:#1e6bb8;text-decoration:none}a:hover{text-decoration:underline}.btn{display:inline-block;margin-bottom:1rem;color:rgba(255,255,255,0.7);background-color:rgba(255,255,255,0.08);border-color:rgba(255,255,255,0.2);border-style:solid;border-width:1px;border-radius:0.3rem;transition:color 0.2s, background-color 0.2s, border-color 0.2s}.btn:hover{color:rgba(255,255,255,0.8);text-decoration:none;background-color:rgba(255,255,255,0.2);border-color:rgba(255,255,255,0.3)}.btn+.btn{margin-left:1rem}@media screen and (min-width: 64em){.btn{padding:0.75rem 1rem}}@media screen and (min-width: 42em) and (max-width: 64em){.btn{padding:0.6rem 0.9rem;font-size:0.9rem}}@media screen and (max-width: 42em){.btn{display:block;width:100%;padding:0.75rem;font-size:0.9rem}.btn+.btn{margin-top:1rem;margin-left:0}}.page-header{color:#fff;text-align:center;background-color:#159957;background-image:linear-gradient(120deg, #1559E7, #15999D)}@media screen and (min-width: 64em){.page-header{padding:5rem 6rem}}@media screen and (min-width: 42em) and (max-width: 64em){.page-header{padding:3rem 4rem}}@media screen and (max-width: 42em){.page-header{padding:2rem 1rem}}.project-name{margin-top:0;margin-bottom:0.1rem}@media screen and (min-width: 64em){.project-name{font-size:3.25rem}}@media screen and (min-width: 42em) and (max-width: 64em){.project-name{font-size:2.25rem}}@media screen and (max-width: 42em){.project-name{font-size:1.75rem}}.project-tagline{margin-bottom:2rem;font-weight:normal;opacity:0.7}@media screen and (min-width: 64em){.project-tagline{font-size:1.25rem}}@media screen and (min-width: 42em) and (max-width: 64em){.project-tagline{font-size:1.15rem}}@media screen and (max-width: 42em){.project-tagline{font-size:1rem}}.main-content{word-wrap:break-word}.main-content :first-child{margin-top:0}@media screen {.main-content{max-width:75rem;padding:2rem 6rem;margin:0 auto;font-size:1.1rem}}@media screen and (min-width: 42em) and (max-width: 64em){.main-content{padding:2rem 4rem;font-size:1.1rem}}@media screen and (max-width: 42em){.main-content{padding:2rem 1rem;font-size:1rem}}.main-content img{max-width:100%}.main-content h1,.main-content h2,.main-content h3,.main-content h4,.main-content h5,.main-content h6{margin-top:1.5rem;margin-bottom:1rem;font-weight:normal;color:#159957}.main-content p{margin-bottom:1em}.main-content code{padding:2px 4px;font-family:Consolas, "Liberation Mono", Menlo, Courier, monospace;font-size:0.9rem;color:#567482;background-color:#f3f6fa;border-radius:0.3rem}.main-content pre{padding:0.8rem;margin-top:0;margin-bottom:1rem;font:1rem Consolas, "Liberation Mono", Menlo, Courier, monospace;color:#567482;word-wrap:normal;background-color:#f3f6fa;border:solid 1px #dce6f0;border-radius:0.3rem}.main-content pre>code{padding:0;margin:0;font-size:0.9rem;color:#567482;word-break:normal;white-space:pre;background:transparent;border:0}.main-content .highlight{margin-bottom:1rem}.main-content .highlight pre{margin-bottom:0;word-break:normal}.main-content .highlight pre,.main-content pre{padding:0.8rem;overflow:auto;font-size:0.9rem;line-height:1.45;border-radius:0.3rem;-webkit-overflow-scrolling:touch}.main-content pre code,.main-content pre tt{display:inline;max-width:initial;padding:0;margin:0;overflow:initial;line-height:inherit;word-wrap:normal;background-color:transparent;border:0}.main-content pre code:before,.main-content pre code:after,.main-content pre tt:before,.main-content pre tt:after{content:normal}.main-content ul,.main-content ol{margin-top:0}.main-content blockquote{padding:0 1rem;margin-left:0;color:#819198;border-left:0.3rem solid #dce6f0}.main-content blockquote>:first-child{margin-top:0}.main-content blockquote>:last-child{margin-bottom:0}.main-content table{display:block;width:100%;overflow:auto;word-break:normal;word-break:keep-all;-webkit-overflow-scrolling:touch}.main-content table th{font-weight:bold}.main-content table th,.main-content table td{padding:0.5rem 1rem;border:1px solid #e9ebec}.main-content dl{padding:0}.main-content dl dt{padding:0;margin-top:1rem;font-size:1rem;font-weight:bold}.main-content dl dd{padding:0;margin-bottom:1rem}.main-content hr{height:2px;padding:0;margin:1rem 0;background-color:#eff0f1;border:0}.site-footer{padding-top:2rem;margin-top:2rem;border-top:solid 1px #eff0f1}@media screen and (min-width: 64em){.site-footer{font-size:1rem}}@media screen and (min-width: 42em) and (max-width: 64em){.site-footer{font-size:1rem}}@media screen and (max-width: 42em){.site-footer{font-size:0.9rem}}.site-footer-owner{display:block;font-weight:bold}.site-footer-credits{color:#819198}
		</style>
	</head>
	<body>
		<section class="page-header">
			<h1 class="project-name" style="text-transform: uppercase;">
				开发文档 - 易如意网络验证系统</h1>
		</section>
		<section class="main-content">
			<div>
				<h2>协议规则</h2>
				<p>传输方式：HTTP</p>
				<p>提交方式：POST</p>
				<p>返回格式：JSON</p>
				<p>签名算法：MD5</p>
				<p>字符编码：UTF-8</p><hr/>
			</div>
			<div>
			<p>
			<a href="#api_ini" style="padding-right: 20px;">[API]应用配置</a>
			<a href="#api_notice" style="padding-right: 20px;">[API]获取应用公告</a>
			<a href="#api_register" style="padding-right: 20px;">[API]注册账号</a>
			<a href="#api_login" style="padding-right: 20px;">[API]登入</a>
			<a href="#api_wx_login" style="padding-right: 20px;">[API]微信登入、注册</a>
			<a href="#api_alteruser" style="padding-right: 20px;">[API]设置账号密码</a>
			<a href="#api_altername" style="padding-right: 20px;">[API]修改名称</a>
			<a href="#api_modify" style="padding-right: 20px;">[API]修改密码</a>
			<a href="#api_findpass" style="padding-right: 20px;">[API]找回密码</a>
			<a href="#api_editcode" style="padding-right: 20px;">[API]解锁设备</a>
			<a href="#api_goods" style="padding-right: 20px;">[API]商品获取</a>
			<a href="#api_pay" style="padding-right: 20px;">[API]支付</a>
			<a href="#api_order" style="padding-right: 20px;">[API]订单查询</a>
			<a href="#api_alterpic" style="padding-right: 20px;">[API]修改头像</a>
			<a href="#api_getinfo" style="padding-right: 20px;">[API]刷新用户信息</a>
			<a href="#api_getvip" style="padding-right: 20px;">[API]会员验证</a>
			<a href="#api_getfen" style="padding-right: 20px;">[API]积分验证</a>
			<a href="#api_diary" style="padding-right: 20px;">[API]签到</a>
			<a href="#api_checkkami" style="padding-right: 20px;">[API]卡密充值</a>
			<a href="#api_wx_bind" style="padding-right: 20px;">[API]绑定微信</a>
			</p>
			<hr/>
			</div>
			<div>
				<h2 id="api_ini">[API]应用配置</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=ini</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>应用ID</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td><a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>200</td><td>返回内容：APP版本、更新内容、更新地址、APP状态、签到、邀请注册赠送VIP时间、应用关闭通知、
							APP扩展配置、支付配置</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_notice">[API]获取应用公告</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=notice</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>应用ID</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td><a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>返回数组公告</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			<div>
				<h2 id="api_register">[API]注册账号</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=register</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>账号</td><td>user</td><td>是</td><td>123456</td><td>用户账号</td></tr>
							<tr><td>密码</td><td>password</td><td>是</td><td>123456</td><td>用户密码</td></tr>
							<tr><td>超级密码</td><td>superpass</td><td>是</td><td>123456</td><td>超级密码用于找回密码以及解锁设备的</td></tr>
							<tr><td>邀请人ID</td><td>inv</td><td>否</td><td>1</td><td>邀请人给的ID，无邀请人可不填</td></tr>
							<tr><td>机器码</td><td>markcode</td><td>是</td><td>F313EXZD24U4S8T</td><td>绑定账号避免多设备登入</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td><a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>成功</td></tr>
							<tr><td>201</td><td>失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							
							<tr><td>100</td><td>账号为空</td></tr>
							<tr><td>101</td><td>密码为空 </td></tr>
							<tr><td>102</td><td>超级密码为空</td></tr>
							<tr><td>103</td><td>机器码为空</td></tr>
							<tr><td>106</td><td>账号长度5~11位，不支持中文和特殊字符</td></tr>
							<tr><td>110</td><td>账号已存在</td></tr>
							<tr><td>111</td><td>该IP已注册</td></tr>
							<tr><td>112</td><td>该机器码已注册</td></tr>
							<tr><td>113</td><td>邀请人ID有误</td></tr>
							<tr><td>114</td><td>邀请人不存在</td></tr>
							
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_login">[API]登入</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=login</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>账号</td><td>user</td><td>是</td><td>123456</td><td>用户账号</td></tr>
							<tr><td>密码</td><td>password</td><td>是</td><td>123456</td><td>用户密码</td></tr>
							<tr><td>机器码</td><td>markcode</td><td>是</td><td>F313EXZD24U4S8T</td><td>绑定账号避免多设备登入</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td><a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>成功返回：用户ID、用户账号、用户头像、用户名字、VIP、token</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							
							<tr><td>100</td><td>账号为空</td></tr>
							<tr><td>101</td><td>密码为空 </td></tr>
							<tr><td>103</td><td>机器码为空</td></tr>
							<tr><td>115</td><td>机器码不匹配</td></tr>
							<tr><td>116</td><td>禁止登陆</td></tr>
							<tr><td>117</td><td>账号密码有误</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_wx_login">[API]微信登入、注册</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=wx_login</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>微信openid</td><td>openid</td><td>是</td><td>123456</td><td>微信openid</td></tr>
							<tr><td>微信access_token</td><td>access_token</td><td>是</td><td>123456</td><td>微信access_token</td></tr>
							<tr><td>邀请人ID</td><td>inv</td><td>否</td><td>1</td><td>邀请人</td></tr>
							<tr><td>机器码</td><td>markcode</td><td>是</td><td>123456</td><td>绑定账号避免多设备登入</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td><a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>系统会自动判读这个微信是否已经注册了账号</p>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>登入成功</td></tr>
							<tr><td>201</td><td>登入失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							
							<tr><td>103</td><td>机器码为空</td></tr>
							<tr><td>111</td><td>该IP已注册</td></tr>
							<tr><td>112</td><td>该机器码已注册</td></tr>
							<tr><td>116</td><td>禁止登陆</td></tr>
							<tr><td>113</td><td>邀请人ID有误</td></tr>
							<tr><td>114</td><td>邀请人不存在</td></tr>
							
							<tr><td>1001</td><td>微信openid为空</td></tr>
							<tr><td>1002</td><td>微信access_token为空</td></tr>
							<tr><td>1003</td><td>错误的身份信息</td></tr>
							<tr><td>1004</td><td>微信openid有误</td></tr>
							
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_alteruser">[API]设置账号密码</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=alteruser</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>登入状态</td><td>token</td><td>是</td><td>8c6aa7a423914ebf7c928aea3c177edf</td><td>登入成功后返回的token</td></tr>
							<tr><td>账号</td><td>user</td><td>是</td><td>123456</td><td>这个方法仅适用于微信登入注册的用户</td></tr>
							<tr><td>密码</td><td>password</td><td>是</td><td>123456</td><td>这个方法仅适用于微信登入注册的用户</td></tr>
							<tr><td>超级密码</td><td>superpass</td><td>是</td><td>123456</td><td>这个方法仅适用于微信登入注册的用户</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td><a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>修改成功</td></tr>
							<tr><td>201</td><td>修改失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>100</td><td>账号为空</td></tr>
							<tr><td>101</td><td>密码为空</td></tr>
							<tr><td>102</td><td>超级密码为空</td></tr>
							<tr><td>106</td><td>账号长度5~11位，不支持中文和特殊字符</td></tr>
							<tr><td>110</td><td>账号已存在</td></tr>
							
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>151</td><td>token有误</td></tr>
							<tr><td>134</td><td>每个用户只能修改一次</td></tr>

						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_altername">[API]修改名称</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=altername</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>登入状态</td><td>token</td><td>是</td><td>8c6aa7a423914ebf7c928aea3c177edf</td><td>登入成功后返回的token</td></tr>
							<tr><td>新的名称</td><td>name</td><td>是</td><td>易如意</td><td>账号的用户名</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>修改成功</td></tr>
							<tr><td>201</td><td>修改失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>151</td><td>token有误或已失效</td></tr>
							
							<tr><td>100</td><td>账号为空</td></tr>
							<tr><td>101</td><td>密码为空</td></tr>
							

						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_modify">[API]修改密码</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=modify</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>账号</td><td>user</td><td>是</td><td>123456</td><td>用户账号</td></tr>
							<tr><td>密码</td><td>password</td><td>是</td><td>123456</td><td>旧密码</td></tr>
							<tr><td>新密码</td><td>newpass</td><td>是</td><td>1234567</td><td>设置新的密码</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>修改成功</td></tr>
							<tr><td>201</td><td>修改失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
						
							<tr><td>100</td><td>账号为空</td></tr>
							<tr><td>101</td><td>密码为空</td></tr>
							<tr><td>129</td><td>新密码为空</td></tr>
							<tr><td>117</td><td>账号密码错误</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_findpass">[API]找回密码</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=findpass</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>账号</td><td>user</td><td>是</td><td>123456</td><td>账号</td></tr>
							<tr><td>超级密码</td><td>superpass</td><td>是</td><td>123456</td><td>超级密码</td></tr>
							<tr><td>新密码</td><td>password</td><td>是</td><td>123456</td><td>设置新密码</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>修改成功</td></tr>
							<tr><td>201</td><td>修改失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
						
							<tr><td>100</td><td>账号为空</td></tr>
							<tr><td>101</td><td>新密码为空</td></tr>
							<tr><td>102</td><td>超级密码为空</td></tr>
							<tr><td>119</td><td>超级密码不正确</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_editcode">[API]解锁设备</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=editcode</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>账号</td><td>user</td><td>是</td><td>123456</td><td>账号</td></tr>
							<tr><td>超级密码</td><td>superpass</td><td>是</td><td>123456</td><td>超级密码</td></tr>
							<tr><td>新的设备机器码</td><td>newcode</td><td>是</td><td>123456</td><td>新的设备机器码</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>修改成功</td></tr>
							<tr><td>201</td><td>修改失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							
							<tr><td>100</td><td>账号为空</td></tr>
							<tr><td>102</td><td>超级密码为空</td></tr>
							<tr><td>119</td><td>超级密码不正确</td></tr>
							<tr><td>118</td><td>机器码为空</td></tr>
							
							<tr><td>120</td><td>24小时内修改过</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_goods">[API]商品获取</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=goods</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
					<tbody>
						<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
						<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
						<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
					</tbody>
					</table>
					<p>返回结果：json数据</p>

				</div>
			</div>
			
			<div>
				<h2 id="api_pay">[API]支付</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=pay</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>订单号</td><td>order</td><td>否</td><td>20190807174624120</td><td>生成的订单号</td></tr>
							<tr><td>账号</td><td>user</td><td>是</td><td>123456</td><td>用户账号</td></tr>
							<tr><td>支付方式</td><td>pway</td><td>是</td><td>zfb</td><td>zfb=支付宝，wx=微信，qq=QQ钱包</td></tr>
							<tr><td>商品ID</td><td>gid</td><td>是</td><td>1</td><td>请先获取商品列表</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>修改成功</td></tr>
							<tr><td>201</td><td>修改失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
						
							<tr><td>100</td><td>账号为空</td></tr>
							<tr><td>135</td><td>订单为空</td></tr>
							<tr><td>136</td><td>支付类型为空</td></tr>
							<tr><td>138</td><td>商品ID为空</td></tr>
							<tr><td>139</td><td>没有找到该商品</td></tr>
							<tr><td>140</td><td>未开启支付功能</td></tr>
							
							<tr><td>141</td><td>支付请求地址为空</td></tr>
							<tr><td>142</td><td>支付APPID为空</td></tr>
							<tr><td>143</td><td>APPkey不能为空</td></tr>
							<tr><td>144</td><td>充值成功通知地址不能为空</td></tr>
							<tr><td>145</td><td>订单入库失败</td></tr>
						</tbody>
					</table>
				</div>
			</div>

			<div>
				<h2 id="api_order">[API]订单查询</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=order</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>账号</td><td>user</td><td>否</td><td>123456</td><td>用户账号：订单号和账号必须填一个</td></tr>
							<tr><td>订单号</td><td>oid</td><td>否</td><td>20190807174624120</td><td>订单号：订单号和账号必须填一个</td></tr>
							<tr><td>获取方式</td><td>gain</td><td>否</td><td>all</td><td>如果是获取用户个人的所有订单则填写all,订单号查询可不填</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>135</td><td>订单号为空</td></tr>
							<tr><td>146</td><td>订单号不存在</td></tr>
							<tr><td>200</td><td>成功返回：订单号、用户账号、商品ID、商品名称、金额、商品类型、VIP天数、积分数、订单时间、
							支付时间、支付类型、支付状态</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_alterpic">[API]修改头像</h2>
				<div>
					<p>URL地址：
					<br>E4A：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=alterpic&amp;appid=【appid】&amp;sign=【sign】&amp;token=【token】&amp;type=e4a
					<br>蓝鸟：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=alterpic&amp;appid=【appid】&amp;sign=【sign】&amp;token=【token】&amp;type=bbp</p>
					<p>POST提交图片，E4A请使用后【如意上传类库】，蓝鸟可以用自带的上传器即可</p>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>修改成功</td></tr>
							<tr><td>201</td><td>修改失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>151</td><td>token已失效或不存在或错误</td></tr>
							<tr><td>131</td><td>提交方式不正确</td></tr>
							<tr><td>132</td><td>上传类型不支持</td></tr>
							<tr><td>133</td><td>修改头像数据失败</td></tr>
							
						</tbody>
					</table>
				</div>
			</div>			
			
			<div>
				<h2 id="api_getinfo">[API]刷新用户信息</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=getinfo</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>token</td><td>token</td><td>是</td><td>8c6aa7a423914ebf7c928aea3c177edf</td><td>用户状态</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>注册用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>成功返回：用户ID、已邀请用户数、账号、头像、名称、微信openid、VIP、积分、机器码</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>151</td><td>token已失效或不存在或不正确</td></tr>
							<tr><td>116</td><td>账号已禁用</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_getvip">[API]会员验证</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=getvip</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>token</td><td>token</td><td>是</td><td>8c6aa7a423914ebf7c928aea3c177edf</td><td>用户状态</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>成功，VIP</td></tr>
							<tr><td>201</td><td>失败，非VIP</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>151</td><td>token已失效或不存在或不正确</td></tr>
							<tr><td>116</td><td>账号已禁用</td></tr>

						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_getfen">[API]积分验证</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=getfen</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>token</td><td>token</td><td>是</td><td>8c6aa7a423914ebf7c928aea3c177edf</td><td>用户状态</td></tr>
							<tr><td>积分事件ID</td><td>fen_id</td><td>是</td><td>1</td><td>积分事件ID</td></tr>
							<tr><td>积分事件标记</td><td>mark</td><td>是</td><td>1</td><td>用于标记用户操作，下次操作则不扣积分</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>成功，扣费成功</td></tr>
							<tr><td>201</td><td>失败，积分不足</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>151</td><td>token已失效或不存在或不正确</td></tr>
							<tr><td>116</td><td>账号已禁用</td></tr>
							<tr><td>160</td><td>积分ID不能为空</td></tr>
							<tr><td>161</td><td>积分事件ID不存在</td></tr>
							<tr><td>162</td><td>积分事件已关闭</td></tr>
							<tr><td>163</td><td>积分事件标记不能为空</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_diary">[API]签到</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=diary</p>
					<p>请求参数说明：</p>
					
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>token</td><td>token</td><td>是</td><td>8c6aa7a423914ebf7c928aea3c177edf</td><td>用户状态</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>签到成功</td></tr>
							<tr><td>201</td><td>签到失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
							
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>151</td><td>token已失效或不存在或不正确</td></tr>
							<tr><td>116</td><td>账号已禁用</td></tr>
							
							<tr><td>126</td><td>签到功能未开启</td></tr>
							<tr><td>127</td><td>今天你签到过了</td></tr>
						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_checkkami">[API]卡密充值</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=checkkami</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>token</td><td>token</td><td>是</td><td>8c6aa7a423914ebf7c928aea3c177edf</td><td>用户状态</td></tr>
							<tr><td>卡密</td><td>kami</td><td>是</td><td>9E0kQMYVaO</td><td>充值卡密</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>成功</td></tr>
							<tr><td>201</td><td>失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
						
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>151</td><td>token已失效或不存在或不正确</td></tr>
							
							<tr><td>121</td><td>卡密为空</td></tr>
							<tr><td>122</td><td>卡密有误</td></tr>
							<tr><td>123</td><td>卡密已被使用</td></tr>
							<tr><td>124</td><td>已是永久会员</td></tr>

						</tbody>
					</table>
				</div>
			</div>
			
			<div>
				<h2 id="api_wx_bind">[API]绑定微信</h2>
				<div>
					<p>URL地址：http://<?php echo $_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"])?>/api.php?action=wx_bind</p>
					<p>请求参数说明：</p>
					<table>
					<thead><tr><th>字段名</th><th>变量名</th><th>必填</th><th>示例值</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>token</td><td>token</td><td>是</td><td>8c6aa7a423914ebf7c928aea3c177edf</td><td>用户状态</td></tr>
							<tr><td>微信openid</td><td>openid</td><td>是</td><td>123456</td><td>微信openid</td></tr>
							<tr><td>微信access_token</td><td>access_token</td><td>是</td><td>ds4a2ddaf414ebf7c928aea3c177edf</td><td>微信access_token</td></tr>
							<tr><td>应用ID</td><td>appid</td><td>是</td><td>10000</td><td>用户绑定应用</td></tr>
							<tr><td>签名字符串</td><td>sign</td><td>是</td><td>b1d5db78459376327cda93d4a95458f6</td><td>
							<a href="https://www.eruyi.cn/thread-5476-1-1.html" target="_blank">签名算法</a></td></tr>
						</tbody>
					</table>
					<p>返回结果：</p>
					<table>
					<thead><tr><th>返回编号</th><th>描述</th></tr></thead>
						<tbody>
							<tr><td>200</td><td>成功</td></tr>
							<tr><td>201</td><td>失败</td></tr>
							<tr><td>104</td><td>应用id为空</td></tr>
							<tr><td>107</td><td>应用不存在</td></tr>
							<tr><td>108</td><td>应用已关闭</td></tr>
							<tr><td>105</td><td>签名为空</td></tr>
							<tr><td>109</td><td>签名错误</td></tr>
						
							<tr><td>150</td><td>token为空</td></tr>
							<tr><td>151</td><td>token已失效或不存在或不正确</td></tr>
							
							<tr><td>1001</td><td>微信openid为空</td></tr>
							<tr><td>1002</td><td>微信access_token为空</td></tr>
							<tr><td>1003</td><td>错误的身份信息</td></tr>
							<tr><td>1004</td><td>微信openid有误</td></tr>
							<tr><td>1006</td><td>该微信已绑定其他账号</td></tr>
							<tr><td>1007</td><td>你已经绑定微信了</td></tr>
							
						</tbody>
					</table>
				</div>
			</div>
			
			<div><h2><a href="#header-5"></a>易如意</h2><div><p>人生苦短迟早如意<br/><div class="highlighter-rouge"><div class="highlight"><pre class="highlight"><strong><code>你不对接我，还能对接谁呢？我就是你的首选网络验证系统创造者~</code></strong></pre></div></div><hr/></div></div>
			<span class="site-footer-owner">
				All rights reserved .
			</span>
			<span class="site-footer-credits">
				<small>
					<a href="http://www.eruyi.cn" target="_blank">
						长沙木皆（易如意）网络科技有限公司技术支持
					</a>
					.
				</small>
			</span>
			</footer>
		</section>
	</body>
</html>