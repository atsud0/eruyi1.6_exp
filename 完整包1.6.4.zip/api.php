<?php
/*
* File：交互接口
* Author：易如意
* QQ：51154393
* url：www.eruyi.cn
** 注意：请勿使用记事本修改，保存时必须保证以《 UTF8 无 BOM 格式编码》，否则会影响返回的数据
*/
include("include/http.php");
require("include/global.php");
date_default_timezone_set('PRC');
$last_t = time()+ 60*10;

$action = isset($_GET['action']) ? addslashes($_GET['action']) : '';
$appid = isset($_POST['appid']) ? (addslashes($_POST['appid'])) : (isset($_GET['appid']) ? addslashes($_GET['appid']) : '');
$sign = isset($_POST['sign']) ? (addslashes($_POST['sign'])) : (isset($_GET['sign']) ? addslashes($_GET['sign']) : '');


if($action !='' and $action != 'pay' and $action != 'presult'){
	if($appid == '') json(104,'应用id不能为空');//应用id为空
	if($sign == '') json(105,'签名不能为空');//签名为空
	
	$app_sql="select * from eruyi_app where id='$appid'";
	$app_query=$db->query($app_sql);
	$app_have=$db->fetch_array($app_query);
	if(!$app_have) json(107,'应用不存在');//应用不存在
	
	if($app_have['state']=='n') json(108,$app_have['notice']);//应用已关闭
	
	$t_sign = Sign($action, $app_have['key'],$app_have['sign_t']);
	if($sign != $t_sign) json(109,'签名错误');//签名错误
}

if($action == 'register'){//用户注册
	$user = isset($_POST['user']) ? addslashes($_POST['user']) : '';
	$password = isset($_POST['password']) ? addslashes($_POST['password']) : '';
	$superpass = isset($_POST['superpass']) ? addslashes($_POST['superpass']) : '';
	$inv = isset($_POST['inv']) ? intval($_POST['inv']) : 0;
	$regdate = time();
	$regip = getIp();
	$markcode = isset($_POST['markcode']) ? addslashes($_POST['markcode']) : '';
	if($user == '') json(100,'账号不能为空');//账号为空
	if($password == '') json(101,'密码不能为空');//密码为空
	if($superpass == '') json(102,'超级密码不能为空');//超级密码为空
	if($markcode == '') json(103,'机器码不能为空');//机器码为空
	
	if (preg_match ("/^[\w]{5,11}$/",$user)==0) json(106,'账号长度5~11位，不支持中文和特殊字符');//账号不支持中文和特殊字符
	
	$sql="select * from eruyi_user where user='$user'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have) json(110,'账号已存在');//账号已存在
	
	$ipon = $app_have['ipon'];//同一IP注册间隔时间
	if($ipon > 0){
		$regtime = $regdate-$ipon*3600;
		$sql="select * from eruyi_user where regip='$regip' and `regdate`>'$regtime'";
		$query=$db->query($sql);
		$have=$db->fetch_array($query);
		if($have) json(111,'该IP已注册');//该IP已注册
	}
	
	$codeon = $app_have['codeon'];//同一机器注册间隔时间
	if($codeon > 0){
		$regtime = $regdate-$codeon*3600;
		$sql="select * from eruyi_user where markcode='$markcode' and `regdate`>'$regtime'";
		$query=$db->query($sql);
		$have=$db->fetch_array($query);
		if($have) json(112,'该机器码已注册');//该机器码已注册
	}
	$inv_award = $app_have['inv_award'];//奖励类型
	$inv_vip = $app_have['inv_vip'];//邀请奖励
	$inv_fen = $app_have['inv_fen'];//邀请奖励
	if ($inv != ''){
		$sql="select * from eruyi_user where uid='$inv'";
		$query=$db->query($sql);
		$have=$db->fetch_array($query);
		if ($have){
			if($have['appid'] != $appid) json(113,'邀请人ID有误');//邀请人不存在
			if($inv_award == 'vip'){
				if ($inv_vip > 0 and $have['vip'] != 999999999){
					if (time() > $have['vip']){
						$vip = $regdate + 3600*$inv_vip;
						$sql = "UPDATE `eruyi_user` SET `vip`='$vip',`i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
					}else{
						$vip = 3600*$inv_vip;
						$sql = "UPDATE `eruyi_user` SET `vip`=`vip`+ $vip,`i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
					}
				}else{
					$sql = "UPDATE `eruyi_user` SET `i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
				}
			}else{
				if ($inv_fen > 0){
					$sql = "UPDATE `eruyi_user` SET `fen`='fen' + $inv_fen,`i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
				}else{
					$sql = "UPDATE `eruyi_user` SET `i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
				}
			}
			$query=$db->query($sql);
		}else {
			json(114,'邀请人不存在');//邀请人不存在
		}
	}
	$reg_award = $app_have['reg_award'];//奖励类型
	$reg_vip = $app_have['reg_vip'];//注册奖励
	$reg_fen = $app_have['reg_fen'];//注册奖励
	$pass = md5($password);
	if($reg_award == 'vip'){
		if ($reg_vip > 0){
			$vip = $regdate + 60 * $reg_vip;
			$fen = 0;
		}else{
			$fen = 0;
			$vip = 0;
		}
	}else{
		if ($reg_fen > 0){
			$fen = $reg_fen;
			$vip = 0;
		}else{
			$vip = 0;
			$fen = 0;
		}
	}
	
	$sql="INSERT INTO `eruyi_user`(`user`, `password`, `superpass`, `inv`, `regdate`, `regip`, `markcode`,`vip`,`fen`,`appid`) VALUES ('$user','$pass','$superpass','$inv','$regdate','$regip','$markcode','$vip','$fen','$appid')";
	$query=$db->query($sql);
	if($query){
		json(200,'注册成功');//注册成功
	}json(201,'注册失败');//注册失败
}

if($action == 'login'){//用户登入
	$user = isset($_POST['user']) ? addslashes($_POST['user']) : '';
	$password = isset($_POST['password']) ? addslashes($_POST['password']) : '';
	$markcode = isset($_POST['markcode']) ? addslashes($_POST['markcode']) : '';

	if($user == '') json(100,'账号不能为空');//账号为空
	if($password == '') json(101,'密码不能为空');//密码不能为空
	if($markcode == '') json(103,'机器码不能为空');//机器码不能为空
	
	$pass = md5($password);
	$sql="select * from eruyi_user where user='$user' and `password`='$pass' and `appid`='$appid'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		$check_code = true;
		if($app_have['check_code']=='y'){
			if($have['markcode']!=$markcode) json(115,'机器码不匹配');//机器码不匹配
		}else{
			if($app_have['many_code']=='y')$check_code = false;
		}
		if($have['lock']>time()) json(116,$have['lock_show']);//账号已被禁用
		
		if($check_code == true){
			$token = md5($user.getcode().$appid);
		}else{
			$token = md5($user.$appid);
		}
		$sql="UPDATE `eruyi_user` SET `token`='$token' , `last_t`='$last_t' WHERE user='$user'";
		$query=$db->query($sql);
		if($query){
			$pic = get_pic($have['pic']);
			$udata = array(
				'uid'=>$have['uid'],
				'user'=>$have['user'],
				'pic'=>$pic,
				'name'=>$have['name'],
				'fen'=>$have['fen'],
				'vip'=>$have['vip'],
				'token'=>$token
			);
			json(200,$udata);
		}
	}else{
		json(117,'账号密码有误');//账号密码有误
	}
}

if($action == 'getinfo'){//获取信息
	$token = isset($_POST['token']) ? addslashes($_POST['token']) : '';
	if($token == '') json(150,'token不能为空');
	$sql="select * from eruyi_user where `token`='$token'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		if($have['lock']>time()) json(116,$have['lock_show']);//账号已被禁用
		$db->query("UPDATE `eruyi_user` SET `last_t`='$last_t' WHERE token='$token'");//活动
		$query=$db->query($sql);
		$pic = get_pic($have['pic']);
		if ($app_have['charge'] == 'y'){
			$vip = $have['vip'];
		}else{
			$vip = '999999999';
		}
		if ($d_time <= $have['diary'] and $have['diary'] <= $t_day){
			$diary = 'n';
		}else {
			$diary = 'y';
		}
		$udata = array(
			'uid'=>$have['uid'],
			'user'=>$have['user'],
			'pic'=>$pic,
			'name'=>$have['name'],
			'wx_openid'=>$have['wx_openid'],
			'i_inv'=>$have['i_inv'],
			'fen'=>$have['fen'],
			'vip'=>$vip,
			'diary'=>$diary,
			'markcode'=>$have['markcode']
		);
		json(200,$udata);
	}else{
		json(151,'token已失效');
	}
}

 
if($action == 'getvip'){//会员验证
	$token = isset($_POST['token']) ? addslashes($_POST['token']) : '';
	if($token == '') json(150,'token不能为空');
	$sql="select * from eruyi_user where token ='$token'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		if($have['lock']>time()) json(116,$have['lock_show']);//账号已被禁用
		$db->query("UPDATE `eruyi_user` SET `last_t`='$last_t' WHERE token='$token'");//活动
		if ($app_have['charge'] == 'y'){//y=收费
			$vip = $have['vip'];
			if($vip == '999999999' || $vip > time()){
		   		json(200,'验证成功');
			}else if($vip < time()){
				json(201,'验证失败');
			}
		}else {
			json(200,'验证成功');
		}
	}else{
		json(151,'token已失效');
	}
}

if($action == 'getfen'){//积分验证
	$token = isset($_POST['token']) ? addslashes($_POST['token']) : '';
	$fen_id = isset($_POST['fen_id']) ? addslashes($_POST['fen_id']) : '';
	$mark = isset($_POST['mark']) ? addslashes($_POST['mark']) : '';
	if($token == '') json(150,'token不能为空');
	if($fen_id == '') json(160,'积分事件不能为空');//积分事件ID不能为空
	if($mark == '') json(163,'积分事件标记不能为空');//积分事件标记不能为空
	$fen_sql="select * from eruyi_fen where id ='$fen_id' and appid = '$appid'";
	$fen_query=$db->query($fen_sql);
	$fen_have=$db->fetch_array($fen_query);
	$fen_time = time();
	if(!$fen_have)json(161,'积分事件不存在');//积分事件ID不存在
	if($fen_have['fen_state']=='n')json(162,'积分事件已关闭');//积分事件已关闭
	$sql="select * from eruyi_user where token ='$token'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		if($have['lock']>time()) json(116,$have['lock_show']);//账号已被禁用
		if ($app_have['charge'] == 'y'){//y=收费
			$fen = $have['fen'];
			$user = $have['user'];
			$fen_money = $fen_have['fen_money'];
		
			$fen_record_sql="select * from eruyi_fen_record where user ='$user' and mark = '$mark' and fen_id = '$fen_id' and appid = '$appid'";
			$fen_record_query=$db->query($fen_record_sql);
			$fen_record_have=$db->fetch_array($fen_record_query);
			if($fen_record_have){
				$db->query("UPDATE `eruyi_user` SET `last_t`='$last_t' WHERE token='$token'");//活动
				json(200,'验证成功');
			}
			
			if($fen >= $fen_money){
				$db->query("UPDATE `eruyi_user` SET `fen` = `fen` - $fen_money,`last_t`='$last_t' WHERE token='$token'");//活动
				$sql="INSERT INTO `eruyi_fen_record`(`user`, `fen_id`, `fen_money`, `mark`, `appid`, `fen_time`) VALUES ('$user', '$fen_id', '$fen_money', '$mark', '$appid', '$fen_time')";
				$db->query($sql);
				json(200,'验证成功');
			}json(201,'积分不足');
		}else {
			$db->query("UPDATE `eruyi_user` SET `last_t`='$last_t' WHERE token='$token'");//活动
			json(200,'验证成功');
		}
	}else{
		json(151,'token已失效');
	}
}


 //签到
if($action == 'diary'){
	$token = isset($_POST['token']) ? addslashes($_POST['token']) : '';
	$diary_t = time();//签到时间
	if($token == '') json(150,'token不能为空');
	$diary_award = $app_have['diary_award'];//奖励类型
	$diary_vip = $app_have['diary_vip'];//签到奖励
	$diary_fen = $app_have['diary_fen'];//签到奖励
	if($diary_award == 'vip' and $diary_vip == 0)json(126,'签到功能未开启');
	if($diary_award == 'fen' and $diary_fen == 0)json(126,'签到功能未开启');
	
	$sql="select * from eruyi_user where `token`='$token'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		if($have['lock']>time()) json(116,$have['lock_show']);//账号已被禁用
		$db->query("UPDATE `eruyi_user` SET `last_t`='$last_t' WHERE token='$token'");//活动
		if ($d_time <= $have['diary'] and $have['diary'] <= $t_day){
			json(127,'今天你签到过了');
		}else {
			if($diary_award == 'vip'){
				if ($have['vip']=='999999999'){
						$sql="UPDATE `eruyi_user` SET `diary` = '$diary_t' WHERE `eruyi_user`.`token`='$token'"; 
					}else if(time() > $have['vip']) {
						$vip = time() + 60 * $diary_vip;
						$sql="UPDATE `eruyi_user` SET `diary` = '$diary_t',`vip` = '$vip' WHERE `eruyi_user`.`token`='$token'";
				}else{
					$vip = 60 * $diary_vip;
					$sql="UPDATE `eruyi_user` SET `diary` = '$diary_t',`vip` = `vip` + $vip WHERE `eruyi_user`.`token`='$token'";
				}
			}else{
				$sql="UPDATE `eruyi_user` SET `diary` = '$diary_t',`fen` = `fen` + $diary_fen WHERE `eruyi_user`.`token`='$token'";
			}
				
			$query=$db->query($sql);
			if($query){
				json(200,'签到成功');
			}json(201,'签到失败');
		}
	}else{
		json(151,'token已失效');
	}
}
 
if($action == 'editcode'){//修改机器码
	$user = isset($_POST['user']) ? addslashes($_POST['user']) : '';
	$superpass = isset($_POST['superpass']) ? addslashes($_POST['superpass']) : '';
	$newcode = isset($_POST['newcode']) ? addslashes($_POST['newcode']) : '';
	
	if($user == '') json(100,'账号不能为空');//账号为空
	if($superpass == '') json(102,'超级密码不能为空');//超级密码不能为空
	if($newcode == '') json(118,'新的机器码不能为空');//机器码不能为空
	
	$sql="select * from eruyi_user where user='$user' and `superpass`='$superpass' and `appid`='$appid'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if(!$have) json(119,'超级密码有误');//超级密码有误
	$now = time();
	if($have['codetime']+24*3600 > $now) json(120,'24内只能修改一次');//24内只能修改一次
	$sql="UPDATE `eruyi_user` SET `markcode`='$newcode',`codetime`='$now' WHERE user='$user'";
	$query=$db->query($sql);
	if($query){
		json(200,'修改成功');//修改成功
	}
}

  
if($action == 'modify'){//修改密码
	$user = isset($_POST['user']) ? addslashes($_POST['user']) : '';
	$password = isset($_POST['password']) ? addslashes($_POST['password']) : '';
	$newpass = isset($_POST['newpass']) ? addslashes($_POST['newpass']) : '';
	if($user == '') json(100,'账号不能为空');//账号为空
	if($password == '') json(101,'密码不能为空');//账号为空
	if($newpass == '') json(129,'新密码不能为空');//新密码不能为空
	$pass = md5($password);
	$sql="select * from eruyi_user where user='$user' and `password`='$pass'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		$npass = md5($newpass);
		$sql="UPDATE `eruyi_user` SET `password`='$npass' WHERE user='$user'";
		$query=$db->query($sql);
		if($query){
			json(200,'修改成功');//修改成功
		}json(201,'修改失败');//修改失败
	}else{
		json(117,'账号密码有误');//账号密码有误
	}
}

  
if($action == 'altername'){//修改名称
	$token = isset($_POST['token']) ? addslashes($_POST['token']) : '';
	$name = isset($_POST['name']) ? addslashes($_POST['name']) : '';
	if($token == '') json(150,'token不能为空');//token不能为空
	if($name == '') json(130,'名称不能为空');//名称不能为空
	$sql="select * from eruyi_user where token ='$token'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		$sql="UPDATE `eruyi_user` SET `name` = '$name',`last_t`='$last_t' WHERE `eruyi_user`.`token`='$token'";
		$query=$db->query($sql);
		if($query) json(200,'修改成功');//修改成功
	}else {
	    json(151,'token已失效');//token已失效
	}
}

   
if($action == 'alterpic'){//上传头像
 	$type = isset($_GET['type']) ? addslashes($_GET['type']) : 'e4a';
	$token = isset($_GET['token']) ? addslashes($_GET['token']) : '';
	if($token == '') json(150,'token不能为空');//token不能为空
	$sql="select * from eruyi_user where token ='$token'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		$user = $have['uid'];
	}else{
		json(151,'token已失效');//token已失效
	}
	$db->query("UPDATE `eruyi_user` SET `last_t`='$last_t' WHERE token='$token'");//活动
	$local_path  = "./pic/";
	if (!file_exists($local_path)) mkdir($local_path);
	if ($type == 'bbp'){
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			foreach ( $_FILES as $name=>$file ) {
				$fn=$file['name'];
				$ft=strrpos($fn,'.',0);
				$fe=substr($fn,$ft);
				$fp='pic/'.$user.$fe;
				$result = move_uploaded_file($file['tmp_name'],$fp);
				$pic = "/" . $fp;
			}
		}json(131,'提交方式不正确');//提交方式不正确
	}else if($type == 'e4a'){
		$target_path = $local_path.$user.".png";
		$result = move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path);
		$pic = substr( $target_path,1);
	}else{
		json(132,'上传类型不支持');//上传类型不支持
	}
	if($result) {
		$sql= "UPDATE `eruyi_user` SET `pic` = '$pic' WHERE `eruyi_user`.`token`='$token'";
		$query=$db->query($sql);
		if($query){
			json(200,'上传成功');//上传成功
		} else {
			json(133,'修改头像数据失败');//修改头像数据失败
		}
    } else{
        json(201,'上传失败');//上传失败
    }
}
 
if($action == 'findpass'){//找回密码
	$user = isset($_POST['user']) ? addslashes($_POST['user']) : '';
	$password = isset($_POST['password']) ? addslashes($_POST['password']) : '';
	$superpass = isset($_POST['superpass']) ? addslashes($_POST['superpass']) : '';
	if($user == '') json(100,'账号不能为空');//账号不能为空
	if($superpass == '') json(102,'超级密码不能为空');//超级密码不能为空
	if($password == '') json(101,'新密码不能为空');//密码不能为空
	$sql="select * from eruyi_user where user='$user' and `superpass`='$superpass' and `appid`='$appid'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if(!$have) json(119,'超级密码有误');//超级密码有误
	$pass = md5($password);
	$sql="UPDATE `eruyi_user` SET `password`='$pass' WHERE user='$user'";
	$query=$db->query($sql);
	if($query){
		json(200,'修改成功');//修改成功
	}json(201,'修改失败');//修改失败
} 

 
if($action == 'checkkami'){//卡密升级
	$token = isset($_POST['token']) ? addslashes($_POST['token']) : '';
	$kami = isset($_POST['kami']) ? addslashes($_POST['kami']) : '';
	if($token == '') json(150,'token不能为空');
	if($kami == '') json(121,'卡密不能为空');
	$sql="select * from eruyi_kami where kami='$kami'";
	$query=$db->query($sql);
	$khave=$db->fetch_array($query);
	if(!$khave) json(122,'卡密有误');
	if($khave['new']!='y') json(123,'卡密已使用');
	$sql="select * from eruyi_user where `token`='$token'";
	$query=$db->query($sql);
	$uhave=$db->fetch_array($query);
	if(!$uhave) json(151,'token已失效');
	$db->query("UPDATE `eruyi_user` SET `last_t`='$last_t' WHERE token='$token'");//活动
	$user = $uhave['user'];
	$KMtype = $khave['type'];
	$k_num = $khave['num'];
	if($KMtype == 'vip'){
		if($uhave['vip']=='999999999') json(124,'你已经是永久会员了');
		if($uhave['vip']>time()){
			if($k_num == 999999999){
				$sql="UPDATE `eruyi_user` SET `vip`='999999999' WHERE token='$token'";
			}else{
				$vip = $k_num*86400;
				$sql="UPDATE `eruyi_user` SET `vip`=`vip`+ $vip WHERE token='$token'";
			}
		}else{
			if($k_num == 999999999){
				$vip = $k_num;
			}else{
				$vip = time()+($k_num*86400);
			}
			$sql="UPDATE `eruyi_user` SET `vip`='$vip' WHERE token='$token'";
		}
	}else{
		$fen = $k_num;
		$sql="UPDATE `eruyi_user` SET `fen`=`fen`+ $fen WHERE token='$token'";
	}
	
	$query=$db->query($sql);
	if($query){
		$date = time();
		$sql="UPDATE `eruyi_kami` SET `new`='n',`user`='$user',`date`='$date' WHERE kami='$kami'";
		$query=$db->query($sql);
		if($query) json(200,'充值成功');
	}else{
		json(201,'充值失败');
	}
}

 //微信登入/注册
if($action == 'wx_login'){
  	$openid = isset($_POST['openid']) ? addslashes($_POST['openid']) : '';
	$access_token = isset($_POST['access_token']) ? addslashes($_POST['access_token']) : '';
	$inv = isset($_POST['inv']) ? addslashes($_POST['inv']) : '';
	$regdate = time();
	$regip = getIp();
	$markcode = isset($_POST['markcode']) ? addslashes($_POST['markcode']) : '';
	if($openid == '') json(1001,'微信openid不能为空');//微信openid为空
	if($access_token == '') json(1002,'微信access_token不能为空');//微信access_token为空
	if($markcode == '') json(103,'机器码不能为空');//机器码不能为空
	$url = 'https://api.weixin.qq.com/sns/userinfo?access_token='.$access_token.'&openid='.$openid.'&lang=zh_CN';
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL,$url);
	curl_setopt($curl, CURLOPT_HEADER,0);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);//禁止调用时就输出获取到的数据
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,false);
	$data = curl_exec($curl);
	curl_close($curl);
	$res = json_decode($data, true);
	//echo $data;
	if (isset($res['errcode']))json(1003,'身份信息错误');//错误的身份信息
	if ($res['openid'] != $openid) json(1004,'微信openid有误');//微信openid有误
	$name = $res['nickname'];
	$pic = $res['headimgurl'];
	$sql="select * from eruyi_user where wx_openid='$openid' and appid='$appid'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		if($have['lock']>time()) json(116,$have['lock_show']);//账号已被禁用
		$token = md5($openid.getcode().$appid);
		$sql="UPDATE `eruyi_user` SET `token`='$token',`last_t`='$last_t' WHERE `wx_openid`='$openid' and `appid`='$appid'";
		$query=$db->query($sql);
		if($query){
			$pic = get_pic($have['pic']);
			$udata = array(
				'uid'=>$have['uid'],
				'user'=>$have['user'],
				'pic'=>$pic,
				'name'=>$have['name'],
				'fen'=>$have['fen'],
				'vip'=>$have['vip'],
				'token'=>$token
			);
			json(200,$udata);//登入成功
		}json(201,'登入失败');//登入失败
	}else{
		$ipon = $app_have['ipon'];//同一IP注册间隔时间
		if($ipon > 0){
			$regtime = $regdate-$ipon*3600;
			$sql="select * from eruyi_user where regip='$regip' and `regdate`>'$regtime'";
			$query=$db->query($sql);
			$have=$db->fetch_array($query);
			if($have) json(111,'该IP已注册');//该IP已注册
		}
		
		$codeon = $app_have['codeon'];//同一机器注册间隔时间
		if($codeon > 0){
			$regtime = $regdate-$codeon*3600;
			$sql="select * from eruyi_user where markcode='$markcode' and `regdate`>'$regtime'";
			$query=$db->query($sql);
			$have=$db->fetch_array($query);
			if($have) json(112,'该机器码已注册');//该机器码已注册
		}
		
		$inv_award = $app_have['inv_award'];//奖励类型
		$inv_vip = $app_have['inv_vip'];//邀请奖励
		$inv_fen = $app_have['inv_fen'];//邀请奖励
		if ($inv != ''){
			$sql="select * from eruyi_user where uid='$inv'";
			$query=$db->query($sql);
			$have=$db->fetch_array($query);
			if ($have){
				if($have['appid'] != $appid) json(113,'邀请人ID有误');//邀请人不存在
				if($inv_award == 'vip'){
					if ($inv_vip > 0){
						if (time() > $have['vip']){
							$vip = $regdate + 3600*$inv_vip;
							$sql = "UPDATE `eruyi_user` SET `vip`='$vip',`i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
						}else {
							$vip = 3600*$inv_vip;
							$sql = "UPDATE `eruyi_user` SET `vip`=`vip`+ $vip,`i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
						}
					}else{
						$sql = "UPDATE `eruyi_user` SET `i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
					}
				}else{
					if ($inv_fen > 0){
						$sql = "UPDATE `eruyi_user` SET `fen`='fen' + $inv_fen,`i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
					}else{
						$sql = "UPDATE `eruyi_user` SET `i_inv`=`i_inv`+ 1 WHERE uid='$inv'";
					}
				}
				$query=$db->query($sql);
			}else {
				json(114,'邀请人不存在');//邀请人不存在
			}
		}
		
		$reg_award = $app_have['reg_award'];//奖励类型
		$reg_vip = $app_have['reg_vip'];//注册奖励
		$reg_fen = $app_have['reg_fen'];//注册奖励
		$pass = md5($password);
		if($reg_award == 'vip'){
			if ($reg_vip > 0){
				$vip = $regdate + 60 * $reg_vip;
				$fen = 0;
			}else{
				$fen = 0;
				$vip = 0;
			}
		}else{
			if ($reg_fen > 0){
				$fen = $reg_fen;
				$vip = 0;
			}else{
				$vip = 0;
				$fen = 0;
			}
		}
		$sql="INSERT INTO `eruyi_user`(`name`,`pic`,`wx_openid`,`inv`, `vip`,`fen`, `regdate`, `regip`, `markcode`,`token`,`last_t`) VALUES ('$name','$pic','$openid','$inv','$vip','$fen','$regdate','$regip','$markcode','$token','$last_t')";
		$query=$db->query($sql);
		if($query){
			$sql="select * from `eruyi_user` where `wx_openid`='$openid' and `appid`='$appid'";
			$query=$db->query($sql);
			$have=$db->fetch_array($query);
			if($have){
				if($have['lock']>time()) json(116,$have['lock_show']);//账号已被禁用
				$pic = get_pic($have['pic']);
				$udata = array(
					'uid'=>$have['uid'],
					'user'=>$have['user'],
					'pic'=>$pic,
					'name'=>$have['name'],
					'fen'=>$have['fen'],
					'vip'=>$have['vip'],
					'token'=>$have['token']
				);
				json(200,$udata);//登入成功
			}json(201,'登入失败');//登入失败
		}json(201,'登入失败');//登入失败
	}
}

 
if($action == 'wx_bind'){ //绑定微信
	$token = isset($_POST['token']) ? addslashes($_POST['token']) : '';
	$openid = isset($_POST['openid']) ? addslashes($_POST['openid']) : '';
	$access_token = isset($_POST['access_token']) ? addslashes($_POST['access_token']) : '';
	if($token == '') json(150,'token不能为空');
	if($openid == '') json(1001,'微信openid不能为空');//微信openid为空
	if($access_token == '') json(1002,'微信access_token不能为空');//微信access_token为空
	$sql="select * from eruyi_user where wx_openid='$openid'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have) json(1006,'该微信已绑定其他账号');//该微信已绑定其他账号
	$sql="select * from eruyi_user where token ='$token'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		if($have['wx_openid'] != null) json(1007,'你已经绑定微信了');//你已经绑定微信了
		$url = 'https://api.weixin.qq.com/sns/userinfo?access_token='.$access_token.'&openid='.$openid.'&lang=zh_CN';
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL,$url);
		curl_setopt($curl, CURLOPT_HEADER,0);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);//禁止调用时就输出获取到的数据
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,false);
		$data = curl_exec($curl);
		curl_close($curl);
		$res = json_decode($data, true);
		if (isset($res['errcode']))json(1003,'身份信息错误');//错误的身份信息
	if ($res['openid'] != $openid) json(1004,'微信openid有误');//微信openid有误
		$name = $res['nickname'];
		$pic = $res['headimgurl'];
		$sql="UPDATE `eruyi_user` SET `wx_openid` = '$openid',`password` = '$pass' WHERE `eruyi_user`.`token`='$token'";
		$query=$db->query($sql);
		if($query){
			json(200,'绑定成功');//修改成功
		}json(201,'绑定失败');//修改失败
	}json(151,'token已失效');
}


  
if($action == 'alteruser'){//设置账号密码
 	$token = isset($_POST['token']) ? addslashes($_POST['token']) : '';
	$user = isset($_POST['user']) ? addslashes($_POST['user']) : '';
	$password = isset($_POST['password']) ? addslashes($_POST['password']) : '';
	$superpass = isset($_POST['superpass']) ? addslashes($_POST['superpass']) : '';
	if($user == '') json(100,'账号不能为空');//账号为空
	if($password == '') json(101,'密码不能为空');//密码不能为空
	if($superpass == '') json(102,'超级密码不能为空');//超级密码为空
	if($token == '') json(150,'token不能为空');
	$pass = md5($password);
	if (preg_match ("/^[\w]{5,11}$/",$user)==0) json(106,'账号长度5~11位，不支持中文和特殊字符');//账号不支持中文和特殊字符
	$sql="select * from eruyi_user where user='$user'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have) json(110,'账号已存在');//账号已存在
	
	$sql="select * from eruyi_user where token ='$token'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		$db->query("UPDATE `eruyi_user` SET `last_t`='$last_t' WHERE token='$token'");//活动
		if ($have['user'] == '' or $have['user'] == null){
			$sql="UPDATE `eruyi_user` SET `user` = '$user',`password` = '$pass',`superpass` = '$superpass' WHERE `token`='$token'";
			$query=$db->query($sql);
			if($query){
				json(200,'修改成功');//修改成功
			}json(201,'修改失败');//修改失败
		}json(134,'账号只能修改一次');//账号只能修改一次
	}else {
	    json(151,'token已失效');
	}
}

if($action == 'goods'){//商品输出
	$sql = "SELECT * FROM `eruyi_goods` where appid ='$appid'";
	$ret = [];
	$record = $db->query($sql);
	while ($row = $db->fetch_array($record)) {
		if($row['g_state'] == 'y'){
			$ret[] = [
				'gid' => $row['id'],
				'name' => $row['g_name'],
				'money' => $row['g_money'],
				'g_type' => $row['g_type'],
				'g_vip' => $row['g_vip'],
				'g_fen' => $row['g_fen']
			];
		}
	}
	json(200,$ret);//商品输出成功

}


if($action == 'pay'){//支付订单创建
	$pt = isset($_POST['pt']) ? (intval($_POST['pt'])) : (isset($_GET['pt']) ? intval($_GET['pt']) : 0);//pay类型，0=默认2=调用如意支付类库
	$user = isset($_POST['user']) ? (addslashes($_POST['user'])) : (isset($_GET['user']) ? addslashes($_GET['user']) : '');//用户帐户
	$pway = isset($_POST['pway']) ? (addslashes($_POST['pway'])) : (isset($_GET['pway']) ? addslashes($_GET['pway']) : '');//支付方式
	$gid = isset($_POST['gid']) ? (addslashes($_POST['gid'])) : (isset($_GET['gid']) ? addslashes($_GET['gid']) : '');//商品id
	
	if($appid == '') return_code(104,'应用id不能为空',$pt);//应用id为空
	if($sign == '') return_code(105,'签名不能为空',$pt);//签名为空
	
	$app_sql="select * from eruyi_app where id='$appid'";
	$app_query=$db->query($app_sql);
	$app_have=$db->fetch_array($app_query);
	if(!$app_have) return_code(107,'应用不存在',$pt);//应用不存在
	
	if($app_have['state']=='n') return_code(108,$app_have['notice'],$pt);//应用已关闭
	
	$t_sign = Sign($action, $app_have['key'],$app_have['sign_t']);
	if($sign != $t_sign) return_code(109,'签名错误',$pt);//签名错误
	
	$order = isset($_POST['order']) ? (addslashes($_POST['order'])) : (isset($_GET['order']) ? addslashes($_GET['order']) : '');//订单号
	//$order = date('YmdHis') . str_pad(mt_rand(1, 99999), 5, '0', STR_PAD_LEFT);
	if($user == '') return_code(100,'账号不能为空',$pt);//账号为空
	if($order == '') return_code(135,'请先创建订单',$pt);//订单不能为空
	if($pway == ''){
		return_code(136,'支付方式不能为空',$pt);//支付方式不能为空
	}else if($pway == 'zfb'){
		if($app_have['pay_zfb_state'] == 'n') return_code(137,'该支付方式已关闭',$pt);//该支付方式已关闭
		$type = $app_have['pay_zfb'];
	}else if($pway == 'wx'){
		if($app_have['pay_wx_state'] == 'n') return_code(137,'该支付方式已关闭',$pt);//该支付方式已关闭
		$type = $app_have['pay_wx'];
	}else if($pway == 'qq'){
		if($app_have['pay_qq_state'] == 'n') return_code(137,'该支付方式已关闭',$pt);//该支付方式已关闭
		$type = $app_have['pay_qq'];
	}
	
	if($gid == '') return_code(138,'商品ID不能为空',$pt);//商品ID不能为空
	
	if($app_have['pay_state'] == 'n') return_code(140,'未开启支付功能',$pt);//未开启支付功能
	$p_appurl = $app_have['pay_url'];
	if($p_appurl == '') return_code(141,'未开启支付功能',$pt);//支付请求地址为空
	$p_appid = $app_have['pay_appid'];
	if($p_appid == '') return_code(142,'未开启支付功能',$pt);//支付APPID为空
	$p_appkey = $app_have['pay_appkey'];
	if($p_appkey == '') return_code(143,'未开启支付功能',$pt);//APPkey不能为空，请前往后台设置
	$p_notify_url = $app_have['pay_notify'];
	if(dirname($_SERVER["REQUEST_URI"]) == '\\' || dirname($_SERVER["REQUEST_URI"]) == '/'){
		$p_return_url = 'http://'.$_SERVER['SERVER_NAME'];
	}else {
		$p_return_url = 'http://'.$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"]);
	}
	if($p_notify_url == '') return_code(144,'未开启支付功能',$pt);//充值成功通知地址不能为空
	
	$sql="select * from eruyi_goods where id='$gid' and appid ='$appid'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if(!$have) return_code(139,'没有该商品',$pt);//没有该商品
	$g_money = $have['g_money'];
	$g_name = $have['g_name'];
	$g_type = $have['g_type'];
	$g_vip = $have['g_vip'];
	$g_fen = $have['g_fen'];
	$o_time = time();
	
	
	
	$sitename = '易如意网络验证系统';
	//$o_info = 'pid='.$p_appid.'&type='.$type.'&out_trade_no='.$order.'&notify_url='.$p_notify_url.'&return_url='.$p_return_url.'&name='.$g_name.'&money='.$g_money.'&sitename='.$sitename;
	$o_info = 'money='.$g_money.'&name='.$g_name.'&notify_url='.$p_notify_url.'&out_trade_no='.$order.'&pid='.$p_appid.'&return_url='.$p_return_url.'&sitename='.$sitename.'&type='.$type;
	$sign = md5Sign($o_info,$p_appkey);
	$sql="INSERT INTO `eruyi_order` (
	`order`, `user`, `g_name`, `money`, `g_type`, `g_vip`, `g_fen`, `o_time`, `g_id`, `pay_type`, `appid`) VALUES (
	'$order','$user','$g_name','$g_money','$g_type','$g_vip','$g_fen','$o_time','$gid', '$pway', '$appid')";
	$query=$db->query($sql);
	if(!$query) return_code(145,'订单入库失败',$pt);//订单入库失败
	$http = new http($p_appurl);
	$http->https();
	$http->setHeader(array('User-Agent: Mozilla/5.0 (Linux; U; Android 8.1.0; zh-cn; BLA-AL00 Build/HUAWEIBLA-AL00) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/57.0.2987.132 MQQBrowser/8.9 Mobile Safari/537.36'));
	$data = $o_info.'&sign='.$sign.'&sign_type=MD5';
	$retdata = $http->post($data);
	$result = strstr($retdata,'维护');
	if($result != '')return_code(144,'支付通道维护中',$pt);//充值成功通知地址不能为空
	echo $retdata;
	return;
}

if($action == 'presult'){//支付结果查询
	$order = isset($_GET['oid']) ? addslashes($_GET['oid']) : '';
	if($order == '') exit('135');//订单不能为空
	$sql = "SELECT * FROM `eruyi_order` where `order` ='$order'";
	$query=$db->query($sql);
	$have=$db->fetch_array($query);
	if($have){
		$p_tate = $have['state'];
		if($p_tate == 0){
			exit('147');//等待支付
		}else if($p_tate == 2){
			exit('200');//充值成功
		}else if($p_tate == 1){
			exit('201');//充值失败
		}else if($p_tate == 3){
			exit('148');//未知用户
		}else if($p_tate == 3){
			exit('149');//已是永久会员
		}
		
	} exit('146');//订单不存在
}

if($action == 'order'){//订单查询
	$gain = isset($_POST['gain']) ? addslashes($_POST['gain']) : '';
	$order = isset($_POST['oid']) ? addslashes($_POST['oid']) : '';
	$user = isset($_POST['user']) ? addslashes($_POST['user']) : '';
	if($gain == ''){
		if($order == '') json(135,'订单不能为空');//订单不能为空
		$sql = "SELECT * FROM `eruyi_order` where `order` ='$order'";
		$query=$db->query($sql);
		$have=$db->fetch_array($query);
		if($have){
			$order_data = array(
				'order'=>$have['order'],
				'user'=>$have['user'],
				'g_id'=>$have['g_id'],
				'g_name'=>$have['g_name'],
				'money'=>$have['money'],
				'g_type'=>$have['g_type'],
				'g_vip'=>$have['g_vip'],
				'g_fen'=>$have['g_fen'],
				'o_time'=>$have['o_time'],
				'p_time'=>$have['p_time'],
				'pay_type'=>$have['pay_type'],
				'state'=>$have['state']
			);
			json(200,$order_data);//订单信息
		} json(146,'订单不存在');//订单不存在
	}else if($gain == 'all'){
		if($user == '') json(190,'查询的账号不能为空');//查询的账号不能为空
		$sql = "SELECT * FROM `eruyi_order` where user ='$user'";
		$ret = [];
		$record = $db->query($sql);
		while ($row = $db->fetch_array($record)) {
			$ret[] = [
				'order'=>$row['order'],
				'user'=>$row['user'],
				'g_id'=>$row['g_id'],
				'g_name'=>$row['g_name'],
				'money'=>$row['money'],
				'g_type'=>$row['g_type'],
				'g_vip'=>$row['g_vip'],
				'g_fen'=>$row['g_fen'],
				'o_time'=>$row['o_time'],
				'p_time'=>$row['p_time'],
				'pay_type'=>$row['pay_type'],
				'state'=>$row['state']
			];
		}
		json(200,$ret);//订单输出成功
	}

}

if($action == 'notice'){//公告通知
	$sql = "SELECT * FROM `eruyi_notice` where appid ='$appid' order by id desc";
	$ret = [];
	$record = $db->query($sql);
	while ($row = $db->fetch_array($record)) {
		$ret[] = [
			'id' => $row['id'],
			'content' => $row['content'],
			'time' => $row['time'],
			'adm' => $row['adm']
		];
	}
	json(200,$ret);//公告获取成功
}

if($action == 't'){//服务器时间
	echo time();
	exit;
}

if($action == 'ini'){//APP配置
	$app_sql="select * from eruyi_app where id='$appid'";
	$app_query=$db->query($app_sql);
	$app_have=$db->fetch_array($app_query);
	if(!$app_have) json(107,'应用不存在');//应用不存在
	
	$app_bb = $app_have['app_bb'];//APP版本
	$app_nshow = $app_have['app_nshow'];//更新内容
	$app_nurl = $app_have['app_nurl'];//更新地址

	$sign_t = $app_have['sign_t'];//sign有效时间
	$state = $app_have['state'];//APP状态
	$reg_vip = $app_have['reg_vip'];//注册赠送VIP时间
	$inv_vip = $app_have['inv_vip'];//邀请注册赠送VIP时间
	$diary_vip = $app_have['diary_vip'];//签到赠送VIP时间
	$notice = $app_have['notice'];//应用关闭通知
	
	$app_extend_ini = $app_have['app_extend_ini'];//APP扩展配置
	$app_extend_1 = $app_have['app_extend_1'];//APP扩展配置1
	$app_extend_2 = $app_have['app_extend_2'];//APP扩展配置2
	$app_extend_3 = $app_have['app_extend_3'];//APP扩展配置3
	$app_extend_4 = $app_have['app_extend_4'];//APP扩展配置4
	$app_extend_5 = $app_have['app_extend_5'];//APP扩展配置5
	
	$pay_state = $app_have['pay_state'];//支付状态
	$pay_url = $app_have['pay_url'];//支付链接
	$pay_appid = $app_have['pay_appid'];//支付APPID
	$pay_appkey = $app_have['pay_appkey'];//支付APPKEY
	$pay_zfb_state = $app_have['pay_zfb_state'];//支付宝状态
	$pay_wx_state = $app_have['pay_wx_state'];//微信状态
	$pay_qq_state = $app_have['pay_qq_state'];//QQ状态
	
	
	$ini_data = array(
		'app_bb'=>$app_bb,
		'app_nshow'=>$app_nshow,
		'app_nurl'=>$app_nurl,
		'inv_vip'=>$inv_vip,
		'diary_vip'=>$diary_vip
	);
	if($app_extend_ini == 'y'){
		if($app_extend_1 != ''){
			$ini_data = array_merge($ini_data,array('app_extend_1'=>$app_extend_1));
		}
		if($app_extend_2 != ''){
			$ini_data = array_merge($ini_data,array('app_extend_2'=>$app_extend_2));
		}
		if($app_extend_3 != ''){
			$ini_data = array_merge($ini_data,array('app_extend_3'=>$app_extend_3));
		}
		if($app_extend_4 != ''){
			$ini_data = array_merge($ini_data,array('app_extend_4'=>$app_extend_4));
		}
		if($app_extend_5 != ''){
			$ini_data = array_merge($ini_data,array('app_extend_5'=>$app_extend_5));
		}
	}
	if($pay_state == 'y'){
		$ini_data = array_merge(
		$ini_data,
		array('pay_url'=>$pay_url,
		'pay_appid'=>$pay_appid,
		'pay_appkey'=>$pay_appkey,
		'pay_zfb_state'=>$pay_zfb_state,
		'pay_wx_state'=>$pay_wx_state,
		'pay_qq_state'=>$pay_qq_state
		));
	}
	json(200,$ini_data);
}
 
 echo "<h1>Error</h1>";

/*
* File：使用函数
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/
function getIp() {
	$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
	if (!ip2long($ip)) {
		$ip = '';
	}
	return $ip;
}
function getcode(){ 
	$str = null;  
	$strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";  
	$max = strlen($strPol)-1;  
	for($i=0;$i<32;$i++){
		$str.=$strPol[rand(0,$max)];
	}  
	return $str; 
}

function get_pic($pic_url) {
	if(dirname($_SERVER["REQUEST_URI"]) == '\\' || dirname($_SERVER["REQUEST_URI"]) == '/'){
		$av_url = 'http://'.$_SERVER['SERVER_NAME'];
	}else {
		$av_url = 'http://'.$_SERVER['SERVER_NAME'].dirname($_SERVER["REQUEST_URI"]);
	}
	if(substr($pic_url,0,4)=='http'){
		return $pic_url;
	}else{
		return $av_url.$pic_url;
	}
}

function md5Sign($prestr, $key) {
	$prestr = $prestr . $key;
	return md5($prestr);
}

function Sign($data,$appkey,$sign_t) {
	$data = $data . $appkey . floor(time()/$sign_t)*$sign_t;
	return md5($data);
}


function json($code,$msg) {
	$udata = array('code'=>$code,'msg'=>$msg,'time'=>time());
	$jdata = json_encode($udata);
	echo $jdata;
	exit;
}

function return_code($code,$msg,$pt) {
	if($pt == 0){
		json($code,$msg);
	}else{
		echo "<script>location.href='?code=".$code."';</script>";
		return;
	}
	
}



?>
