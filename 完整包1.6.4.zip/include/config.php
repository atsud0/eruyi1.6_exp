<?php
date_default_timezone_set("Asia/Shanghai");
$dt = date("Y-m-d 00:00:00");
$d_time = strtotime($dt);//今日时间
$t_day = strtotime($dt) + 24 * 3600;//今天23:59:59

define('DB_HOST','localhost');//数据库连接地址，默认：localhost或127.0.0.1
define('DB_USER','root');//数据库账号
define('DB_PASSWD','root');//数据库密码
define('DB_NAME','user');//数据库名称

?>