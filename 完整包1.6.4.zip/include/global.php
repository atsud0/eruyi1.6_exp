<?php
/*
* File：Global.php
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/
	header("content-type:text/html; charset=utf-8"); 
	require_once("config.php");
	require_once("Mysql.php");
	$db = MySql::getInstance();

	function pagination($count, $perlogs, $page, $url) {
		$pnums = @ceil($count / $perlogs);
		$re = '';
		$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|", "", $url);
		for ($i = $page - 2; $i <= $page + 2 && $i <= $pnums; $i++) {
			if ($i > 0) {
				if ($i == $page) {
					$re .= "<li><span>$i</span></li>";
				} elseif ($i == 1) {
					$re .= "<li><a href=\"$urlHome\">$i</a></li>";
				} else {
					$re .= "<li><a href=\"$url$i\">$i</a></li>";
				}
			}
		}
		if($page > 0)
			if($pnums > $page){//前进
				$go = $page +1;
			}else{
				$go = $page;
			}
			if($page > 1){
				$after = $page -1;
			}else{
				$after = $page;
			}
			$re = "<li><a href=\"$url$after\"><i class=\"icon-double-angle-left\"></i></a></li>$re";
			$re .= "<li><a href=\"$url$go\"><i class=\"icon-double-angle-right\"></i></a></li>";
		if ($pnums <= 1)
			$re = '';
		return "<ul>".$re."</ul>";
	}
?>