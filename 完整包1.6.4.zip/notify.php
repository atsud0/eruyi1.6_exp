<?php
/* *
 * 功能：木皆支付异步通知页面
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 *************************页面功能说明*************************
 * 创建该页面文件时，请留心该页面文件中无任何HTML代码及空格。
 * 该页面不能在本机电脑测试，请到服务器上做测试。请确保外部可以访问该页面。
 * 该页面调试工具请使用写文本函数logResult，该函数已被默认关闭，见alipay_notify_class.php中的函数verifyNotify
 */
include("include/global.php");
$order = isset($_POST['out_trade_no']) ? (addslashes($_POST['aout_trade_no'])) : (isset($_GET['out_trade_no']) ? addslashes($_GET['out_trade_no']) : '');//商户订单号
$sql = "SELECT * FROM `eruyi_order` where `order` ='$order'";
$query=$db->query($sql);
$oid_have=$db->fetch_array($query);
$appid = $oid_have['appid'];

$app_sql="select * from eruyi_app where id='$appid'";
$app_query=$db->query($app_sql);
$app_have=$db->fetch_array($app_query);
//商户ID
$alipay_config['partner']= $app_have['pay_appid'];
//商户KEY
$alipay_config['key']= $app_have['pay_appkey'];
//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

//签名方式 不需修改
$alipay_config['sign_type']= strtoupper('MD5');
//字符编码格式 目前支持 gbk 或 utf-8
$alipay_config['input_charset']= strtolower('utf-8');
//访问模式,根据自己的服务器是否支持ssl访问，若支持请选择https；若不支持请选择http
$alipay_config['transport']= 'http';

//支付API地址
$alipay_config['apiurl']= 'http://'.$_SERVER['HTTP_HOST'].'/';
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
require_once("lib/epay_notify.class.php");
//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {//验证成功
	$trade_no = $_GET['trade_no'];//支付交易号
	$trade_status = $_GET['trade_status'];//交易状态	
	$type = $_GET['type'];//支付方式
	$money = $_GET['money'];//支付金额
	$udata = array(
		'trade_no' => $trade_no,
		'trade_status' => $trade_status,
		'type' => $type,
		'money' => $money
	);
	$data = json_encode($udata);
	if ($trade_status == 'TRADE_SUCCESS' and $oid_have['state'] == 0) {
		$user = $oid_have['user'];
		$g_type = $oid_have['g_type'];
		$g_vip = $oid_have['g_vip'];
		$g_fen = $oid_have['g_fen'];
		$sql="select * from eruyi_user where `user`='$user'";
		$query=$db->query($sql);
		$have=$db->fetch_array($query);
		if(!$have){
			$state = 3;//没有找到用户
		}else{
			if($g_type == 'vip'){
				if($have['vip']=='999999999'){
					$state = 4;//该用户已是VIP会员
				}else if($have['vip']>time()){
					if($g_vip == '9999'){
						$sql="UPDATE `eruyi_user` SET `vip`='999999999' WHERE user='$user'";
					}else{
						$sql="UPDATE `eruyi_user` SET `vip`=`vip`+$g_vip*86400 WHERE user='$user'";
					}
				}else{
					if($g_vip == '9999'){
						$vip = '999999999';
					}else{
						$vip = time()+$g_vip*86400;
					}
					$sql="UPDATE `eruyi_user` SET `vip`='$vip' WHERE user='$user'";
				}
				$query=$db->query($sql);
				if($query){
					$state = 2;//成功
				}else{
					$state = 1;//失败
				}
			}else if($g_type == 'fen'){
				$sql = "UPDATE `eruyi_user` SET `fen`=`fen` + $g_fen WHERE user='$user'";
				$query=$db->query($sql);
				if($query){
					$state = 2;//成功
				}else{
					$state = 1;//失败
				}
			}
			
		}
		$sql="UPDATE `eruyi_order` SET `data` = '$data',`state` = '$state' WHERE `order`='$order'";
    }else{
		$sql="UPDATE `eruyi_order` SET `data` = '$data' WHERE `order`='$order'";
	}
	$query=$db->query($sql);
	echo "success";		//请不要修改或删除
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}else{//验证失败
	$sql="UPDATE `eruyi_order` SET `data` = 'fail' WHERE `order`='$order'";
	$query=$db->query($sql);
    echo "fail";
}
?>