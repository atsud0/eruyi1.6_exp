<?php
include("include/global.php");
$ipList = array('192.168.0.13','127.0.0.1');//可添加多个安全IP，只有安全IP才可调用该接口

if(!in_array(getIP(),$ipList)) json(100,'安全IP校验失败');

$user = isset($_GET['user']) ? addslashes($_GET['user']) : '';
$day = isset($_GET['day']) ? addslashes($_GET['day']) : '';
if($user == '') json(101,'用户账号不能为空');
if($day == '') json(102,'增加天数不能为空');

$sql="select * from eruyi_user where `user`='$user'";
$query=$db->query($sql);
$have=$db->fetch_array($query);
if(!$have) json(103,'没有找到该用户');
if($have['vip']=='999999999') json(104,'该用户已是永久会员');
if($have['vip']>time()){
    if($day == '9999'){
        $sql="UPDATE `eruyi_user` SET `vip`='999999999' WHERE user='$user'";
    }else{
        $sql="UPDATE `eruyi_user` SET `vip`=`vip`+$day*86400 WHERE user='$user'";
    }
}else{
    if($day == '9999'){
        $vip = '999999999';
    }else{
        $vip = time()+$day*86400;
    }
    $sql="UPDATE `eruyi_user` SET `vip`='$vip' WHERE user='$user'";
}
$query=$db->query($sql);
if($query){
	json(200,'增加成功');
}else{
	json(201,'增加失败');
}


function getIP() {
    if (getenv('HTTP_CLIENT_IP')) {
        $ip = getenv('HTTP_CLIENT_IP');
    } elseif (getenv('HTTP_X_FORWARDED_FOR')) {
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    } elseif (getenv('HTTP_X_FORWARDED')) {
        $ip = getenv('HTTP_X_FORWARDED');
    } elseif (getenv('HTTP_FORWARDED_FOR')) {
        $ip = getenv('HTTP_FORWARDED_FOR');

    } elseif (getenv('HTTP_FORWARDED')) {
        $ip = getenv('HTTP_FORWARDED');
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function json($code,$msg) {
	$udata = array('code'=>$code,'msg'=>$msg);
	$jdata = json_encode($udata);
	echo $jdata;
	exit;
}