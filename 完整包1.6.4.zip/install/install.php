﻿<?php

/*
* File：数据库安装
* Author：易如意
* QQ：51154393
* Url：www.eruyi.cn
*/
$error_msg = '';
if (isset($_GET['a']) && $_GET['a'] == 'install') {
    $error = [
        'db_server' => '请输入数据库地址',
        'db_u' => '请输入数据库用户名',
        'db_name' => '请输入数据库名',
        'user' => '请输入管理员用户名',
        'pwd' => '请输入管理员密码'
    ];
    foreach ($error as $key => $val) {
        if (!array_isset($_POST, $key)) {
            $error_msg = $val;
            break;
        }
    }
    if (!$error_msg) {
        $conn = @mysqli_connect($_POST['db_server'], $_POST['db_u'], $_POST['db_p']);
		mysqli_query($conn,"set names utf8");
        if ($conn) {
            if (@mysqli_select_db($conn, $_POST['db_name'])) {
                mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `eruyi_user` (
                    `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`name` varchar(255) DEFAULT '这个人很懒，没有名字' COMMENT '名称',
					`pic` varchar(255) DEFAULT '/pic/0.png' COMMENT '头像',
					`user` varchar(32) DEFAULT NULL COMMENT '账号',
					`wx_openid` varchar(128) DEFAULT NULL COMMENT '微信openid',
					`password` varchar(32) DEFAULT NULL COMMENT '密码',
					`i_inv` int(10) DEFAULT '0' COMMENT '我邀请的',
					`inv` int(10) DEFAULT NULL COMMENT '推荐人',
					`vip` int(10) DEFAULT '0' COMMENT 'VIP到期时间',
					`fen` int(10) DEFAULT '0' COMMENT '积分',
					`superpass` varchar(255) DEFAULT NULL COMMENT '超级密码',
					`regdate` int(10) NOT NULL,
					`regip` varchar(15) DEFAULT NULL COMMENT '注册IP',
					`markcode` varchar(32) DEFAULT NULL COMMENT '机器码',
					`codetime` int(10) DEFAULT '0' COMMENT '机器码修改时间',
					`lock` int(10) DEFAULT '0' COMMENT '禁用账号0=正常',
					`lock_show` varchar(255) DEFAULT NULL COMMENT '禁用账号说明',
					`diary` int(10) DEFAULT '0' COMMENT '签到时间',
					`appid` varchar(32) NOT NULL COMMENT '应用ID',
					`token` varchar(32) DEFAULT NULL COMMENT 'token',
					`last_t` int(10) DEFAULT '0' COMMENT '最后活动时间',
                    PRIMARY KEY (`uid`),
					UNIQUE KEY `user` (`user`),
					KEY `username` (`user`)
                ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
				
				mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `eruyi_app` (
                    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
					`name` varchar(255) NOT NULL COMMENT '应用名称',
					`key` varchar(32) NOT NULL COMMENT '应用key',
					`sign_t` int(10) DEFAULT '100' COMMENT 'sign有效期',
					`state` enum('y','n') DEFAULT 'y' COMMENT 'APP状态y=正常',
					`charge` enum('y','n') DEFAULT 'y' COMMENT '运营模式y=收费',
					`ipon` int(10) DEFAULT '0' COMMENT 'IP注册限制',
					`codeon` int(10) DEFAULT '0' COMMENT '机器码注册限制',
					`check_code` enum('y','n') DEFAULT 'y' COMMENT '登入验证机器码y=开启',
					`many_code` enum('y','n') DEFAULT 'y' COMMENT '支持多个设备登入',
					`reg_award` enum('vip','fen') DEFAULT 'vip' COMMENT '注册奖励类型',
					`inv_award` enum('vip','fen') DEFAULT 'vip' COMMENT '邀请奖励类型',
					`diary_award` enum('vip','fen') DEFAULT 'vip' COMMENT '签到奖励类型',
					`reg_vip` int(10) DEFAULT '0' COMMENT '注册赠送VIP时间(单位：分钟，0=不赠送)',
					`reg_fen` int(10) DEFAULT '0' COMMENT '注册赠送积分，0=不赠送',
					`inv_vip` int(10) DEFAULT '0' COMMENT '邀请注册赠送VIP时间(单位：小时，0=不赠送)',
					`inv_fen` int(10) DEFAULT '0' COMMENT '邀请奖励积分，0=不赠送',
					`diary_vip` int(10) DEFAULT '0' COMMENT '签到赠送VIP时间(单位：分钟，0=不赠送)',
					`diary_fen` int(10) DEFAULT '0' COMMENT '签到奖励积分(单位：分钟，0=不赠送)',
					`notice` varchar(255) DEFAULT NULL COMMENT '关闭通知',
					`app_bb` varchar(10) DEFAULT '1.0.0' COMMENT '应用版本',
					`app_nshow` varchar(255) DEFAULT NULL COMMENT '更新内容',
					`app_nurl` varchar(255) DEFAULT NULL COMMENT '更新地址',
					`app_extend_ini` enum('y','n') DEFAULT 'n' COMMENT '扩展配置状态',
					`app_extend_1` varchar(255) DEFAULT NULL COMMENT '扩展配置1',
					`app_extend_2` varchar(255) DEFAULT NULL COMMENT '扩展配置2',
					`app_extend_3` varchar(255) DEFAULT NULL COMMENT '扩展配置3',
					`app_extend_4` varchar(255) DEFAULT NULL COMMENT '扩展配置4',
					`app_extend_5` varchar(255) DEFAULT NULL COMMENT '扩展配置5',
					`pay_state` enum('y','n') DEFAULT 'n' COMMENT '支付状态',
					`pay_url` varchar(255) DEFAULT NULL COMMENT '支付请求地址',
					`pay_appid` varchar(10) DEFAULT NULL COMMENT '支付ID',
					`pay_appkey` varchar(255) DEFAULT NULL COMMENT '支付秘钥',
					`pay_qq` varchar(255) DEFAULT 'qqpay' COMMENT 'QQ支付方式',
					`pay_zfb` varchar(255) DEFAULT 'alipay' COMMENT '支付宝支付方式',
					`pay_wx` varchar(255) DEFAULT 'wxpay' COMMENT '微信支付方式',
					`pay_zfb_state` enum('y','n') DEFAULT 'y' COMMENT '支付宝支付方式状态',
					`pay_wx_state` enum('y','n') DEFAULT 'y' COMMENT '微信支付方式状态',
					`pay_qq_state` enum('y','n') DEFAULT 'y' COMMENT 'QQ支付方式状态',
					`pay_notify` varchar(255) DEFAULT NULL COMMENT '异步通知地址',
                    PRIMARY KEY (`id`)
                ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10000 ;");
				
				mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `eruyi_fen` (
				  `id` int(10) NOT NULL AUTO_INCREMENT,
				  `fen_name` varchar(255) NOT NULL COMMENT '积分事件名称',
				  `fen_money` int(10) NOT NULL COMMENT '积分金额',
				  `appid` int(10) NOT NULL,
				  `fen_state` enum('y','n') DEFAULT 'y' COMMENT '积分事件状态',
				  PRIMARY KEY (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
				
				mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `eruyi_fen_record` (
				  `id` int(10) NOT NULL AUTO_INCREMENT,
				  `user` varchar(255) NOT NULL COMMENT '用户账号',
				  `fen_id` int(10) NOT NULL COMMENT '积分事件ID',
				  `fen_money` int(10) NOT NULL COMMENT '积分事件价格',
				  `mark` varchar(255) NOT NULL COMMENT '积分事件记录标记下次触发同一个标记不需要重新支付积分',
				  `appid` int(10) NOT NULL,
				  `fen_time` int(10) NOT NULL COMMENT '事件时间',
				  PRIMARY KEY (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
				
				mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `eruyi_goods` (
				  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
				  `g_money` float(10,2) NOT NULL DEFAULT '0.00',
				  `g_name` varchar(255) NOT NULL COMMENT '商品名称',
				  `g_type` enum('vip','fen') NOT NULL DEFAULT 'vip' COMMENT '商品类型',
				  `g_vip` int(11) DEFAULT '0' COMMENT '会员天数',
				  `g_fen` int(10) DEFAULT '0' COMMENT '积分数',
				  `appid` varchar(32) NOT NULL COMMENT '应用ID',
				  `g_state` enum('y','n') NOT NULL DEFAULT 'y' COMMENT '商品状态',
				  KEY `id` (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
				
				mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `eruyi_kami` (
				  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
				  `kami` varchar(32) NOT NULL,
				  `type` enum('vip','fen') NOT NULL COMMENT '卡密类型',
                  `num` int(10) NOT NULL COMMENT 'VIP天数或积分数',
				  `new` enum('y','n') NOT NULL DEFAULT 'y' COMMENT '卡密状态y=正常',
				  `user` varchar(32) DEFAULT NULL COMMENT '使用账户',
				  `date` int(10) DEFAULT NULL COMMENT '使用时间',
				  PRIMARY KEY (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
				
				mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `eruyi_notice` (
				  `id` int(10) NOT NULL AUTO_INCREMENT,
				  `content` varchar(255) NOT NULL COMMENT '内容',
				  `appid` varchar(255) NOT NULL COMMENT '应用id',
				  `time` int(10) NOT NULL COMMENT '时间戳',
				  `adm` varchar(255) NOT NULL COMMENT '发布人',
				  PRIMARY KEY (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
				
				mysqli_query($conn, "CREATE TABLE IF NOT EXISTS `eruyi_order` (
				  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
				  `order` varchar(20) NOT NULL COMMENT '订单号',
				  `user` varchar(200) NOT NULL COMMENT '账号',
				  `g_name` varchar(255) NOT NULL COMMENT '商品名称',
				  `money` float(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
				  `g_type` enum('vip','fen') NOT NULL COMMENT '商品类型',
				  `g_vip` int(10) DEFAULT '0' COMMENT 'VIP天',
				  `g_fen` int(10) DEFAULT '0' COMMENT '积分数',
				  `o_time` int(10) NOT NULL COMMENT '订单时间',
				  `p_time` varchar(255) DEFAULT NULL COMMENT '支付时间',
				  `g_id` int(11) NOT NULL COMMENT '商品ID',
				  `pay_type` enum('zfb','wx','qq') NOT NULL COMMENT '支付方式',
				  `state` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0' COMMENT '订单状态0=待支付1=充值未到账2=成功3=未找到该用户4=用户已是永久会员5=未知错误',
				  `appid` varchar(32) NOT NULL COMMENT '应用ID',
				  `data` varchar(255) DEFAULT NULL COMMENT '支付回调结果',
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `order` (`order`)
				) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;");
				
                $config = file_get_contents('../include/config.php');
                $config = preg_replace("/define\('DB_HOST','.*?'\)/", "define('DB_HOST','{$_POST['db_server']}')", $config);
                $config = preg_replace("/define\('DB_USER','.*?'\)/", "define('DB_USER','{$_POST['db_u']}')", $config);
                $config = preg_replace("/define\('DB_PASSWD','.*?'\)/", "define('DB_PASSWD','{$_POST['db_p']}')", $config);
                $config = preg_replace("/define\('DB_NAME','.*?'\)/", "define('DB_NAME','{$_POST['db_name']}')", $config);
                file_put_contents('../include/config.php', $config);

                $userdata = file_get_contents('../admin/userdata.php');
				
                $userdata = preg_replace('/\$user = \'.*?\'/', '$user = \'' . $_POST['user'] . '\'', $userdata);
                $userdata = preg_replace('/\$pass = \'.*?\'/', '$pass = \'' . $_POST['pwd'] . '\'', $userdata);
				$userdata = preg_replace('/\$cookie = \'.*?\'/', '$cookie = \'' . md5($_POST['user'].$_POST['pwd'].time()) . '\'', $userdata);
                file_put_contents('../admin/userdata.php', $userdata);
				rename('install.php', 'install.lock' );
                header('Location: ../admin/login.php');
                // rename('install.php','install.php.back');
            } else {
                $error_msg = '未找到数据库';
            }
        } else {
            $error_msg = '错误的数据库信息,连接失败';
        }
    }

}
function array_isset($arr, $key)
{
    return isset($arr[$key]) && !empty($arr[$key]);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../admin/style/css/css-login.css" type="text/css" media="screen" /> 
<title>管理登录</title>
</head>
<body>
<form name="f" method="post" action="./install.php?a=install">
<div class="login-main">
	<div class="login-top"></div>
	<div class="login-logo"><img src="../admin/style/images/install_logo.png" alt="admin" width="294" height="68" /></div>
	<div class="login-input">
        <span style="font-size:14px">数据库信息:</span><br>
        <span>数据库地址</span>
		<div><input type="text" name="db_server" value="localhost" /></div>
        <span>数据库用户</span>
		<div><input type="text" name="db_u" value="root" /></div>
        <span>数据库密码</span>
		<div><input type="text" name="db_p" /></div>
        <span>数据库名</span>
		<div><input type="text" name="db_name" /></div>
        <span style="font-size:14px">管理员信息:</span><br>
        <span>账号</span>
		<div><input type="text" name="user" /></div>
		<span>密码</span>
		<div><input type="password" name="pwd" /></div>
	</div>
	<div class="login-button">
	<div class="button"><input type="submit" value="开 始 安 装" class="submit"></div>
	</div>
	<div style="clear:both;"></div>
	<div class="login-bottom"></div>
</div>
<?php if ($error_msg) : ?>
<div class="login-error"><?php echo $error_msg; ?></div>
<?php endif; ?>
</form>
</body>
</html>
